for i=1:18
 [Best3,Index] = max(MPPT3_Pout{i}{1:3,1:18});
 BestPeff(1) = MPPT3_Peff(Index);
 
 Ave(i) = mean(MPPT4_Pout{i})
 [Best4,Index] = max(Ave(i))
 BestPeff(2) = MPPT4_Peff(Index)
 
 Ave(i) = mean(MPPT4_Pout{i})
 [Best4,Index] = max(Ave(i))
 BestPeff(2) = MPPT4_Peff(Index)
 end
    
Solution = sort(BestPeff)