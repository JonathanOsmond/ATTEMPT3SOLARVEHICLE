%UNTITLED plotFunction takes the cell array ResultTotal after all the
%simulations have run and unpackages and plots the necessary data.



%UNTITLED plotFunction takes the cell array ResultTotal after all the
%simulations have run and unpackages and plots the necessary data.



%% MPPT3 Efficiencies
NumMPPT = 3;
w = 1;
for BattVolt = 110:5:150
    
    if BattVolt/NumMPPT >40
        
        disp('ERROR: MPPT cannot output over 40v')
        
        break
        
    end
        
        for i=1:18
            
            [Pmax(i),Index] = (max(Result{1,1}(i).Power));   %PowerMax for every half hour
            Vmp(i) = Result{1,1}(i).Voltage(Index);
            [Peff(i),OverVoltage] = EfficiencyData(BattVolt,NumMPPT,Vmp(i));
            Pout(i) = Peff(i)*Pmax(i);
            
           
            
            
        end
        
         PeffMax3(w) = max(Peff);
         PoutMax3(w) = max(Pout);
          w=w+1;
      
      
end
         [maxPeff3,Index3_Peff] = max(Peff); 
         [maxPout3,Index3_Pout] = max(Pout);
          BestBattVolt3 = [Index3_Peff*5+110,Index3_Pout*5+110];    




%% MPPT4 EFFICIENCIES
NumMPPT = 4;
w = 1;
for BattVolt = 110:5:150
    
    if BattVolt/NumMPPT >40
        
        disp('ERROR: MPPT cannot output over 40v')
        
        break
        
    end
    
    for q = 1:3
        
        for i=1:18
            
            [Pmax(i),Index] = (max(Result{1,2}{q,i}.Power));   %PowerMax for every half hour
            disp(Index)
            Vmp(q,i) = Result{1,2}{q,i}.Voltage(Index);
            Peff(q,i) = EfficiencyData(BattVolt,NumMPPT,Vmp(q,i));
            Pout(q,i) = Peff(q,i)*Pmax(i);
        end
            [maxPout4(q),Index4(q)] = max(Pout(q,:));
            
             
    end
        BestPeff4(w) = max(mean(Peff));
        BestPout4(w) = max(mean(Pout));
        
      [AveMaxPeff4,Index4_Peff] = max(BestPeff4);
      [AveMaxPout4,Index4_Pout] = max(BestPout4);
      BestBattVolt4 = [Index4_Peff*5+110,Index4_Pout*5+110];
      w=w+1;
end
        

      

%% MPPT5 EFFICIENCIES
NumMPPT = 5;
w = 1;
for BattVolt = 110:5:150
    
    for q = 1:3
        
        for i=1:18
            
            [Pmax(i),Index] = (max(Result{1,3}{q,i}.Power)); %PowerMax for every half hour
            Vmp(q,i) = Result{1,3}{q,i}.Voltage(Index);
            
            Peff(q,i) = EfficiencyData(BattVolt,NumMPPT,Vmp(q,i));
            Pout(q,i) = Peff(q,i)*Pmax(i);
            
        end
            [maxPout5(q),Index5(q)] = max(Pout(q,:));
    end
    
        BestPeff5(w) = max(mean(Peff));
        BestPout5(w) = max(mean(Pout));
        
        
        
     
      w=w+1;
end  
      [AveMaxPeff5,Index5_Peff] = max(BestPeff5);
      [AveMaxPout5,Index5_Pout] = max(BestPout5);
      BestBattVolt5 = [Index5_Peff*5+110,Index5_Pout*5+110];
 %% Best Solution finder
 
 
 
 
    
%Solution = sort(maxPout3,mean(maxPout4),mean(maxPout5))


                

 