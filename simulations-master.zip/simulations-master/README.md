AUSRT Design Simulations
========================

This repository contains scripts (matlab), data and any programs that may be useful for simulation or parametric design for AUSRT. Currently it is targetting solar array and MPPT design optimisation.

Requirements
------------

Some simulation files require Matlab 2016a with a SimScape license in order to run correctly.