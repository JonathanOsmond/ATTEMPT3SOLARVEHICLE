function [Peff,OverVoltage] = EfficiencyData(BattVolt,NumMPPT,Vmp)
% The Values used for efficiency need to be checked as they are quite
% ambiguous
% PEFF vs Vout for Vmp = 12V
OverVoltage=0;
Vout = BattVolt/NumMPPT;

if Vout>40
    disp('ERROR: MPPT cannot output over 40V')
    OverVoltage=1;
end

Eff1 = [97.5,97,96.5,95,93.5];
Vout1 = [10,16,32,36,40];

%PEFF vs Vout for Vmp = 24V
Eff2 = [98.5,97.5,96.5,96.1];
Vout2 = [10,26,36,40];              %DODGY NUMBERS MAY NEED FIX
q=0;

if (Vmp>=12 && Vmp<=24)
    x1 = linterp(Vout1,Eff1,Vout);     
    x2 = linterp(Vout2,Eff2,Vout);    
    Peff = (((24/12)-(Vmp/12))*(x2-x1)+x1)/100;
    disp(Peff)
elseif Vmp>24
    fprintf('ERROR: No data yet exists for this situation')
    Peff = 98/100;
    q=q+1;
    assignin('base','NumberOfTimesVmpExceeds24',q)
elseif Vmp<8
    fprintf('ERROR: Vmp is lower than 6 Volts, MPPT will not turn on')
    Peff=0;
else
    %No data exists for Vmp<12V Assuming a linear decline to 0% efficiency
    %At 6V
    Peff = ((-15.83*(12-Vmp))+95)/100;
    
end