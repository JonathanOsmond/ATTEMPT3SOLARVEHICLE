#include "__cf_SolarArray3MPPT.h"
#ifndef RTW_HEADER_SolarArray3MPPT_acc_types_h_
#define RTW_HEADER_SolarArray3MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct kodnswmzmf_ kodnswmzmf ;
#endif
