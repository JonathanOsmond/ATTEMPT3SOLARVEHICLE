#include "__cf_SolarArray3MPPT.h"
#include "SolarArray3MPPT_acc.h"
#include "SolarArray3MPPT_acc_private.h"
kodnswmzmf dyfxjivegq = { 0.0 , 392.57000000000005 , 353.31300000000005 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
274.79900000000004 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 2.0 , 0.0 , 0.0 } ;
