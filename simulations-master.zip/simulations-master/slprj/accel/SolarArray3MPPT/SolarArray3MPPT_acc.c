#include "__cf_SolarArray3MPPT.h"
#include <math.h>
#include "SolarArray3MPPT_acc.h"
#include "SolarArray3MPPT_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T o0aim5bwqa ;
real_T currentTime ; mgx4xv2rbq * _rtB ; kodnswmzmf * _rtP ; ka4eiu5nz4 *
_rtDW ; _rtDW = ( ( ka4eiu5nz4 * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
kodnswmzmf * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( mgx4xv2rbq * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> jhw0jneul2 [ 0 ] = _rtB -> hbs2wn5fz0 ;
_rtB -> jhw0jneul2 [ 1 ] = 0.0 ; _rtB -> jhw0jneul2 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> cr51jnyedr [ 0 ] = ! ( _rtB ->
jhw0jneul2 [ 0 ] == _rtDW -> cr51jnyedr [ 1 ] ) ; _rtDW -> cr51jnyedr [ 1 ] =
_rtB -> jhw0jneul2 [ 0 ] ; } _rtB -> jhw0jneul2 [ 3 ] = _rtDW -> cr51jnyedr [
0 ] ; _rtB -> nrp2kfmfon [ 0 ] = _rtB -> dtgyudzedg ; _rtB -> nrp2kfmfon [ 1
] = 0.0 ; _rtB -> nrp2kfmfon [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> lcgfawfd4s [ 0 ] = ! ( _rtB -> nrp2kfmfon [ 0 ] == _rtDW ->
lcgfawfd4s [ 1 ] ) ; _rtDW -> lcgfawfd4s [ 1 ] = _rtB -> nrp2kfmfon [ 0 ] ; }
_rtB -> nrp2kfmfon [ 3 ] = _rtDW -> lcgfawfd4s [ 0 ] ; _rtB -> nuuddqqgox [ 0
] = _rtB -> ls2vzwokuz ; _rtB -> nuuddqqgox [ 1 ] = 0.0 ; _rtB -> nuuddqqgox
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> kt4o1r3e4r [ 0 ] = !
( _rtB -> nuuddqqgox [ 0 ] == _rtDW -> kt4o1r3e4r [ 1 ] ) ; _rtDW ->
kt4o1r3e4r [ 1 ] = _rtB -> nuuddqqgox [ 0 ] ; } _rtB -> nuuddqqgox [ 3 ] =
_rtDW -> kt4o1r3e4r [ 0 ] ; _rtB -> hgu0r3oeb0 [ 0 ] = _rtB -> mv0vusfxyp ;
_rtB -> hgu0r3oeb0 [ 1 ] = 0.0 ; _rtB -> hgu0r3oeb0 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> b0jg2y4mty [ 0 ] = ! ( _rtB ->
hgu0r3oeb0 [ 0 ] == _rtDW -> b0jg2y4mty [ 1 ] ) ; _rtDW -> b0jg2y4mty [ 1 ] =
_rtB -> hgu0r3oeb0 [ 0 ] ; } _rtB -> hgu0r3oeb0 [ 3 ] = _rtDW -> b0jg2y4mty [
0 ] ; _rtB -> ed134xttcv [ 0 ] = _rtB -> niyrqdn1ht ; _rtB -> ed134xttcv [ 1
] = 0.0 ; _rtB -> ed134xttcv [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> hdrglqb5ze [ 0 ] = ! ( _rtB -> ed134xttcv [ 0 ] == _rtDW ->
hdrglqb5ze [ 1 ] ) ; _rtDW -> hdrglqb5ze [ 1 ] = _rtB -> ed134xttcv [ 0 ] ; }
_rtB -> ed134xttcv [ 3 ] = _rtDW -> hdrglqb5ze [ 0 ] ; _rtB -> mqe5pes1or [ 0
] = _rtB -> hdofipiz5d ; _rtB -> mqe5pes1or [ 1 ] = 0.0 ; _rtB -> mqe5pes1or
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> mstm3c3bwk [ 0 ] = !
( _rtB -> mqe5pes1or [ 0 ] == _rtDW -> mstm3c3bwk [ 1 ] ) ; _rtDW ->
mstm3c3bwk [ 1 ] = _rtB -> mqe5pes1or [ 0 ] ; } _rtB -> mqe5pes1or [ 3 ] =
_rtDW -> mstm3c3bwk [ 0 ] ; _rtB -> nuqwgqhif2 [ 0 ] = _rtB -> bh5bwp4bqc ;
_rtB -> nuqwgqhif2 [ 1 ] = 0.0 ; _rtB -> nuqwgqhif2 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> kx4yaqjmbq [ 0 ] = ! ( _rtB ->
nuqwgqhif2 [ 0 ] == _rtDW -> kx4yaqjmbq [ 1 ] ) ; _rtDW -> kx4yaqjmbq [ 1 ] =
_rtB -> nuqwgqhif2 [ 0 ] ; } _rtB -> nuqwgqhif2 [ 3 ] = _rtDW -> kx4yaqjmbq [
0 ] ; _rtB -> gixhbsvc04 [ 0 ] = _rtB -> fb4i5sr1k0 ; _rtB -> gixhbsvc04 [ 1
] = 0.0 ; _rtB -> gixhbsvc04 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> fsqwhvm045 [ 0 ] = ! ( _rtB -> gixhbsvc04 [ 0 ] == _rtDW ->
fsqwhvm045 [ 1 ] ) ; _rtDW -> fsqwhvm045 [ 1 ] = _rtB -> gixhbsvc04 [ 0 ] ; }
_rtB -> gixhbsvc04 [ 3 ] = _rtDW -> fsqwhvm045 [ 0 ] ; _rtB -> a2uuimlj3u [ 0
] = _rtB -> cwdbni3abo ; _rtB -> a2uuimlj3u [ 1 ] = 0.0 ; _rtB -> a2uuimlj3u
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> iubpoqczdu [ 0 ] = !
( _rtB -> a2uuimlj3u [ 0 ] == _rtDW -> iubpoqczdu [ 1 ] ) ; _rtDW ->
iubpoqczdu [ 1 ] = _rtB -> a2uuimlj3u [ 0 ] ; } _rtB -> a2uuimlj3u [ 3 ] =
_rtDW -> iubpoqczdu [ 0 ] ; _rtB -> ej05ow2q0h [ 0 ] = _rtB -> hsak53qnwq ;
_rtB -> ej05ow2q0h [ 1 ] = 0.0 ; _rtB -> ej05ow2q0h [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> cyy2ctqkm3 [ 0 ] = ! ( _rtB ->
ej05ow2q0h [ 0 ] == _rtDW -> cyy2ctqkm3 [ 1 ] ) ; _rtDW -> cyy2ctqkm3 [ 1 ] =
_rtB -> ej05ow2q0h [ 0 ] ; } _rtB -> ej05ow2q0h [ 3 ] = _rtDW -> cyy2ctqkm3 [
0 ] ; _rtB -> a5sdh2n2ws [ 0 ] = _rtB -> hsak53qnwq ; _rtB -> a5sdh2n2ws [ 1
] = 0.0 ; _rtB -> a5sdh2n2ws [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> az1o0ipwxf [ 0 ] = ! ( _rtB -> a5sdh2n2ws [ 0 ] == _rtDW ->
az1o0ipwxf [ 1 ] ) ; _rtDW -> az1o0ipwxf [ 1 ] = _rtB -> a5sdh2n2ws [ 0 ] ; }
_rtB -> a5sdh2n2ws [ 3 ] = _rtDW -> az1o0ipwxf [ 0 ] ; _rtB -> mpexy2lary [ 0
] = _rtB -> cwdbni3abo ; _rtB -> mpexy2lary [ 1 ] = 0.0 ; _rtB -> mpexy2lary
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> itdf0dcbkh [ 0 ] = !
( _rtB -> mpexy2lary [ 0 ] == _rtDW -> itdf0dcbkh [ 1 ] ) ; _rtDW ->
itdf0dcbkh [ 1 ] = _rtB -> mpexy2lary [ 0 ] ; } _rtB -> mpexy2lary [ 3 ] =
_rtDW -> itdf0dcbkh [ 0 ] ; _rtB -> j2m4zhxbpi [ 0 ] = _rtB -> fb4i5sr1k0 ;
_rtB -> j2m4zhxbpi [ 1 ] = 0.0 ; _rtB -> j2m4zhxbpi [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> loxhwxrfiq [ 0 ] = ! ( _rtB ->
j2m4zhxbpi [ 0 ] == _rtDW -> loxhwxrfiq [ 1 ] ) ; _rtDW -> loxhwxrfiq [ 1 ] =
_rtB -> j2m4zhxbpi [ 0 ] ; } _rtB -> j2m4zhxbpi [ 3 ] = _rtDW -> loxhwxrfiq [
0 ] ; _rtB -> b5pygy35bl [ 0 ] = _rtB -> nouak3mf10 ; _rtB -> b5pygy35bl [ 1
] = 0.0 ; _rtB -> b5pygy35bl [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> gcuuxozdmx [ 0 ] = ! ( _rtB -> b5pygy35bl [ 0 ] == _rtDW ->
gcuuxozdmx [ 1 ] ) ; _rtDW -> gcuuxozdmx [ 1 ] = _rtB -> b5pygy35bl [ 0 ] ; }
_rtB -> b5pygy35bl [ 3 ] = _rtDW -> gcuuxozdmx [ 0 ] ; _rtB -> gmuhnhstnk [ 0
] = _rtB -> a3gy5z0pyi ; _rtB -> gmuhnhstnk [ 1 ] = 0.0 ; _rtB -> gmuhnhstnk
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> pp13ilzd3w [ 0 ] = !
( _rtB -> gmuhnhstnk [ 0 ] == _rtDW -> pp13ilzd3w [ 1 ] ) ; _rtDW ->
pp13ilzd3w [ 1 ] = _rtB -> gmuhnhstnk [ 0 ] ; } _rtB -> gmuhnhstnk [ 3 ] =
_rtDW -> pp13ilzd3w [ 0 ] ; _rtB -> khjhb1ta1i [ 0 ] = _rtB -> niyrqdn1ht ;
_rtB -> khjhb1ta1i [ 1 ] = 0.0 ; _rtB -> khjhb1ta1i [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> cjjwv5jf13 [ 0 ] = ! ( _rtB ->
khjhb1ta1i [ 0 ] == _rtDW -> cjjwv5jf13 [ 1 ] ) ; _rtDW -> cjjwv5jf13 [ 1 ] =
_rtB -> khjhb1ta1i [ 0 ] ; } _rtB -> khjhb1ta1i [ 3 ] = _rtDW -> cjjwv5jf13 [
0 ] ; _rtB -> k55nbx0uoe [ 0 ] = _rtB -> a3gy5z0pyi ; _rtB -> k55nbx0uoe [ 1
] = 0.0 ; _rtB -> k55nbx0uoe [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> i5h1hpjo3q [ 0 ] = ! ( _rtB -> k55nbx0uoe [ 0 ] == _rtDW ->
i5h1hpjo3q [ 1 ] ) ; _rtDW -> i5h1hpjo3q [ 1 ] = _rtB -> k55nbx0uoe [ 0 ] ; }
_rtB -> k55nbx0uoe [ 3 ] = _rtDW -> i5h1hpjo3q [ 0 ] ; _rtB -> ml1fd1cgzz [ 0
] = _rtB -> nouak3mf10 ; _rtB -> ml1fd1cgzz [ 1 ] = 0.0 ; _rtB -> ml1fd1cgzz
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> lrhq1oqhmb [ 0 ] = !
( _rtB -> ml1fd1cgzz [ 0 ] == _rtDW -> lrhq1oqhmb [ 1 ] ) ; _rtDW ->
lrhq1oqhmb [ 1 ] = _rtB -> ml1fd1cgzz [ 0 ] ; } _rtB -> ml1fd1cgzz [ 3 ] =
_rtDW -> lrhq1oqhmb [ 0 ] ; _rtB -> biucyn5yoh [ 0 ] = _rtB -> avwrmud2mg ;
_rtB -> biucyn5yoh [ 1 ] = 0.0 ; _rtB -> biucyn5yoh [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> per50x1w0a [ 0 ] = ! ( _rtB ->
biucyn5yoh [ 0 ] == _rtDW -> per50x1w0a [ 1 ] ) ; _rtDW -> per50x1w0a [ 1 ] =
_rtB -> biucyn5yoh [ 0 ] ; } _rtB -> biucyn5yoh [ 3 ] = _rtDW -> per50x1w0a [
0 ] ; _rtB -> dr05gq5qmq [ 0 ] = _rtB -> avwrmud2mg ; _rtB -> dr05gq5qmq [ 1
] = 0.0 ; _rtB -> dr05gq5qmq [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> gjyktp2z0z [ 0 ] = ! ( _rtB -> dr05gq5qmq [ 0 ] == _rtDW ->
gjyktp2z0z [ 1 ] ) ; _rtDW -> gjyktp2z0z [ 1 ] = _rtB -> dr05gq5qmq [ 0 ] ; }
_rtB -> dr05gq5qmq [ 3 ] = _rtDW -> gjyktp2z0z [ 0 ] ; _rtB -> kaz22evvuq [ 0
] = _rtB -> hbs2wn5fz0 ; _rtB -> kaz22evvuq [ 1 ] = 0.0 ; _rtB -> kaz22evvuq
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> c5ccf5xntz [ 0 ] = !
( _rtB -> kaz22evvuq [ 0 ] == _rtDW -> c5ccf5xntz [ 1 ] ) ; _rtDW ->
c5ccf5xntz [ 1 ] = _rtB -> kaz22evvuq [ 0 ] ; } _rtB -> kaz22evvuq [ 3 ] =
_rtDW -> c5ccf5xntz [ 0 ] ; _rtB -> plselnbjap [ 0 ] = _rtB -> gbyicchr4j ;
_rtB -> plselnbjap [ 1 ] = 0.0 ; _rtB -> plselnbjap [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> fqosukt0js [ 0 ] = ! ( _rtB ->
plselnbjap [ 0 ] == _rtDW -> fqosukt0js [ 1 ] ) ; _rtDW -> fqosukt0js [ 1 ] =
_rtB -> plselnbjap [ 0 ] ; } _rtB -> plselnbjap [ 3 ] = _rtDW -> fqosukt0js [
0 ] ; _rtB -> pcuygi4pjk [ 0 ] = _rtB -> gbyicchr4j ; _rtB -> pcuygi4pjk [ 1
] = 0.0 ; _rtB -> pcuygi4pjk [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> lpjihap1kr [ 0 ] = ! ( _rtB -> pcuygi4pjk [ 0 ] == _rtDW ->
lpjihap1kr [ 1 ] ) ; _rtDW -> lpjihap1kr [ 1 ] = _rtB -> pcuygi4pjk [ 0 ] ; }
_rtB -> pcuygi4pjk [ 3 ] = _rtDW -> lpjihap1kr [ 0 ] ; _rtB -> mgmgbry5pc [ 0
] = _rtB -> huj5catels ; _rtB -> mgmgbry5pc [ 1 ] = 0.0 ; _rtB -> mgmgbry5pc
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> bb2mhxxvha [ 0 ] = !
( _rtB -> mgmgbry5pc [ 0 ] == _rtDW -> bb2mhxxvha [ 1 ] ) ; _rtDW ->
bb2mhxxvha [ 1 ] = _rtB -> mgmgbry5pc [ 0 ] ; } _rtB -> mgmgbry5pc [ 3 ] =
_rtDW -> bb2mhxxvha [ 0 ] ; _rtB -> oozc0r5a1d [ 0 ] = _rtB -> huj5catels ;
_rtB -> oozc0r5a1d [ 1 ] = 0.0 ; _rtB -> oozc0r5a1d [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> evvogz1klj [ 0 ] = ! ( _rtB ->
oozc0r5a1d [ 0 ] == _rtDW -> evvogz1klj [ 1 ] ) ; _rtDW -> evvogz1klj [ 1 ] =
_rtB -> oozc0r5a1d [ 0 ] ; } _rtB -> oozc0r5a1d [ 3 ] = _rtDW -> evvogz1klj [
0 ] ; _rtB -> hvjqnzu51e [ 0 ] = _rtB -> l0k3jq0msw ; _rtB -> hvjqnzu51e [ 1
] = 0.0 ; _rtB -> hvjqnzu51e [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> dvw5r5dq1f [ 0 ] = ! ( _rtB -> hvjqnzu51e [ 0 ] == _rtDW ->
dvw5r5dq1f [ 1 ] ) ; _rtDW -> dvw5r5dq1f [ 1 ] = _rtB -> hvjqnzu51e [ 0 ] ; }
_rtB -> hvjqnzu51e [ 3 ] = _rtDW -> dvw5r5dq1f [ 0 ] ; _rtB -> gd4aqvvoou [ 0
] = _rtB -> a4pg3sjom5 ; _rtB -> gd4aqvvoou [ 1 ] = 0.0 ; _rtB -> gd4aqvvoou
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> ffmmk3wlha [ 0 ] = !
( _rtB -> gd4aqvvoou [ 0 ] == _rtDW -> ffmmk3wlha [ 1 ] ) ; _rtDW ->
ffmmk3wlha [ 1 ] = _rtB -> gd4aqvvoou [ 0 ] ; } _rtB -> gd4aqvvoou [ 3 ] =
_rtDW -> ffmmk3wlha [ 0 ] ; _rtB -> kddlrltqx0 [ 0 ] = _rtB -> l0k3jq0msw ;
_rtB -> kddlrltqx0 [ 1 ] = 0.0 ; _rtB -> kddlrltqx0 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> gx4dbvvtjr [ 0 ] = ! ( _rtB ->
kddlrltqx0 [ 0 ] == _rtDW -> gx4dbvvtjr [ 1 ] ) ; _rtDW -> gx4dbvvtjr [ 1 ] =
_rtB -> kddlrltqx0 [ 0 ] ; } _rtB -> kddlrltqx0 [ 3 ] = _rtDW -> gx4dbvvtjr [
0 ] ; _rtB -> md1zuras2y [ 0 ] = _rtB -> mm2r0t1sbt ; _rtB -> md1zuras2y [ 1
] = 0.0 ; _rtB -> md1zuras2y [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> m5oz0l4cmq [ 0 ] = ! ( _rtB -> md1zuras2y [ 0 ] == _rtDW ->
m5oz0l4cmq [ 1 ] ) ; _rtDW -> m5oz0l4cmq [ 1 ] = _rtB -> md1zuras2y [ 0 ] ; }
_rtB -> md1zuras2y [ 3 ] = _rtDW -> m5oz0l4cmq [ 0 ] ; _rtB -> bhkyvh2anz [ 0
] = _rtB -> mm2r0t1sbt ; _rtB -> bhkyvh2anz [ 1 ] = 0.0 ; _rtB -> bhkyvh2anz
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> ln2wvlyhzx [ 0 ] = !
( _rtB -> bhkyvh2anz [ 0 ] == _rtDW -> ln2wvlyhzx [ 1 ] ) ; _rtDW ->
ln2wvlyhzx [ 1 ] = _rtB -> bhkyvh2anz [ 0 ] ; } _rtB -> bhkyvh2anz [ 3 ] =
_rtDW -> ln2wvlyhzx [ 0 ] ; _rtB -> nk5ubuvp4k [ 0 ] = _rtB -> dtgyudzedg ;
_rtB -> nk5ubuvp4k [ 1 ] = 0.0 ; _rtB -> nk5ubuvp4k [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> lxofxz112n [ 0 ] = ! ( _rtB ->
nk5ubuvp4k [ 0 ] == _rtDW -> lxofxz112n [ 1 ] ) ; _rtDW -> lxofxz112n [ 1 ] =
_rtB -> nk5ubuvp4k [ 0 ] ; } _rtB -> nk5ubuvp4k [ 3 ] = _rtDW -> lxofxz112n [
0 ] ; _rtB -> ehmjvbt2wo [ 0 ] = _rtB -> m5feanzino ; _rtB -> ehmjvbt2wo [ 1
] = 0.0 ; _rtB -> ehmjvbt2wo [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> oelz3kagjg [ 0 ] = ! ( _rtB -> ehmjvbt2wo [ 0 ] == _rtDW ->
oelz3kagjg [ 1 ] ) ; _rtDW -> oelz3kagjg [ 1 ] = _rtB -> ehmjvbt2wo [ 0 ] ; }
_rtB -> ehmjvbt2wo [ 3 ] = _rtDW -> oelz3kagjg [ 0 ] ; _rtB -> n5bqfych1r [ 0
] = _rtB -> m5feanzino ; _rtB -> n5bqfych1r [ 1 ] = 0.0 ; _rtB -> n5bqfych1r
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> caotf0vieg [ 0 ] = !
( _rtB -> n5bqfych1r [ 0 ] == _rtDW -> caotf0vieg [ 1 ] ) ; _rtDW ->
caotf0vieg [ 1 ] = _rtB -> n5bqfych1r [ 0 ] ; } _rtB -> n5bqfych1r [ 3 ] =
_rtDW -> caotf0vieg [ 0 ] ; _rtB -> nnn1afl5ax [ 0 ] = _rtB -> ls2vzwokuz ;
_rtB -> nnn1afl5ax [ 1 ] = 0.0 ; _rtB -> nnn1afl5ax [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> of1lieuisn [ 0 ] = ! ( _rtB ->
nnn1afl5ax [ 0 ] == _rtDW -> of1lieuisn [ 1 ] ) ; _rtDW -> of1lieuisn [ 1 ] =
_rtB -> nnn1afl5ax [ 0 ] ; } _rtB -> nnn1afl5ax [ 3 ] = _rtDW -> of1lieuisn [
0 ] ; _rtB -> i0vw5gjhpt [ 0 ] = _rtB -> a4pg3sjom5 ; _rtB -> i0vw5gjhpt [ 1
] = 0.0 ; _rtB -> i0vw5gjhpt [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> cb3ddargsh [ 0 ] = ! ( _rtB -> i0vw5gjhpt [ 0 ] == _rtDW ->
cb3ddargsh [ 1 ] ) ; _rtDW -> cb3ddargsh [ 1 ] = _rtB -> i0vw5gjhpt [ 0 ] ; }
_rtB -> i0vw5gjhpt [ 3 ] = _rtDW -> cb3ddargsh [ 0 ] ; _rtB -> h0ans3kduo [ 0
] = _rtB -> mv0vusfxyp ; _rtB -> h0ans3kduo [ 1 ] = 0.0 ; _rtB -> h0ans3kduo
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> jknhboatla [ 0 ] = !
( _rtB -> h0ans3kduo [ 0 ] == _rtDW -> jknhboatla [ 1 ] ) ; _rtDW ->
jknhboatla [ 1 ] = _rtB -> h0ans3kduo [ 0 ] ; } _rtB -> h0ans3kduo [ 3 ] =
_rtDW -> jknhboatla [ 0 ] ; _rtB -> dodruqzu4n [ 0 ] = _rtB -> bh5bwp4bqc ;
_rtB -> dodruqzu4n [ 1 ] = 0.0 ; _rtB -> dodruqzu4n [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> b21f1ohoy3 [ 0 ] = ! ( _rtB ->
dodruqzu4n [ 0 ] == _rtDW -> b21f1ohoy3 [ 1 ] ) ; _rtDW -> b21f1ohoy3 [ 1 ] =
_rtB -> dodruqzu4n [ 0 ] ; } _rtB -> dodruqzu4n [ 3 ] = _rtDW -> b21f1ohoy3 [
0 ] ; _rtB -> gkiih1eplc [ 0 ] = _rtB -> hdofipiz5d ; _rtB -> gkiih1eplc [ 1
] = 0.0 ; _rtB -> gkiih1eplc [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> bzo1qpgncy [ 0 ] = ! ( _rtB -> gkiih1eplc [ 0 ] == _rtDW ->
bzo1qpgncy [ 1 ] ) ; _rtDW -> bzo1qpgncy [ 1 ] = _rtB -> gkiih1eplc [ 0 ] ; }
_rtB -> gkiih1eplc [ 3 ] = _rtDW -> bzo1qpgncy [ 0 ] ; _rtB -> auwbmy3jl4 [ 0
] = _rtB -> do4ul34qld ; _rtB -> auwbmy3jl4 [ 1 ] = 0.0 ; _rtB -> auwbmy3jl4
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> h2lucxffkr [ 0 ] = !
( _rtB -> auwbmy3jl4 [ 0 ] == _rtDW -> h2lucxffkr [ 1 ] ) ; _rtDW ->
h2lucxffkr [ 1 ] = _rtB -> auwbmy3jl4 [ 0 ] ; } _rtB -> auwbmy3jl4 [ 3 ] =
_rtDW -> h2lucxffkr [ 0 ] ; _rtB -> cbnsbv0dle [ 0 ] = _rtB -> do4ul34qld ;
_rtB -> cbnsbv0dle [ 1 ] = 0.0 ; _rtB -> cbnsbv0dle [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> iy3ni0sj3m [ 0 ] = ! ( _rtB ->
cbnsbv0dle [ 0 ] == _rtDW -> iy3ni0sj3m [ 1 ] ) ; _rtDW -> iy3ni0sj3m [ 1 ] =
_rtB -> cbnsbv0dle [ 0 ] ; } _rtB -> cbnsbv0dle [ 3 ] = _rtDW -> iy3ni0sj3m [
0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime = ssGetTaskTime ( S ,
1 ) ; _rtDW -> ocpkpzcgid = ( currentTime >= _rtP -> P_20 ) ; if ( _rtDW ->
ocpkpzcgid == 1 ) { _rtB -> f4etwy4ua5 = _rtP -> P_22 ; } else { _rtB ->
f4etwy4ua5 = _rtP -> P_21 ; } } o0aim5bwqa = ssGetT ( S ) ; _rtB ->
ga2jqizeni = o0aim5bwqa - _rtB -> jf0cf5lc3a ; _rtB -> ez53kjnjid = _rtB ->
f4etwy4ua5 * _rtB -> ga2jqizeni ; _rtB -> lr0cpdxiq3 = _rtB -> ez53kjnjid +
_rtB -> bffotymg4f ; _rtB -> ahzsabfojc [ 0 ] = _rtB -> lr0cpdxiq3 ; _rtB ->
ahzsabfojc [ 1 ] = 0.0 ; _rtB -> ahzsabfojc [ 2 ] = 0.0 ; _rtB -> ahzsabfojc
[ 3 ] = 0.0 ; ssCallAccelRunBlock ( S , 2 , 68 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 2 , 69 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> lfrzvyqfzp [ 0 ] = _rtB -> a4m3iu401p [ 2 ] ; _rtB -> lfrzvyqfzp [ 1
] = _rtB -> a4m3iu401p [ 0 ] ; ssCallAccelRunBlock ( S , 1 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> i4bvxnbzzf [ 0 ] = _rtB -> a4m3iu401p [ 2 ] ;
_rtB -> i4bvxnbzzf [ 1 ] = _rtB -> a4m3iu401p [ 1 ] ; } ssCallAccelRunBlock (
S , 2 , 72 , SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 73 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> icppu2jiri [ 0 ] = _rtB -> a4m3iu401p [ 2 ] ;
_rtB -> icppu2jiri [ 1 ] = _rtB -> a4m3iu401p [ 0 ] ; ssCallAccelRunBlock ( S
, 2 , 75 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) { mgx4xv2rbq * _rtB ; kodnswmzmf
* _rtP ; _rtP = ( ( kodnswmzmf * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
mgx4xv2rbq * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> hbs2wn5fz0 = _rtP -> P_0
; _rtB -> dtgyudzedg = _rtP -> P_1 ; _rtB -> ls2vzwokuz = _rtP -> P_2 ; _rtB
-> mv0vusfxyp = _rtP -> P_3 ; _rtB -> niyrqdn1ht = _rtP -> P_4 ; _rtB ->
hdofipiz5d = _rtP -> P_5 ; _rtB -> bh5bwp4bqc = _rtP -> P_6 ; _rtB ->
fb4i5sr1k0 = _rtP -> P_7 ; _rtB -> cwdbni3abo = _rtP -> P_8 ; _rtB ->
hsak53qnwq = _rtP -> P_9 ; _rtB -> nouak3mf10 = _rtP -> P_10 ; _rtB ->
a3gy5z0pyi = _rtP -> P_11 ; _rtB -> avwrmud2mg = _rtP -> P_12 ; _rtB ->
gbyicchr4j = _rtP -> P_13 ; _rtB -> huj5catels = _rtP -> P_14 ; _rtB ->
l0k3jq0msw = _rtP -> P_15 ; _rtB -> a4pg3sjom5 = _rtP -> P_16 ; _rtB ->
mm2r0t1sbt = _rtP -> P_17 ; _rtB -> m5feanzino = _rtP -> P_18 ; _rtB ->
do4ul34qld = _rtP -> P_19 ; _rtB -> jf0cf5lc3a = _rtP -> P_23 ; _rtB ->
bffotymg4f = _rtP -> P_24 ; UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { mgx4xv2rbq * _rtB ;
_rtB = ( ( mgx4xv2rbq * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 2 , 68 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
68 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
2 , 68 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
68 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { kodnswmzmf * _rtP ;
a4q00rfuw4 * _rtZCSV ; _rtZCSV = ( ( a4q00rfuw4 * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( kodnswmzmf * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
cl4i4kr3lz = ssGetT ( S ) - _rtP -> P_20 ; ssCallAccelRunBlock ( S , 2 , 68 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 1161993599U ) ; ssSetChecksumVal ( S , 1 ,
4029617629U ) ; ssSetChecksumVal ( S , 2 , 4027434483U ) ; ssSetChecksumVal (
S , 3 , 989291096U ) ; { mxArray * slVerStructMat = NULL ; mxArray * slStrMat
= mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == NULL ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
ka4eiu5nz4 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( mgx4xv2rbq ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
kodnswmzmf ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & dyfxjivegq ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( ka4eiu5nz4 ) ) { {
( ( ka4eiu5nz4 * ) ssGetRootDWork ( S ) ) -> ld3awksiki = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
