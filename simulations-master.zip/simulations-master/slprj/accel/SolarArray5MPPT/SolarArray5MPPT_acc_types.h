#include "__cf_SolarArray5MPPT.h"
#ifndef RTW_HEADER_SolarArray5MPPT_acc_types_h_
#define RTW_HEADER_SolarArray5MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct lk0ew1iep3_ lk0ew1iep3 ;
#endif
