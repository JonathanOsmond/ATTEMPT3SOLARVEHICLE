#include "__cf_SolarArray5MPPT.h"
#include "SolarArray5MPPT_acc.h"
#include "SolarArray5MPPT_acc_private.h"
lk0ew1iep3 j0u3vydaz0 = { 392.57 , 353.31300000000005 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 392.57000000000005 , 0.0 , 392.57000000000005 , 392.57000000000005 ,
0.0 , 0.0 , 2.0 , 0.0 , 0.0 } ;
