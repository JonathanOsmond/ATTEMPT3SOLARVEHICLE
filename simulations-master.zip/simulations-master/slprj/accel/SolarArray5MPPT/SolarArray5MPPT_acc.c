#include "__cf_SolarArray5MPPT.h"
#include <math.h>
#include "SolarArray5MPPT_acc.h"
#include "SolarArray5MPPT_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T dnn1qcksnj ;
real_T currentTime ; nt00fl5kzn * _rtB ; lk0ew1iep3 * _rtP ; lpxvc5glao *
_rtDW ; _rtDW = ( ( lpxvc5glao * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
lk0ew1iep3 * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( nt00fl5kzn * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> gj4rc5fflj [ 0 ] = _rtB -> ifpze33yoh ;
_rtB -> gj4rc5fflj [ 1 ] = 0.0 ; _rtB -> gj4rc5fflj [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> j2somzpedf [ 0 ] = ! ( _rtB ->
gj4rc5fflj [ 0 ] == _rtDW -> j2somzpedf [ 1 ] ) ; _rtDW -> j2somzpedf [ 1 ] =
_rtB -> gj4rc5fflj [ 0 ] ; } _rtB -> gj4rc5fflj [ 3 ] = _rtDW -> j2somzpedf [
0 ] ; _rtB -> mpedmloxhh [ 0 ] = _rtB -> ioqcng0scf ; _rtB -> mpedmloxhh [ 1
] = 0.0 ; _rtB -> mpedmloxhh [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> j4mhwou5fj [ 0 ] = ! ( _rtB -> mpedmloxhh [ 0 ] == _rtDW ->
j4mhwou5fj [ 1 ] ) ; _rtDW -> j4mhwou5fj [ 1 ] = _rtB -> mpedmloxhh [ 0 ] ; }
_rtB -> mpedmloxhh [ 3 ] = _rtDW -> j4mhwou5fj [ 0 ] ; _rtB -> hvzxrz3n4o [ 0
] = _rtB -> ny0rb5vtud ; _rtB -> hvzxrz3n4o [ 1 ] = 0.0 ; _rtB -> hvzxrz3n4o
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> bjsgswldz4 [ 0 ] = !
( _rtB -> hvzxrz3n4o [ 0 ] == _rtDW -> bjsgswldz4 [ 1 ] ) ; _rtDW ->
bjsgswldz4 [ 1 ] = _rtB -> hvzxrz3n4o [ 0 ] ; } _rtB -> hvzxrz3n4o [ 3 ] =
_rtDW -> bjsgswldz4 [ 0 ] ; _rtB -> puvqjkayad [ 0 ] = _rtB -> lceqgrmosw ;
_rtB -> puvqjkayad [ 1 ] = 0.0 ; _rtB -> puvqjkayad [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> hzahdgcdf5 [ 0 ] = ! ( _rtB ->
puvqjkayad [ 0 ] == _rtDW -> hzahdgcdf5 [ 1 ] ) ; _rtDW -> hzahdgcdf5 [ 1 ] =
_rtB -> puvqjkayad [ 0 ] ; } _rtB -> puvqjkayad [ 3 ] = _rtDW -> hzahdgcdf5 [
0 ] ; _rtB -> dpjobnj04a [ 0 ] = _rtB -> lceqgrmosw ; _rtB -> dpjobnj04a [ 1
] = 0.0 ; _rtB -> dpjobnj04a [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> d3enfs4ndh [ 0 ] = ! ( _rtB -> dpjobnj04a [ 0 ] == _rtDW ->
d3enfs4ndh [ 1 ] ) ; _rtDW -> d3enfs4ndh [ 1 ] = _rtB -> dpjobnj04a [ 0 ] ; }
_rtB -> dpjobnj04a [ 3 ] = _rtDW -> d3enfs4ndh [ 0 ] ; _rtB -> lpqzql3ggi [ 0
] = _rtB -> ny0rb5vtud ; _rtB -> lpqzql3ggi [ 1 ] = 0.0 ; _rtB -> lpqzql3ggi
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> agyelh3r4d [ 0 ] = !
( _rtB -> lpqzql3ggi [ 0 ] == _rtDW -> agyelh3r4d [ 1 ] ) ; _rtDW ->
agyelh3r4d [ 1 ] = _rtB -> lpqzql3ggi [ 0 ] ; } _rtB -> lpqzql3ggi [ 3 ] =
_rtDW -> agyelh3r4d [ 0 ] ; _rtB -> jdw03x4dq5 [ 0 ] = _rtB -> ioqcng0scf ;
_rtB -> jdw03x4dq5 [ 1 ] = 0.0 ; _rtB -> jdw03x4dq5 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> jqlyswkcwc [ 0 ] = ! ( _rtB ->
jdw03x4dq5 [ 0 ] == _rtDW -> jqlyswkcwc [ 1 ] ) ; _rtDW -> jqlyswkcwc [ 1 ] =
_rtB -> jdw03x4dq5 [ 0 ] ; } _rtB -> jdw03x4dq5 [ 3 ] = _rtDW -> jqlyswkcwc [
0 ] ; _rtB -> gqbcxu15fn [ 0 ] = _rtB -> piqt3tbggf ; _rtB -> gqbcxu15fn [ 1
] = 0.0 ; _rtB -> gqbcxu15fn [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> mc55gda1hr [ 0 ] = ! ( _rtB -> gqbcxu15fn [ 0 ] == _rtDW ->
mc55gda1hr [ 1 ] ) ; _rtDW -> mc55gda1hr [ 1 ] = _rtB -> gqbcxu15fn [ 0 ] ; }
_rtB -> gqbcxu15fn [ 3 ] = _rtDW -> mc55gda1hr [ 0 ] ; _rtB -> bopkrypgrd [ 0
] = _rtB -> aawxy3fm0p ; _rtB -> bopkrypgrd [ 1 ] = 0.0 ; _rtB -> bopkrypgrd
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> odt2rgvhds [ 0 ] = !
( _rtB -> bopkrypgrd [ 0 ] == _rtDW -> odt2rgvhds [ 1 ] ) ; _rtDW ->
odt2rgvhds [ 1 ] = _rtB -> bopkrypgrd [ 0 ] ; } _rtB -> bopkrypgrd [ 3 ] =
_rtDW -> odt2rgvhds [ 0 ] ; _rtB -> opkuaoqfld [ 0 ] = _rtB -> ifpze33yoh ;
_rtB -> opkuaoqfld [ 1 ] = 0.0 ; _rtB -> opkuaoqfld [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> izklpurrkg [ 0 ] = ! ( _rtB ->
opkuaoqfld [ 0 ] == _rtDW -> izklpurrkg [ 1 ] ) ; _rtDW -> izklpurrkg [ 1 ] =
_rtB -> opkuaoqfld [ 0 ] ; } _rtB -> opkuaoqfld [ 3 ] = _rtDW -> izklpurrkg [
0 ] ; _rtB -> k5ev5vlkm5 [ 0 ] = _rtB -> aawxy3fm0p ; _rtB -> k5ev5vlkm5 [ 1
] = 0.0 ; _rtB -> k5ev5vlkm5 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> fxytxervya [ 0 ] = ! ( _rtB -> k5ev5vlkm5 [ 0 ] == _rtDW ->
fxytxervya [ 1 ] ) ; _rtDW -> fxytxervya [ 1 ] = _rtB -> k5ev5vlkm5 [ 0 ] ; }
_rtB -> k5ev5vlkm5 [ 3 ] = _rtDW -> fxytxervya [ 0 ] ; _rtB -> ntjlzwwta2 [ 0
] = _rtB -> piqt3tbggf ; _rtB -> ntjlzwwta2 [ 1 ] = 0.0 ; _rtB -> ntjlzwwta2
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> jxnml2y5zi [ 0 ] = !
( _rtB -> ntjlzwwta2 [ 0 ] == _rtDW -> jxnml2y5zi [ 1 ] ) ; _rtDW ->
jxnml2y5zi [ 1 ] = _rtB -> ntjlzwwta2 [ 0 ] ; } _rtB -> ntjlzwwta2 [ 3 ] =
_rtDW -> jxnml2y5zi [ 0 ] ; _rtB -> fjngzx3yos [ 0 ] = _rtB -> mgtikhiomj ;
_rtB -> fjngzx3yos [ 1 ] = 0.0 ; _rtB -> fjngzx3yos [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> pnrqqqixwy [ 0 ] = ! ( _rtB ->
fjngzx3yos [ 0 ] == _rtDW -> pnrqqqixwy [ 1 ] ) ; _rtDW -> pnrqqqixwy [ 1 ] =
_rtB -> fjngzx3yos [ 0 ] ; } _rtB -> fjngzx3yos [ 3 ] = _rtDW -> pnrqqqixwy [
0 ] ; _rtB -> m3zshgsacb [ 0 ] = _rtB -> mgtikhiomj ; _rtB -> m3zshgsacb [ 1
] = 0.0 ; _rtB -> m3zshgsacb [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> noksg5xmff [ 0 ] = ! ( _rtB -> m3zshgsacb [ 0 ] == _rtDW ->
noksg5xmff [ 1 ] ) ; _rtDW -> noksg5xmff [ 1 ] = _rtB -> m3zshgsacb [ 0 ] ; }
_rtB -> m3zshgsacb [ 3 ] = _rtDW -> noksg5xmff [ 0 ] ; _rtB -> b1kez2xggg [ 0
] = _rtB -> mb4oijokj5 ; _rtB -> b1kez2xggg [ 1 ] = 0.0 ; _rtB -> b1kez2xggg
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> cfaojmmdez [ 0 ] = !
( _rtB -> b1kez2xggg [ 0 ] == _rtDW -> cfaojmmdez [ 1 ] ) ; _rtDW ->
cfaojmmdez [ 1 ] = _rtB -> b1kez2xggg [ 0 ] ; } _rtB -> b1kez2xggg [ 3 ] =
_rtDW -> cfaojmmdez [ 0 ] ; _rtB -> lzamj2f0iv [ 0 ] = _rtB -> mb4oijokj5 ;
_rtB -> lzamj2f0iv [ 1 ] = 0.0 ; _rtB -> lzamj2f0iv [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> lidhfwtddh [ 0 ] = ! ( _rtB ->
lzamj2f0iv [ 0 ] == _rtDW -> lidhfwtddh [ 1 ] ) ; _rtDW -> lidhfwtddh [ 1 ] =
_rtB -> lzamj2f0iv [ 0 ] ; } _rtB -> lzamj2f0iv [ 3 ] = _rtDW -> lidhfwtddh [
0 ] ; _rtB -> enjwdxu5rv [ 0 ] = _rtB -> p1ko31ujcn ; _rtB -> enjwdxu5rv [ 1
] = 0.0 ; _rtB -> enjwdxu5rv [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> i3wzbjpw4r [ 0 ] = ! ( _rtB -> enjwdxu5rv [ 0 ] == _rtDW ->
i3wzbjpw4r [ 1 ] ) ; _rtDW -> i3wzbjpw4r [ 1 ] = _rtB -> enjwdxu5rv [ 0 ] ; }
_rtB -> enjwdxu5rv [ 3 ] = _rtDW -> i3wzbjpw4r [ 0 ] ; _rtB -> hu5pdpzy0e [ 0
] = _rtB -> boexrkmf0w ; _rtB -> hu5pdpzy0e [ 1 ] = 0.0 ; _rtB -> hu5pdpzy0e
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> ffqgguajdj [ 0 ] = !
( _rtB -> hu5pdpzy0e [ 0 ] == _rtDW -> ffqgguajdj [ 1 ] ) ; _rtDW ->
ffqgguajdj [ 1 ] = _rtB -> hu5pdpzy0e [ 0 ] ; } _rtB -> hu5pdpzy0e [ 3 ] =
_rtDW -> ffqgguajdj [ 0 ] ; _rtB -> jtkivxce54 [ 0 ] = _rtB -> p1ko31ujcn ;
_rtB -> jtkivxce54 [ 1 ] = 0.0 ; _rtB -> jtkivxce54 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> ceug1p3m2i [ 0 ] = ! ( _rtB ->
jtkivxce54 [ 0 ] == _rtDW -> ceug1p3m2i [ 1 ] ) ; _rtDW -> ceug1p3m2i [ 1 ] =
_rtB -> jtkivxce54 [ 0 ] ; } _rtB -> jtkivxce54 [ 3 ] = _rtDW -> ceug1p3m2i [
0 ] ; _rtB -> cygbzbeupq [ 0 ] = _rtB -> boexrkmf0w ; _rtB -> cygbzbeupq [ 1
] = 0.0 ; _rtB -> cygbzbeupq [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> oulodpccbw [ 0 ] = ! ( _rtB -> cygbzbeupq [ 0 ] == _rtDW ->
oulodpccbw [ 1 ] ) ; _rtDW -> oulodpccbw [ 1 ] = _rtB -> cygbzbeupq [ 0 ] ; }
_rtB -> cygbzbeupq [ 3 ] = _rtDW -> oulodpccbw [ 0 ] ; _rtB -> lzv3nw4ms4 [ 0
] = _rtB -> hhf4nv21kq ; _rtB -> lzv3nw4ms4 [ 1 ] = 0.0 ; _rtB -> lzv3nw4ms4
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> czhryz433r [ 0 ] = !
( _rtB -> lzv3nw4ms4 [ 0 ] == _rtDW -> czhryz433r [ 1 ] ) ; _rtDW ->
czhryz433r [ 1 ] = _rtB -> lzv3nw4ms4 [ 0 ] ; } _rtB -> lzv3nw4ms4 [ 3 ] =
_rtDW -> czhryz433r [ 0 ] ; _rtB -> ami0jkv45g [ 0 ] = _rtB -> hhf4nv21kq ;
_rtB -> ami0jkv45g [ 1 ] = 0.0 ; _rtB -> ami0jkv45g [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> ctxh1opzge [ 0 ] = ! ( _rtB ->
ami0jkv45g [ 0 ] == _rtDW -> ctxh1opzge [ 1 ] ) ; _rtDW -> ctxh1opzge [ 1 ] =
_rtB -> ami0jkv45g [ 0 ] ; } _rtB -> ami0jkv45g [ 3 ] = _rtDW -> ctxh1opzge [
0 ] ; _rtB -> ct35newecv [ 0 ] = _rtB -> ifpze33yoh ; _rtB -> ct35newecv [ 1
] = 0.0 ; _rtB -> ct35newecv [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> e5fr13eoxk [ 0 ] = ! ( _rtB -> ct35newecv [ 0 ] == _rtDW ->
e5fr13eoxk [ 1 ] ) ; _rtDW -> e5fr13eoxk [ 1 ] = _rtB -> ct35newecv [ 0 ] ; }
_rtB -> ct35newecv [ 3 ] = _rtDW -> e5fr13eoxk [ 0 ] ; _rtB -> eayusvpfqv [ 0
] = _rtB -> ifpze33yoh ; _rtB -> eayusvpfqv [ 1 ] = 0.0 ; _rtB -> eayusvpfqv
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> ge0npai44b [ 0 ] = !
( _rtB -> eayusvpfqv [ 0 ] == _rtDW -> ge0npai44b [ 1 ] ) ; _rtDW ->
ge0npai44b [ 1 ] = _rtB -> eayusvpfqv [ 0 ] ; } _rtB -> eayusvpfqv [ 3 ] =
_rtDW -> ge0npai44b [ 0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime
= ssGetTaskTime ( S , 1 ) ; _rtDW -> emeycgiiik = ( currentTime >= _rtP ->
P_11 ) ; if ( _rtDW -> emeycgiiik == 1 ) { _rtB -> nmmbibrmzw = _rtP -> P_13
; } else { _rtB -> nmmbibrmzw = _rtP -> P_12 ; } } dnn1qcksnj = ssGetT ( S )
; _rtB -> h2sseo1uno = dnn1qcksnj - _rtB -> b2p1ydlck3 ; _rtB -> grw02prx1l =
_rtB -> nmmbibrmzw * _rtB -> h2sseo1uno ; _rtB -> lid4jmbcze = _rtB ->
grw02prx1l + _rtB -> kwrfcegrid ; _rtB -> ieq2gvzdld [ 0 ] = _rtB ->
lid4jmbcze ; _rtB -> ieq2gvzdld [ 1 ] = 0.0 ; _rtB -> ieq2gvzdld [ 2 ] = 0.0
; _rtB -> ieq2gvzdld [ 3 ] = 0.0 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 44 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> np4thyosuu
[ 0 ] = _rtB -> e1wfkf2d3r [ 2 ] ; _rtB -> np4thyosuu [ 1 ] = _rtB ->
e1wfkf2d3r [ 0 ] ; ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> knrz45gjxk [ 0 ] = _rtB -> e1wfkf2d3r [ 2 ] ; _rtB -> knrz45gjxk [ 1
] = _rtB -> e1wfkf2d3r [ 1 ] ; } ssCallAccelRunBlock ( S , 2 , 47 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 48 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> n1rnls4vge [ 0 ] = _rtB -> e1wfkf2d3r [ 2 ] ;
_rtB -> n1rnls4vge [ 1 ] = _rtB -> e1wfkf2d3r [ 0 ] ; ssCallAccelRunBlock ( S
, 2 , 50 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) { nt00fl5kzn * _rtB ; lk0ew1iep3
* _rtP ; _rtP = ( ( lk0ew1iep3 * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
nt00fl5kzn * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> ifpze33yoh = _rtP -> P_0
; _rtB -> ioqcng0scf = _rtP -> P_1 ; _rtB -> ny0rb5vtud = _rtP -> P_2 ; _rtB
-> lceqgrmosw = _rtP -> P_3 ; _rtB -> piqt3tbggf = _rtP -> P_4 ; _rtB ->
aawxy3fm0p = _rtP -> P_5 ; _rtB -> mgtikhiomj = _rtP -> P_6 ; _rtB ->
mb4oijokj5 = _rtP -> P_7 ; _rtB -> p1ko31ujcn = _rtP -> P_8 ; _rtB ->
boexrkmf0w = _rtP -> P_9 ; _rtB -> hhf4nv21kq = _rtP -> P_10 ; _rtB ->
b2p1ydlck3 = _rtP -> P_14 ; _rtB -> kwrfcegrid = _rtP -> P_15 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { nt00fl5kzn * _rtB ;
_rtB = ( ( nt00fl5kzn * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 2 , 43 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
2 , 43 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { lk0ew1iep3 * _rtP ;
a0ylmch2v2 * _rtZCSV ; _rtZCSV = ( ( a0ylmch2v2 * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( lk0ew1iep3 * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
eypx1tevih = ssGetT ( S ) - _rtP -> P_11 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 1646592196U ) ; ssSetChecksumVal ( S , 1 ,
2154260633U ) ; ssSetChecksumVal ( S , 2 , 721992113U ) ; ssSetChecksumVal (
S , 3 , 2383490295U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
lpxvc5glao ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( nt00fl5kzn ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
lk0ew1iep3 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & j0u3vydaz0 ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( lpxvc5glao ) ) { {
( ( lpxvc5glao * ) ssGetRootDWork ( S ) ) -> fecshouk10 = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
