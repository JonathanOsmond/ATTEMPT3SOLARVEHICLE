#include "__cf_SolarArray5MPPT.h"
#ifndef RTW_HEADER_SolarArray5MPPT_acc_h_
#define RTW_HEADER_SolarArray5MPPT_acc_h_
#include <stddef.h>
#ifndef SolarArray5MPPT_acc_COMMON_INCLUDES_
#define SolarArray5MPPT_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SolarArray5MPPT_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T ifpze33yoh ; real_T gj4rc5fflj [ 4 ] ; real_T
ioqcng0scf ; real_T mpedmloxhh [ 4 ] ; real_T ny0rb5vtud ; real_T hvzxrz3n4o
[ 4 ] ; real_T lceqgrmosw ; real_T puvqjkayad [ 4 ] ; real_T dpjobnj04a [ 4 ]
; real_T lpqzql3ggi [ 4 ] ; real_T jdw03x4dq5 [ 4 ] ; real_T piqt3tbggf ;
real_T gqbcxu15fn [ 4 ] ; real_T aawxy3fm0p ; real_T bopkrypgrd [ 4 ] ;
real_T opkuaoqfld [ 4 ] ; real_T k5ev5vlkm5 [ 4 ] ; real_T ntjlzwwta2 [ 4 ] ;
real_T mgtikhiomj ; real_T fjngzx3yos [ 4 ] ; real_T m3zshgsacb [ 4 ] ;
real_T mb4oijokj5 ; real_T b1kez2xggg [ 4 ] ; real_T lzamj2f0iv [ 4 ] ;
real_T p1ko31ujcn ; real_T enjwdxu5rv [ 4 ] ; real_T boexrkmf0w ; real_T
hu5pdpzy0e [ 4 ] ; real_T jtkivxce54 [ 4 ] ; real_T cygbzbeupq [ 4 ] ; real_T
hhf4nv21kq ; real_T lzv3nw4ms4 [ 4 ] ; real_T ami0jkv45g [ 4 ] ; real_T
ct35newecv [ 4 ] ; real_T eayusvpfqv [ 4 ] ; real_T nmmbibrmzw ; real_T
b2p1ydlck3 ; real_T h2sseo1uno ; real_T grw02prx1l ; real_T kwrfcegrid ;
real_T lid4jmbcze ; real_T ieq2gvzdld [ 4 ] ; real_T pm5ai5pwgd [ 221 ] ;
real_T e1wfkf2d3r [ 3 ] ; real_T n1rnls4vge [ 2 ] ; real_T knrz45gjxk [ 2 ] ;
real_T np4thyosuu [ 2 ] ; } nt00fl5kzn ; typedef struct { real_T j2somzpedf [
2 ] ; real_T j4mhwou5fj [ 2 ] ; real_T bjsgswldz4 [ 2 ] ; real_T hzahdgcdf5 [
2 ] ; real_T d3enfs4ndh [ 2 ] ; real_T agyelh3r4d [ 2 ] ; real_T jqlyswkcwc [
2 ] ; real_T mc55gda1hr [ 2 ] ; real_T odt2rgvhds [ 2 ] ; real_T izklpurrkg [
2 ] ; real_T fxytxervya [ 2 ] ; real_T jxnml2y5zi [ 2 ] ; real_T pnrqqqixwy [
2 ] ; real_T noksg5xmff [ 2 ] ; real_T cfaojmmdez [ 2 ] ; real_T lidhfwtddh [
2 ] ; real_T i3wzbjpw4r [ 2 ] ; real_T ffqgguajdj [ 2 ] ; real_T ceug1p3m2i [
2 ] ; real_T oulodpccbw [ 2 ] ; real_T czhryz433r [ 2 ] ; real_T ctxh1opzge [
2 ] ; real_T e5fr13eoxk [ 2 ] ; real_T ge0npai44b [ 2 ] ; real_T fqd05iz1ko [
2 ] ; void * pwgfd1bw3t ; void * mjo3irs3pt ; void * irku4aocux ; void *
apsragafzo ; void * hfxcerxfwa ; void * geape4pcgt ; void * d0mbp3g1pb ; void
* mudhnln1iv ; void * afchcarv51 ; void * jkviawzr0a ; void * jx40bflqhk [ 3
] ; void * nmz2vfvxvb ; void * i4z01se3l1 ; int_T ijrwzeomk5 [ 134 ] ; int_T
emeycgiiik ; int32_T fecshouk10 ; boolean_T f2edpcusth ; boolean_T d1v2lrgsgk
; char_T fulex2qxjr [ 6 ] ; } lpxvc5glao ; typedef struct { real_T iarnbacwja
[ 87 ] ; } f05co3tnvd ; typedef struct { real_T iarnbacwja [ 87 ] ; }
a2cjiq3w3j ; typedef struct { boolean_T iarnbacwja [ 87 ] ; } gzpzeoim4w ;
typedef struct { real_T iarnbacwja [ 87 ] ; } ccwfco124n ; typedef struct {
real_T eypx1tevih ; real_T chljx4byge ; real_T ahtzpdxnqn ; real_T jn3sx4g0w3
; real_T lvuvhe2rt2 ; real_T iche5loftp ; real_T kmgrf0c3mn ; real_T
g013zpy0bz ; real_T ipaq4j0eji ; real_T fl4is55cb3 ; real_T lts43slmyf ;
real_T lgpmyfgjxs ; real_T egygk34whd ; real_T n2d05phkig ; real_T hn2bp3lixf
; real_T ne31c45ftt ; real_T nhxt10zhdc ; real_T kxfilywzun ; real_T
i43o0mtq0r ; real_T brc04fweah ; real_T o0v0ginchq ; real_T ogo5ypb1nr ;
real_T etijpm0pmm ; real_T kbo4lain0s ; real_T pimn2chk15 ; real_T br5fvomjsv
; real_T pnv3r540ij ; real_T ghfcqhwwa4 ; real_T ojidcfi4ui ; real_T
g04fwlcbta ; real_T onfrsqdtba ; real_T luqtszrjmq ; real_T oz4cvudlgv ;
real_T hvc0ezlsaa ; real_T lutzj3siej ; real_T ahjjwzdnza ; real_T a4pus2ffgl
; real_T d5uno3zk0j ; real_T msbnyumw04 ; real_T gu30ylpoxy ; real_T
ajdkrlb4kg ; real_T g55qoqaima ; real_T ezgkkpplhp ; real_T m4l3eeamsa ;
real_T phipnx4x2y ; real_T i54ccssirr ; real_T nfprognpl5 ; real_T irlay1sotw
; real_T iuedhptirz ; real_T ka31oclhox ; real_T k5qwfdc4vk ; real_T
b2232btiop ; real_T ap44emy11w ; real_T ijyvzdjkdt ; real_T joahck5uwz ;
real_T m5k0nkzoom ; real_T n2r3cgc2bu ; real_T bxzvbdyvkt ; real_T neho4xs2ak
; real_T dpfyrk1qgy ; real_T ezcqberff0 ; real_T grqfc1hfan ; real_T
pg2uyvcdvw ; real_T jj0lmc5d0h ; real_T b1gy2t1zdu ; real_T mxnhjb2zgc ;
real_T i3oqk3jguz ; real_T mhwvcbytd2 ; real_T iobbw1wcep ; real_T k5gykvtnd1
; real_T d3dupawlg1 ; real_T hprfwgc322 ; real_T ogwk5thsxv ; real_T
hwtshgw5eo ; real_T ebc5xcokuu ; real_T ng4crazjel ; real_T er43noy02x ;
real_T g0bf5m14bx ; real_T ccrwnoynpy ; real_T cz5mbt4pdc ; real_T abzbzdgj3d
; real_T mr3m2k4avv ; real_T g4r450vnyf ; real_T j3t53rmys1 ; real_T
e4tdofe5m1 ; real_T n2psznv214 ; real_T cvpdu4ilkz ; real_T kefh34trhf ;
real_T jtiorf5s31 ; real_T bg3ugtzlf2 ; real_T cqp11qxdj2 ; real_T ovfkm01pcn
; real_T ey5r2vhnek ; real_T e1u13jzxrg ; real_T jkakalppuo ; real_T
l5k5wczsuz ; real_T fbfx00aatw ; real_T j5twljbear ; real_T p0qilbj4u3 ;
real_T jh4zud2fd3 ; real_T bntx3htejt ; real_T mu4nrxwtob ; real_T pgwas0ywhp
; real_T pcifmcmx0n ; real_T faaryn2dc2 ; real_T lyma013asd ; real_T
n2ao5hhm5k ; real_T osdhsbnd24 ; real_T lzbx5xebec ; real_T l0qohbi1be ;
real_T ggs2fpvo43 ; real_T kcy1i2mupk ; real_T ntqgko5p12 ; real_T jgplzh2bi0
; real_T f1lhc1lnkf ; real_T lygkr0jlev ; real_T ltq3okdr51 ; real_T
ixdzzf2fiw ; real_T nbuekywsdj ; real_T b3zwp4mkuj ; real_T efe5zst1qq ;
real_T cc3ae5fuyp ; real_T ocenh5zrwg ; real_T fqssizeawq ; real_T kxu2hflkbo
; real_T ch0nnxbctu ; real_T metmmw2lus ; real_T n1n5so4jxi ; real_T
bp5in1g3hv ; real_T knmyjlzg4z ; real_T idsk1bpbgu ; real_T hibf3hc5r2 ;
real_T jd305bfupp ; real_T m1g3xlsxhh ; real_T brqezlnp1o ; } a0ylmch2v2 ;
typedef struct { ZCSigState bl3mtguvlg ; ZCSigState nm3rd5jb5k ; ZCSigState
ltvzomcpto ; ZCSigState hvs1530piu ; ZCSigState ghyrv00ylh ; ZCSigState
mbibjkrpud ; ZCSigState onqyvr1ypx ; ZCSigState gtpgdkufnz ; ZCSigState
amnkimc2cc ; ZCSigState dim3ouwomv ; ZCSigState p42le5oaj4 ; ZCSigState
ggjbzn2zzl ; ZCSigState gxkw1bewrp ; ZCSigState k5ewwyakfk ; ZCSigState
gbcvmuk412 ; ZCSigState i3vorv3e5w ; ZCSigState dkgbpespex ; ZCSigState
mcgwomtenc ; ZCSigState m2vqjqk2eq ; ZCSigState cfg5xnci20 ; ZCSigState
bwk1apecq2 ; ZCSigState gvbvqmwyrc ; ZCSigState crot2o0shk ; ZCSigState
dfzqt1qsrn ; ZCSigState jwnkdjil4h ; ZCSigState muqo3n5v5a ; ZCSigState
h5nnerucde ; ZCSigState hku5omgbwz ; ZCSigState hhyv2niqh5 ; ZCSigState
abj40f1wuc ; ZCSigState bmy3xcj4fl ; ZCSigState l203ldgee0 ; ZCSigState
p0ppizanp5 ; ZCSigState mo3dsiuefo ; ZCSigState i4d4wiscw1 ; ZCSigState
dzfgk3vvdz ; ZCSigState ph3j1bqgt5 ; ZCSigState kp5bmvuune ; ZCSigState
mdjcpgm2bc ; ZCSigState msjodfrc4n ; ZCSigState ke0lkmbdvu ; ZCSigState
hcq2gbpgtd ; ZCSigState kxj1sz5s0a ; ZCSigState aren1mlau4 ; ZCSigState
e5ypakbn4g ; ZCSigState fy0uz3h0ni ; ZCSigState norhrqy2m1 ; ZCSigState
hmpmyefx4a ; ZCSigState g1fvg0qvob ; ZCSigState eh0murv5mv ; ZCSigState
f54ovi0p24 ; ZCSigState obw24n3h5i ; ZCSigState i41podfdva ; ZCSigState
j4fcpn4ksm ; ZCSigState eqlvzwljmd ; ZCSigState mxb3q5ydu2 ; ZCSigState
mdihw5plai ; ZCSigState k2igpwaaxo ; ZCSigState lq5fthmm0u ; ZCSigState
dmuwhsth3r ; ZCSigState ntcvwt35gh ; ZCSigState iclorxdn2y ; ZCSigState
nfwkafvngf ; ZCSigState bs5f0ppaxk ; ZCSigState ph5k00a1f2 ; ZCSigState
izha1r0ngg ; ZCSigState mnw3pginiv ; ZCSigState lg5s4ot3na ; ZCSigState
jdfu1a5ddr ; ZCSigState ollg3xzuvd ; ZCSigState getwoo05fm ; ZCSigState
ndvvrgx1ft ; ZCSigState llaa1u0ijh ; ZCSigState kzcoociuea ; ZCSigState
mf0h3i4i0t ; ZCSigState exmtynkfrr ; ZCSigState launkpysim ; ZCSigState
c44j4ewrmh ; ZCSigState jgfj1nx1ud ; ZCSigState bj4zhllqlv ; ZCSigState
msu2z0afl0 ; ZCSigState e1ahy1odtl ; ZCSigState ahrwlcpi0s ; ZCSigState
p4ikrgs4me ; ZCSigState elr0hpylde ; ZCSigState gpbauf4szi ; ZCSigState
fyfbojfrxu ; ZCSigState bqgvf2gf5h ; ZCSigState f25qd4zq45 ; ZCSigState
lybp1zulq2 ; ZCSigState flrsszbrb2 ; ZCSigState n0jppr1cso ; ZCSigState
msn34xmshv ; ZCSigState pete3glft4 ; ZCSigState covduk0dsy ; ZCSigState
lgnn2wzrbe ; ZCSigState ifsytgwx5m ; ZCSigState naxmnqbz3s ; ZCSigState
nsbu5n43xo ; ZCSigState ookiei0tbw ; ZCSigState atfgzmccle ; ZCSigState
mmwn0zqmo0 ; ZCSigState dlh4zakmdf ; ZCSigState c45hqzbrco ; ZCSigState
j51eohdoqj ; ZCSigState kdangvvnon ; ZCSigState bhk0mpxyfv ; ZCSigState
aljcod2iie ; ZCSigState ppivbshjjv ; ZCSigState d5rxsk1ct3 ; ZCSigState
e4gbwkuvhw ; ZCSigState khjq0gttf5 ; ZCSigState hmc3l4uqu3 ; ZCSigState
hv1x40ua1y ; ZCSigState hkoga5zmko ; ZCSigState lrpgrgu0a2 ; ZCSigState
gdq0mgum13 ; ZCSigState cjdytnfmer ; ZCSigState l4vc0utohr ; ZCSigState
gag14rh4j5 ; ZCSigState eej4pjtpq1 ; ZCSigState obs25vwevk ; ZCSigState
oidqdmcf1r ; ZCSigState an44cf0gcs ; ZCSigState dtexgljrmb ; ZCSigState
gyddtghqyb ; ZCSigState n55oqnhbtw ; ZCSigState dv4t5pmmj1 ; ZCSigState
ckhrqx3sut ; ZCSigState hvjn10oyo2 ; ZCSigState iardad4vcp ; ZCSigState
j1iradof3x ; ZCSigState hio2huko0h ; ZCSigState pivyz5x0hp ; ZCSigState
ngy2bcoq3p ; } j0uajmf4pv ; typedef struct { int_T ir [ 1 ] ; int_T jc [ 87 +
1 ] ; real_T pr [ 1 ] ; } de0sfcyowr ; struct lk0ew1iep3_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; } ; extern lk0ew1iep3
j0u3vydaz0 ;
#endif
