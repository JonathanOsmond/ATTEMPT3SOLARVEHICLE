#include "__cf_SolarArray_5MPPT.h"
#ifndef RTW_HEADER_SolarArray_5MPPT_acc_h_
#define RTW_HEADER_SolarArray_5MPPT_acc_h_
#include <stddef.h>
#ifndef SolarArray_5MPPT_acc_COMMON_INCLUDES_
#define SolarArray_5MPPT_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SolarArray_5MPPT_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T lytyffj4w0 ; real_T pdrmibpcun [ 4 ] ; real_T
ny1cvtpsrl ; real_T esnzxjueac [ 4 ] ; real_T c2zwf4ztz2 ; real_T mp4yfyfohm
[ 4 ] ; real_T ocrden5vxs ; real_T ntnp123zh1 [ 4 ] ; real_T fv2wt2hbxn [ 4 ]
; real_T lrvg2rsbqa [ 4 ] ; real_T o30wssovj1 [ 4 ] ; real_T mmcvzdyndf ;
real_T esqghrw1f4 [ 4 ] ; real_T iswdnswhaw ; real_T mcnmep2d0q [ 4 ] ;
real_T od01h0hpn3 [ 4 ] ; real_T ciz14es2qd [ 4 ] ; real_T gbf4bmqst3 [ 4 ] ;
real_T ftitnzr24s ; real_T bqhnciid2p [ 4 ] ; real_T mnk1j5m2u2 [ 4 ] ;
real_T me22bk5wua ; real_T p2nfmzosfs [ 4 ] ; real_T dz53u4y5l3 [ 4 ] ;
real_T ndnwklv2ar ; real_T eqfjw3x3ov [ 4 ] ; real_T fvn4xpfdgf ; real_T
pcpkaefzls [ 4 ] ; real_T bwkunclwvk [ 4 ] ; real_T cv4xmvltde [ 4 ] ; real_T
dgcjtztuaz ; real_T iitewf0bav [ 4 ] ; real_T ophbssgh1y [ 4 ] ; real_T
cuzn1nf4h4 [ 4 ] ; real_T l22ddvxy55 [ 4 ] ; real_T dlczxig5c3 ; real_T
alhh5sp42l ; real_T nwebnmqngt ; real_T orptn4t0xa ; real_T kegng3vlcz ;
real_T awqmzon2xj ; real_T kovb1rljo1 [ 4 ] ; real_T j5xa0gaig0 [ 221 ] ;
real_T iwbuyatmgo [ 3 ] ; real_T hzxlfztnyk [ 2 ] ; real_T h0t3fary0z [ 2 ] ;
real_T oeprmtj04h [ 2 ] ; } oqkgxcf4za ; typedef struct { real_T i40lgkgyaf [
2 ] ; real_T piseld1o4a [ 2 ] ; real_T p0ahmu5pfd [ 2 ] ; real_T i3k21htbkg [
2 ] ; real_T petdpe3e05 [ 2 ] ; real_T i1hnw0obka [ 2 ] ; real_T efl4u14zmq [
2 ] ; real_T f2ehckzlxr [ 2 ] ; real_T o042aj131u [ 2 ] ; real_T c5q02zub1g [
2 ] ; real_T aheetf2rmo [ 2 ] ; real_T p4fo3eni0n [ 2 ] ; real_T eon01h12gq [
2 ] ; real_T c1uh5ir33e [ 2 ] ; real_T odhmncpoka [ 2 ] ; real_T hkkgg0zsus [
2 ] ; real_T jd4kmptglz [ 2 ] ; real_T cykf34nruq [ 2 ] ; real_T acl0loxhr1 [
2 ] ; real_T pxk4qa2bci [ 2 ] ; real_T gya3bwtiuh [ 2 ] ; real_T jfno1y5p2j [
2 ] ; real_T ooe2cthozw [ 2 ] ; real_T hnrasxyo3k [ 2 ] ; real_T fsemik3hrm [
2 ] ; void * kubwnmfadn ; void * pimtrh0ywq ; void * pec2apkorr ; void *
m5tzy0kgle ; void * dfwm0fe310 ; void * ioxwka0fr2 ; void * izojow52fp ; void
* ajrfqz2xoz ; void * ajwzq10fnt ; void * je3lfj4v5s ; void * njfkrqsfpq [ 3
] ; void * c1yvftkhld ; void * laaatneeif ; int_T gwmyqfwr4x [ 134 ] ; int_T
gt1wog5nfj ; int32_T bxxpjriogo ; boolean_T fm0kuvespe ; boolean_T bw4foclxqt
; char_T opcmhxoczb [ 6 ] ; } c2yuaepbs4 ; typedef struct { real_T gdo13n51mr
[ 87 ] ; } hnd132xv1u ; typedef struct { real_T gdo13n51mr [ 87 ] ; }
eqqsn1xa3o ; typedef struct { boolean_T gdo13n51mr [ 87 ] ; } f3vwmjhj0z ;
typedef struct { real_T gdo13n51mr [ 87 ] ; } nnfhx2sdnl ; typedef struct {
real_T b10dx3vguh ; real_T ktfe4gg5h5 ; real_T jjwgb4cwca ; real_T n2eymihded
; real_T jku4kqjqif ; real_T hclh5rxvrl ; real_T nbe03urj5e ; real_T
ffrknocuhw ; real_T ps2e1l0dt4 ; real_T o4cprn42bs ; real_T njssgqbqfc ;
real_T fmvtmoygci ; real_T doznrzj0tx ; real_T llip2jqiz5 ; real_T ngerfldvs0
; real_T k1e45ewv1j ; real_T b53hsoubd2 ; real_T jey135rhpz ; real_T
prfzdv22fc ; real_T gxblbipkhv ; real_T nwxlhx04sy ; real_T nvz3tmhfia ;
real_T m2tyexobry ; real_T dzb34022mx ; real_T npieaslf1x ; real_T p0ldujiway
; real_T prkbnnhbcb ; real_T byt0viorwv ; real_T ehjhwmaahd ; real_T
pwg3hdsnba ; real_T pzfkyi3unx ; real_T a0epbgzgdk ; real_T ot5bmuns2g ;
real_T ej0ml1evhx ; real_T ahjkdz2052 ; real_T i1p4xyb1gs ; real_T ekmx5p2rpf
; real_T kqj0rgpqin ; real_T cx4e2kkejd ; real_T htx02rkire ; real_T
copoc2jvd4 ; real_T euh3wad2vt ; real_T lbgv4cvwgi ; real_T i4vy1w5qal ;
real_T grhqeaesvy ; real_T gnybjdtdmg ; real_T afrmeren1e ; real_T hk0tsju0ga
; real_T pqhbkdgtuy ; real_T cga1q1c3t5 ; real_T l25tid4sxe ; real_T
hsjsk5kxba ; real_T irwy2jkaon ; real_T gmw0x3qxiu ; real_T lfqxrtfeyy ;
real_T ogewo4f1ow ; real_T eakca2zvcv ; real_T pvxivkruv2 ; real_T fkii2zjyj2
; real_T koqokh1nvg ; real_T f4qixwrfub ; real_T m1q1sayyza ; real_T
o5dzbf5ic3 ; real_T ieihuquvlu ; real_T p1352fwwp2 ; real_T e3bqct1ooa ;
real_T pioaqz1len ; real_T pvvevciy23 ; real_T lr2propzmh ; real_T muk3j4cmb2
; real_T a1yhzelc1t ; real_T iz2wbkjgkh ; real_T a51arwwvs3 ; real_T
lctawgpdxx ; real_T ghdvrseace ; real_T l3fp02tnbt ; real_T pr3hdtar1g ;
real_T goqdhjnxxx ; real_T hpb4etm5d1 ; real_T nmwdnzuhkv ; real_T blwvjbm1l2
; real_T n5j4ga5ik4 ; real_T denkhhsnzo ; real_T omvfd05jxp ; real_T
k5kys5gx1m ; real_T jha4xxgcnm ; real_T ardwywq1wz ; real_T aw1xcwsq5o ;
real_T kowg22zjmu ; real_T kest003fni ; real_T oaebrgll14 ; real_T hpa4ykntky
; real_T bo4nkbnayz ; real_T ievqonnoys ; real_T nt3c31tb0w ; real_T
hv23budwxn ; real_T ibv34viehp ; real_T mgkaf44qp4 ; real_T jxiepdt54u ;
real_T auhlg2we5n ; real_T py3ddjsm4b ; real_T hnvg4lwtke ; real_T cznv4s1j2o
; real_T chr1aolbaq ; real_T m4jcfeu2cb ; real_T dx2izaf54c ; real_T
lybzswclje ; real_T a1fb4ay4w0 ; real_T oq0gve432n ; real_T opau40zfao ;
real_T iev1px0r32 ; real_T izr1cwjzy0 ; real_T fjug4qusdr ; real_T dq23n2wxlm
; real_T hvdp53mset ; real_T gzrajnlwvx ; real_T fuwmdgc1dp ; real_T
kf5oaz4qfa ; real_T lwhq2wz2fz ; real_T l1pr2rhspy ; real_T jrxi3fwbfo ;
real_T dewdn4aaiw ; real_T gijvzd2zvc ; real_T ilcs1auaik ; real_T pvjmvu04lg
; real_T efa1ma2nli ; real_T gynd2qtkb5 ; real_T hd0hgesvb2 ; real_T
jllkr4zqlg ; real_T lbdorkanot ; real_T evcf0nhd4c ; real_T j03ccsxlwa ;
real_T mszkrz2ied ; real_T e15pzrsi4l ; real_T joiio1moon ; } f0f0vksdcq ;
typedef struct { ZCSigState dohxyqilrg ; ZCSigState delbxi3z4j ; ZCSigState
pacdue3pb5 ; ZCSigState o3yuweql3q ; ZCSigState dkgaoqd4yc ; ZCSigState
kycjkw2jjw ; ZCSigState a2wgye3fjy ; ZCSigState hdvkofv0vk ; ZCSigState
fpt1mvust5 ; ZCSigState goadht1zjq ; ZCSigState f1dorzrozo ; ZCSigState
kq43pmmdqo ; ZCSigState mzoifyjwz3 ; ZCSigState ak0oyennn4 ; ZCSigState
gy1drj4da2 ; ZCSigState o02xfvuf1w ; ZCSigState ov1bnvqi3v ; ZCSigState
ltoihnvqyq ; ZCSigState p0p2rcout5 ; ZCSigState bo44ocet10 ; ZCSigState
pvrdot1dr3 ; ZCSigState pc3iq2ig1g ; ZCSigState ggfeu2dmri ; ZCSigState
jnaxkezzt0 ; ZCSigState n3ua43ldub ; ZCSigState b2lvm1sd2h ; ZCSigState
gzv4skv1tt ; ZCSigState mk001ddhqa ; ZCSigState mv1v5roqnw ; ZCSigState
m0r0wwbydt ; ZCSigState abmwnddmnu ; ZCSigState k2tjviyle0 ; ZCSigState
h2p1r1malo ; ZCSigState muvwjeaopd ; ZCSigState hynjjh3sn0 ; ZCSigState
axdzcjd410 ; ZCSigState luljj4oqaj ; ZCSigState nekmdwbt5b ; ZCSigState
c5oitin4zs ; ZCSigState okm5pbv4kr ; ZCSigState mdrqeoftyh ; ZCSigState
fsjxwi5und ; ZCSigState oogehjam0s ; ZCSigState cbq3my5uyr ; ZCSigState
nxz1m2dtqs ; ZCSigState cus3a13v0p ; ZCSigState mfwrbbwi1c ; ZCSigState
pvlqsladga ; ZCSigState jsjreh0q3u ; ZCSigState eywc4wz0tw ; ZCSigState
pgozkhscjf ; ZCSigState gazijirdd4 ; ZCSigState cxkcnobfqt ; ZCSigState
pdyizlq5fp ; ZCSigState nqbisgdkii ; ZCSigState izm52sdp5v ; ZCSigState
gtxopokhsv ; ZCSigState kbw2wzheku ; ZCSigState kags3a0hp3 ; ZCSigState
jyqcvvvnro ; ZCSigState pjwtuf10v3 ; ZCSigState ccap4axhus ; ZCSigState
l0mjq0urqo ; ZCSigState pe2q0e22ym ; ZCSigState mgx5gsx4gy ; ZCSigState
gkojyqztwc ; ZCSigState fdidgysyv0 ; ZCSigState pg0aihv1su ; ZCSigState
h0kdtc3tkq ; ZCSigState dowbqerds0 ; ZCSigState imz5gicnmv ; ZCSigState
amhfqtqds2 ; ZCSigState mqsvoqtxrl ; ZCSigState om25nsr4un ; ZCSigState
poot2eybc0 ; ZCSigState jyrxvnsrv4 ; ZCSigState c5nyfrnw4u ; ZCSigState
i4x11tzec5 ; ZCSigState pbfs4ephvu ; ZCSigState ek5fqcwanj ; ZCSigState
h4tphxx5m1 ; ZCSigState acz24m21er ; ZCSigState bscnn0bnrp ; ZCSigState
oz1aw33ika ; ZCSigState eaqrhsusiz ; ZCSigState iecyobjgbf ; ZCSigState
jbvrvrr35f ; ZCSigState frvtzwew4a ; ZCSigState oqj2n3lg3g ; ZCSigState
fryaaowrhq ; ZCSigState nvaptocqog ; ZCSigState mlinecckzk ; ZCSigState
evvil1ehgn ; ZCSigState oymn1w1v5h ; ZCSigState pnj5he0g3t ; ZCSigState
lk10gqe4ep ; ZCSigState btcnu2wnv2 ; ZCSigState c1cjnqliuc ; ZCSigState
mshzwnxkd0 ; ZCSigState gizgetsj3s ; ZCSigState bmtn2aoddf ; ZCSigState
ohm1tgd2v3 ; ZCSigState lniovzsjmd ; ZCSigState dpvgq2bj0z ; ZCSigState
dfaybivowu ; ZCSigState adlvarau3k ; ZCSigState a5p5hz344m ; ZCSigState
epeyuzlb1l ; ZCSigState jfesilyeip ; ZCSigState jrr0evpk3x ; ZCSigState
ek1rjop3lm ; ZCSigState lnxztfo5pv ; ZCSigState chhyopzep1 ; ZCSigState
nfnm0cgsfs ; ZCSigState bhbvktnpn3 ; ZCSigState l3t4dqsh30 ; ZCSigState
hdb0v4zn50 ; ZCSigState ivtvmyd1ms ; ZCSigState ab02v4m12m ; ZCSigState
fc1rperckq ; ZCSigState d3gzruzbvx ; ZCSigState gc03tzqn5e ; ZCSigState
hlpf0y5qmy ; ZCSigState moxv1keviv ; ZCSigState b52zlpy4bm ; ZCSigState
oe35utogec ; ZCSigState ak3zz3ubxh ; ZCSigState aze4vyuwne ; ZCSigState
lqde3k1zvl ; ZCSigState mr1cqtv3yt ; ZCSigState h2tihqivho ; ZCSigState
om0ba4hjmy ; ZCSigState eo21xettr1 ; ZCSigState dg1trus0xq ; ZCSigState
gxdilvaok3 ; } ok5g4g5yuk ; typedef struct { int_T ir [ 1 ] ; int_T jc [ 87 +
1 ] ; real_T pr [ 1 ] ; } bahvnke1g4 ; struct ecnpgld541_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; } ; extern ecnpgld541
lbsf31scam ;
#endif
