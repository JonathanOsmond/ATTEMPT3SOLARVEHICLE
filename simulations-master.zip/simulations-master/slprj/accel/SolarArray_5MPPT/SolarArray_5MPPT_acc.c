#include "__cf_SolarArray_5MPPT.h"
#include <math.h>
#include "SolarArray_5MPPT_acc.h"
#include "SolarArray_5MPPT_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T oohoiua0m4 ;
real_T currentTime ; oqkgxcf4za * _rtB ; ecnpgld541 * _rtP ; c2yuaepbs4 *
_rtDW ; _rtDW = ( ( c2yuaepbs4 * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
ecnpgld541 * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( oqkgxcf4za * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> pdrmibpcun [ 0 ] = _rtB -> lytyffj4w0 ;
_rtB -> pdrmibpcun [ 1 ] = 0.0 ; _rtB -> pdrmibpcun [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> i40lgkgyaf [ 0 ] = ! ( _rtB ->
pdrmibpcun [ 0 ] == _rtDW -> i40lgkgyaf [ 1 ] ) ; _rtDW -> i40lgkgyaf [ 1 ] =
_rtB -> pdrmibpcun [ 0 ] ; } _rtB -> pdrmibpcun [ 3 ] = _rtDW -> i40lgkgyaf [
0 ] ; _rtB -> esnzxjueac [ 0 ] = _rtB -> ny1cvtpsrl ; _rtB -> esnzxjueac [ 1
] = 0.0 ; _rtB -> esnzxjueac [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> piseld1o4a [ 0 ] = ! ( _rtB -> esnzxjueac [ 0 ] == _rtDW ->
piseld1o4a [ 1 ] ) ; _rtDW -> piseld1o4a [ 1 ] = _rtB -> esnzxjueac [ 0 ] ; }
_rtB -> esnzxjueac [ 3 ] = _rtDW -> piseld1o4a [ 0 ] ; _rtB -> mp4yfyfohm [ 0
] = _rtB -> c2zwf4ztz2 ; _rtB -> mp4yfyfohm [ 1 ] = 0.0 ; _rtB -> mp4yfyfohm
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> p0ahmu5pfd [ 0 ] = !
( _rtB -> mp4yfyfohm [ 0 ] == _rtDW -> p0ahmu5pfd [ 1 ] ) ; _rtDW ->
p0ahmu5pfd [ 1 ] = _rtB -> mp4yfyfohm [ 0 ] ; } _rtB -> mp4yfyfohm [ 3 ] =
_rtDW -> p0ahmu5pfd [ 0 ] ; _rtB -> ntnp123zh1 [ 0 ] = _rtB -> ocrden5vxs ;
_rtB -> ntnp123zh1 [ 1 ] = 0.0 ; _rtB -> ntnp123zh1 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> i3k21htbkg [ 0 ] = ! ( _rtB ->
ntnp123zh1 [ 0 ] == _rtDW -> i3k21htbkg [ 1 ] ) ; _rtDW -> i3k21htbkg [ 1 ] =
_rtB -> ntnp123zh1 [ 0 ] ; } _rtB -> ntnp123zh1 [ 3 ] = _rtDW -> i3k21htbkg [
0 ] ; _rtB -> fv2wt2hbxn [ 0 ] = _rtB -> ocrden5vxs ; _rtB -> fv2wt2hbxn [ 1
] = 0.0 ; _rtB -> fv2wt2hbxn [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> petdpe3e05 [ 0 ] = ! ( _rtB -> fv2wt2hbxn [ 0 ] == _rtDW ->
petdpe3e05 [ 1 ] ) ; _rtDW -> petdpe3e05 [ 1 ] = _rtB -> fv2wt2hbxn [ 0 ] ; }
_rtB -> fv2wt2hbxn [ 3 ] = _rtDW -> petdpe3e05 [ 0 ] ; _rtB -> lrvg2rsbqa [ 0
] = _rtB -> c2zwf4ztz2 ; _rtB -> lrvg2rsbqa [ 1 ] = 0.0 ; _rtB -> lrvg2rsbqa
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> i1hnw0obka [ 0 ] = !
( _rtB -> lrvg2rsbqa [ 0 ] == _rtDW -> i1hnw0obka [ 1 ] ) ; _rtDW ->
i1hnw0obka [ 1 ] = _rtB -> lrvg2rsbqa [ 0 ] ; } _rtB -> lrvg2rsbqa [ 3 ] =
_rtDW -> i1hnw0obka [ 0 ] ; _rtB -> o30wssovj1 [ 0 ] = _rtB -> ny1cvtpsrl ;
_rtB -> o30wssovj1 [ 1 ] = 0.0 ; _rtB -> o30wssovj1 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> efl4u14zmq [ 0 ] = ! ( _rtB ->
o30wssovj1 [ 0 ] == _rtDW -> efl4u14zmq [ 1 ] ) ; _rtDW -> efl4u14zmq [ 1 ] =
_rtB -> o30wssovj1 [ 0 ] ; } _rtB -> o30wssovj1 [ 3 ] = _rtDW -> efl4u14zmq [
0 ] ; _rtB -> esqghrw1f4 [ 0 ] = _rtB -> mmcvzdyndf ; _rtB -> esqghrw1f4 [ 1
] = 0.0 ; _rtB -> esqghrw1f4 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> f2ehckzlxr [ 0 ] = ! ( _rtB -> esqghrw1f4 [ 0 ] == _rtDW ->
f2ehckzlxr [ 1 ] ) ; _rtDW -> f2ehckzlxr [ 1 ] = _rtB -> esqghrw1f4 [ 0 ] ; }
_rtB -> esqghrw1f4 [ 3 ] = _rtDW -> f2ehckzlxr [ 0 ] ; _rtB -> mcnmep2d0q [ 0
] = _rtB -> iswdnswhaw ; _rtB -> mcnmep2d0q [ 1 ] = 0.0 ; _rtB -> mcnmep2d0q
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> o042aj131u [ 0 ] = !
( _rtB -> mcnmep2d0q [ 0 ] == _rtDW -> o042aj131u [ 1 ] ) ; _rtDW ->
o042aj131u [ 1 ] = _rtB -> mcnmep2d0q [ 0 ] ; } _rtB -> mcnmep2d0q [ 3 ] =
_rtDW -> o042aj131u [ 0 ] ; _rtB -> od01h0hpn3 [ 0 ] = _rtB -> lytyffj4w0 ;
_rtB -> od01h0hpn3 [ 1 ] = 0.0 ; _rtB -> od01h0hpn3 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> c5q02zub1g [ 0 ] = ! ( _rtB ->
od01h0hpn3 [ 0 ] == _rtDW -> c5q02zub1g [ 1 ] ) ; _rtDW -> c5q02zub1g [ 1 ] =
_rtB -> od01h0hpn3 [ 0 ] ; } _rtB -> od01h0hpn3 [ 3 ] = _rtDW -> c5q02zub1g [
0 ] ; _rtB -> ciz14es2qd [ 0 ] = _rtB -> iswdnswhaw ; _rtB -> ciz14es2qd [ 1
] = 0.0 ; _rtB -> ciz14es2qd [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> aheetf2rmo [ 0 ] = ! ( _rtB -> ciz14es2qd [ 0 ] == _rtDW ->
aheetf2rmo [ 1 ] ) ; _rtDW -> aheetf2rmo [ 1 ] = _rtB -> ciz14es2qd [ 0 ] ; }
_rtB -> ciz14es2qd [ 3 ] = _rtDW -> aheetf2rmo [ 0 ] ; _rtB -> gbf4bmqst3 [ 0
] = _rtB -> mmcvzdyndf ; _rtB -> gbf4bmqst3 [ 1 ] = 0.0 ; _rtB -> gbf4bmqst3
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> p4fo3eni0n [ 0 ] = !
( _rtB -> gbf4bmqst3 [ 0 ] == _rtDW -> p4fo3eni0n [ 1 ] ) ; _rtDW ->
p4fo3eni0n [ 1 ] = _rtB -> gbf4bmqst3 [ 0 ] ; } _rtB -> gbf4bmqst3 [ 3 ] =
_rtDW -> p4fo3eni0n [ 0 ] ; _rtB -> bqhnciid2p [ 0 ] = _rtB -> ftitnzr24s ;
_rtB -> bqhnciid2p [ 1 ] = 0.0 ; _rtB -> bqhnciid2p [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> eon01h12gq [ 0 ] = ! ( _rtB ->
bqhnciid2p [ 0 ] == _rtDW -> eon01h12gq [ 1 ] ) ; _rtDW -> eon01h12gq [ 1 ] =
_rtB -> bqhnciid2p [ 0 ] ; } _rtB -> bqhnciid2p [ 3 ] = _rtDW -> eon01h12gq [
0 ] ; _rtB -> mnk1j5m2u2 [ 0 ] = _rtB -> ftitnzr24s ; _rtB -> mnk1j5m2u2 [ 1
] = 0.0 ; _rtB -> mnk1j5m2u2 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> c1uh5ir33e [ 0 ] = ! ( _rtB -> mnk1j5m2u2 [ 0 ] == _rtDW ->
c1uh5ir33e [ 1 ] ) ; _rtDW -> c1uh5ir33e [ 1 ] = _rtB -> mnk1j5m2u2 [ 0 ] ; }
_rtB -> mnk1j5m2u2 [ 3 ] = _rtDW -> c1uh5ir33e [ 0 ] ; _rtB -> p2nfmzosfs [ 0
] = _rtB -> me22bk5wua ; _rtB -> p2nfmzosfs [ 1 ] = 0.0 ; _rtB -> p2nfmzosfs
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> odhmncpoka [ 0 ] = !
( _rtB -> p2nfmzosfs [ 0 ] == _rtDW -> odhmncpoka [ 1 ] ) ; _rtDW ->
odhmncpoka [ 1 ] = _rtB -> p2nfmzosfs [ 0 ] ; } _rtB -> p2nfmzosfs [ 3 ] =
_rtDW -> odhmncpoka [ 0 ] ; _rtB -> dz53u4y5l3 [ 0 ] = _rtB -> me22bk5wua ;
_rtB -> dz53u4y5l3 [ 1 ] = 0.0 ; _rtB -> dz53u4y5l3 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> hkkgg0zsus [ 0 ] = ! ( _rtB ->
dz53u4y5l3 [ 0 ] == _rtDW -> hkkgg0zsus [ 1 ] ) ; _rtDW -> hkkgg0zsus [ 1 ] =
_rtB -> dz53u4y5l3 [ 0 ] ; } _rtB -> dz53u4y5l3 [ 3 ] = _rtDW -> hkkgg0zsus [
0 ] ; _rtB -> eqfjw3x3ov [ 0 ] = _rtB -> ndnwklv2ar ; _rtB -> eqfjw3x3ov [ 1
] = 0.0 ; _rtB -> eqfjw3x3ov [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> jd4kmptglz [ 0 ] = ! ( _rtB -> eqfjw3x3ov [ 0 ] == _rtDW ->
jd4kmptglz [ 1 ] ) ; _rtDW -> jd4kmptglz [ 1 ] = _rtB -> eqfjw3x3ov [ 0 ] ; }
_rtB -> eqfjw3x3ov [ 3 ] = _rtDW -> jd4kmptglz [ 0 ] ; _rtB -> pcpkaefzls [ 0
] = _rtB -> fvn4xpfdgf ; _rtB -> pcpkaefzls [ 1 ] = 0.0 ; _rtB -> pcpkaefzls
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> cykf34nruq [ 0 ] = !
( _rtB -> pcpkaefzls [ 0 ] == _rtDW -> cykf34nruq [ 1 ] ) ; _rtDW ->
cykf34nruq [ 1 ] = _rtB -> pcpkaefzls [ 0 ] ; } _rtB -> pcpkaefzls [ 3 ] =
_rtDW -> cykf34nruq [ 0 ] ; _rtB -> bwkunclwvk [ 0 ] = _rtB -> ndnwklv2ar ;
_rtB -> bwkunclwvk [ 1 ] = 0.0 ; _rtB -> bwkunclwvk [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> acl0loxhr1 [ 0 ] = ! ( _rtB ->
bwkunclwvk [ 0 ] == _rtDW -> acl0loxhr1 [ 1 ] ) ; _rtDW -> acl0loxhr1 [ 1 ] =
_rtB -> bwkunclwvk [ 0 ] ; } _rtB -> bwkunclwvk [ 3 ] = _rtDW -> acl0loxhr1 [
0 ] ; _rtB -> cv4xmvltde [ 0 ] = _rtB -> fvn4xpfdgf ; _rtB -> cv4xmvltde [ 1
] = 0.0 ; _rtB -> cv4xmvltde [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> pxk4qa2bci [ 0 ] = ! ( _rtB -> cv4xmvltde [ 0 ] == _rtDW ->
pxk4qa2bci [ 1 ] ) ; _rtDW -> pxk4qa2bci [ 1 ] = _rtB -> cv4xmvltde [ 0 ] ; }
_rtB -> cv4xmvltde [ 3 ] = _rtDW -> pxk4qa2bci [ 0 ] ; _rtB -> iitewf0bav [ 0
] = _rtB -> dgcjtztuaz ; _rtB -> iitewf0bav [ 1 ] = 0.0 ; _rtB -> iitewf0bav
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> gya3bwtiuh [ 0 ] = !
( _rtB -> iitewf0bav [ 0 ] == _rtDW -> gya3bwtiuh [ 1 ] ) ; _rtDW ->
gya3bwtiuh [ 1 ] = _rtB -> iitewf0bav [ 0 ] ; } _rtB -> iitewf0bav [ 3 ] =
_rtDW -> gya3bwtiuh [ 0 ] ; _rtB -> ophbssgh1y [ 0 ] = _rtB -> dgcjtztuaz ;
_rtB -> ophbssgh1y [ 1 ] = 0.0 ; _rtB -> ophbssgh1y [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> jfno1y5p2j [ 0 ] = ! ( _rtB ->
ophbssgh1y [ 0 ] == _rtDW -> jfno1y5p2j [ 1 ] ) ; _rtDW -> jfno1y5p2j [ 1 ] =
_rtB -> ophbssgh1y [ 0 ] ; } _rtB -> ophbssgh1y [ 3 ] = _rtDW -> jfno1y5p2j [
0 ] ; _rtB -> cuzn1nf4h4 [ 0 ] = _rtB -> lytyffj4w0 ; _rtB -> cuzn1nf4h4 [ 1
] = 0.0 ; _rtB -> cuzn1nf4h4 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> ooe2cthozw [ 0 ] = ! ( _rtB -> cuzn1nf4h4 [ 0 ] == _rtDW ->
ooe2cthozw [ 1 ] ) ; _rtDW -> ooe2cthozw [ 1 ] = _rtB -> cuzn1nf4h4 [ 0 ] ; }
_rtB -> cuzn1nf4h4 [ 3 ] = _rtDW -> ooe2cthozw [ 0 ] ; _rtB -> l22ddvxy55 [ 0
] = _rtB -> lytyffj4w0 ; _rtB -> l22ddvxy55 [ 1 ] = 0.0 ; _rtB -> l22ddvxy55
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> hnrasxyo3k [ 0 ] = !
( _rtB -> l22ddvxy55 [ 0 ] == _rtDW -> hnrasxyo3k [ 1 ] ) ; _rtDW ->
hnrasxyo3k [ 1 ] = _rtB -> l22ddvxy55 [ 0 ] ; } _rtB -> l22ddvxy55 [ 3 ] =
_rtDW -> hnrasxyo3k [ 0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime
= ssGetTaskTime ( S , 1 ) ; _rtDW -> gt1wog5nfj = ( currentTime >= _rtP ->
P_11 ) ; if ( _rtDW -> gt1wog5nfj == 1 ) { _rtB -> dlczxig5c3 = _rtP -> P_13
; } else { _rtB -> dlczxig5c3 = _rtP -> P_12 ; } } oohoiua0m4 = ssGetT ( S )
; _rtB -> nwebnmqngt = oohoiua0m4 - _rtB -> alhh5sp42l ; _rtB -> orptn4t0xa =
_rtB -> dlczxig5c3 * _rtB -> nwebnmqngt ; _rtB -> awqmzon2xj = _rtB ->
orptn4t0xa + _rtB -> kegng3vlcz ; _rtB -> kovb1rljo1 [ 0 ] = _rtB ->
awqmzon2xj ; _rtB -> kovb1rljo1 [ 1 ] = 0.0 ; _rtB -> kovb1rljo1 [ 2 ] = 0.0
; _rtB -> kovb1rljo1 [ 3 ] = 0.0 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 44 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> oeprmtj04h
[ 0 ] = _rtB -> iwbuyatmgo [ 2 ] ; _rtB -> oeprmtj04h [ 1 ] = _rtB ->
iwbuyatmgo [ 0 ] ; ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> h0t3fary0z [ 0 ] = _rtB -> iwbuyatmgo [ 2 ] ; _rtB -> h0t3fary0z [ 1
] = _rtB -> iwbuyatmgo [ 1 ] ; } ssCallAccelRunBlock ( S , 2 , 47 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 48 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> hzxlfztnyk [ 0 ] = _rtB -> iwbuyatmgo [ 2 ] ;
_rtB -> hzxlfztnyk [ 1 ] = _rtB -> iwbuyatmgo [ 0 ] ; ssCallAccelRunBlock ( S
, 2 , 50 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) { oqkgxcf4za * _rtB ; ecnpgld541
* _rtP ; _rtP = ( ( ecnpgld541 * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
oqkgxcf4za * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> lytyffj4w0 = _rtP -> P_0
; _rtB -> ny1cvtpsrl = _rtP -> P_1 ; _rtB -> c2zwf4ztz2 = _rtP -> P_2 ; _rtB
-> ocrden5vxs = _rtP -> P_3 ; _rtB -> mmcvzdyndf = _rtP -> P_4 ; _rtB ->
iswdnswhaw = _rtP -> P_5 ; _rtB -> ftitnzr24s = _rtP -> P_6 ; _rtB ->
me22bk5wua = _rtP -> P_7 ; _rtB -> ndnwklv2ar = _rtP -> P_8 ; _rtB ->
fvn4xpfdgf = _rtP -> P_9 ; _rtB -> dgcjtztuaz = _rtP -> P_10 ; _rtB ->
alhh5sp42l = _rtP -> P_14 ; _rtB -> kegng3vlcz = _rtP -> P_15 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { oqkgxcf4za * _rtB ;
_rtB = ( ( oqkgxcf4za * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 2 , 43 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
2 , 43 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { ecnpgld541 * _rtP ;
f0f0vksdcq * _rtZCSV ; _rtZCSV = ( ( f0f0vksdcq * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( ecnpgld541 * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
b10dx3vguh = ssGetT ( S ) - _rtP -> P_11 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 2148540346U ) ; ssSetChecksumVal ( S , 1 ,
3848407294U ) ; ssSetChecksumVal ( S , 2 , 1639057837U ) ; ssSetChecksumVal (
S , 3 , 3963526579U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
c2yuaepbs4 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( oqkgxcf4za ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
ecnpgld541 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & lbsf31scam ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( c2yuaepbs4 ) ) { {
( ( c2yuaepbs4 * ) ssGetRootDWork ( S ) ) -> bxxpjriogo = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
