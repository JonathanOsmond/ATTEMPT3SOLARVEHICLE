#include "__cf_SolarArray_5MPPT.h"
#ifndef RTW_HEADER_SolarArray_5MPPT_acc_types_h_
#define RTW_HEADER_SolarArray_5MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct ecnpgld541_ ecnpgld541 ;
#endif
