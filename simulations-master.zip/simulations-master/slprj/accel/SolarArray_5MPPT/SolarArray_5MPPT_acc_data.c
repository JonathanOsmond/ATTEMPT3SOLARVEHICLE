#include "__cf_SolarArray_5MPPT.h"
#include "SolarArray_5MPPT_acc.h"
#include "SolarArray_5MPPT_acc_private.h"
ecnpgld541 lbsf31scam = { 392.57 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
274.79900000000004 , 196.28500000000003 , 392.57000000000005 , 0.0 , 0.0 ,
0.5 , 0.0 , 0.0 } ;
