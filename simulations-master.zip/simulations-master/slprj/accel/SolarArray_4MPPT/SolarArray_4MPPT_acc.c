#include "__cf_SolarArray_4MPPT.h"
#include <math.h>
#include "SolarArray_4MPPT_acc.h"
#include "SolarArray_4MPPT_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T fxoxbchte0 ;
real_T currentTime ; h5kt41wnrp * _rtB ; p1a5tgug2l * _rtP ; ata4x4liix *
_rtDW ; _rtDW = ( ( ata4x4liix * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
p1a5tgug2l * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( h5kt41wnrp * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> eviuvjxr5s [ 0 ] = _rtB -> cyelfttrrn ;
_rtB -> eviuvjxr5s [ 1 ] = 0.0 ; _rtB -> eviuvjxr5s [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> bkkf11dbdm [ 0 ] = ! ( _rtB ->
eviuvjxr5s [ 0 ] == _rtDW -> bkkf11dbdm [ 1 ] ) ; _rtDW -> bkkf11dbdm [ 1 ] =
_rtB -> eviuvjxr5s [ 0 ] ; } _rtB -> eviuvjxr5s [ 3 ] = _rtDW -> bkkf11dbdm [
0 ] ; _rtB -> kgiobs020s [ 0 ] = _rtB -> o5v4qw3g2d ; _rtB -> kgiobs020s [ 1
] = 0.0 ; _rtB -> kgiobs020s [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> lqrr5j0jnf [ 0 ] = ! ( _rtB -> kgiobs020s [ 0 ] == _rtDW ->
lqrr5j0jnf [ 1 ] ) ; _rtDW -> lqrr5j0jnf [ 1 ] = _rtB -> kgiobs020s [ 0 ] ; }
_rtB -> kgiobs020s [ 3 ] = _rtDW -> lqrr5j0jnf [ 0 ] ; _rtB -> cgildvxhzu [ 0
] = _rtB -> e4epcmtju3 ; _rtB -> cgildvxhzu [ 1 ] = 0.0 ; _rtB -> cgildvxhzu
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> i2oc5dutqq [ 0 ] = !
( _rtB -> cgildvxhzu [ 0 ] == _rtDW -> i2oc5dutqq [ 1 ] ) ; _rtDW ->
i2oc5dutqq [ 1 ] = _rtB -> cgildvxhzu [ 0 ] ; } _rtB -> cgildvxhzu [ 3 ] =
_rtDW -> i2oc5dutqq [ 0 ] ; _rtB -> h3oyd4yz3w [ 0 ] = _rtB -> cqoqbnifmu ;
_rtB -> h3oyd4yz3w [ 1 ] = 0.0 ; _rtB -> h3oyd4yz3w [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> gfiivyyoe4 [ 0 ] = ! ( _rtB ->
h3oyd4yz3w [ 0 ] == _rtDW -> gfiivyyoe4 [ 1 ] ) ; _rtDW -> gfiivyyoe4 [ 1 ] =
_rtB -> h3oyd4yz3w [ 0 ] ; } _rtB -> h3oyd4yz3w [ 3 ] = _rtDW -> gfiivyyoe4 [
0 ] ; _rtB -> cbk02q5hhz [ 0 ] = _rtB -> dk35u53igm ; _rtB -> cbk02q5hhz [ 1
] = 0.0 ; _rtB -> cbk02q5hhz [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> mrynth1k40 [ 0 ] = ! ( _rtB -> cbk02q5hhz [ 0 ] == _rtDW ->
mrynth1k40 [ 1 ] ) ; _rtDW -> mrynth1k40 [ 1 ] = _rtB -> cbk02q5hhz [ 0 ] ; }
_rtB -> cbk02q5hhz [ 3 ] = _rtDW -> mrynth1k40 [ 0 ] ; _rtB -> m5qya3k503 [ 0
] = _rtB -> nrcwwhjgyt ; _rtB -> m5qya3k503 [ 1 ] = 0.0 ; _rtB -> m5qya3k503
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> f3qdc4zofk [ 0 ] = !
( _rtB -> m5qya3k503 [ 0 ] == _rtDW -> f3qdc4zofk [ 1 ] ) ; _rtDW ->
f3qdc4zofk [ 1 ] = _rtB -> m5qya3k503 [ 0 ] ; } _rtB -> m5qya3k503 [ 3 ] =
_rtDW -> f3qdc4zofk [ 0 ] ; _rtB -> ffhkfxwzzx [ 0 ] = _rtB -> bu1lhjvanf ;
_rtB -> ffhkfxwzzx [ 1 ] = 0.0 ; _rtB -> ffhkfxwzzx [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> agaubfitpn [ 0 ] = ! ( _rtB ->
ffhkfxwzzx [ 0 ] == _rtDW -> agaubfitpn [ 1 ] ) ; _rtDW -> agaubfitpn [ 1 ] =
_rtB -> ffhkfxwzzx [ 0 ] ; } _rtB -> ffhkfxwzzx [ 3 ] = _rtDW -> agaubfitpn [
0 ] ; _rtB -> epqjkoltfu [ 0 ] = _rtB -> pnt3n51nyd ; _rtB -> epqjkoltfu [ 1
] = 0.0 ; _rtB -> epqjkoltfu [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> dzvxkbhxxt [ 0 ] = ! ( _rtB -> epqjkoltfu [ 0 ] == _rtDW ->
dzvxkbhxxt [ 1 ] ) ; _rtDW -> dzvxkbhxxt [ 1 ] = _rtB -> epqjkoltfu [ 0 ] ; }
_rtB -> epqjkoltfu [ 3 ] = _rtDW -> dzvxkbhxxt [ 0 ] ; _rtB -> oh2m5ntp2g [ 0
] = _rtB -> pnt3n51nyd ; _rtB -> oh2m5ntp2g [ 1 ] = 0.0 ; _rtB -> oh2m5ntp2g
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> iobhqps1hm [ 0 ] = !
( _rtB -> oh2m5ntp2g [ 0 ] == _rtDW -> iobhqps1hm [ 1 ] ) ; _rtDW ->
iobhqps1hm [ 1 ] = _rtB -> oh2m5ntp2g [ 0 ] ; } _rtB -> oh2m5ntp2g [ 3 ] =
_rtDW -> iobhqps1hm [ 0 ] ; _rtB -> djicnfjtex [ 0 ] = _rtB -> bu1lhjvanf ;
_rtB -> djicnfjtex [ 1 ] = 0.0 ; _rtB -> djicnfjtex [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> bo20hsf0jd [ 0 ] = ! ( _rtB ->
djicnfjtex [ 0 ] == _rtDW -> bo20hsf0jd [ 1 ] ) ; _rtDW -> bo20hsf0jd [ 1 ] =
_rtB -> djicnfjtex [ 0 ] ; } _rtB -> djicnfjtex [ 3 ] = _rtDW -> bo20hsf0jd [
0 ] ; _rtB -> dsa0j5rfi2 [ 0 ] = _rtB -> nrcwwhjgyt ; _rtB -> dsa0j5rfi2 [ 1
] = 0.0 ; _rtB -> dsa0j5rfi2 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> kwbq0t4ug3 [ 0 ] = ! ( _rtB -> dsa0j5rfi2 [ 0 ] == _rtDW ->
kwbq0t4ug3 [ 1 ] ) ; _rtDW -> kwbq0t4ug3 [ 1 ] = _rtB -> dsa0j5rfi2 [ 0 ] ; }
_rtB -> dsa0j5rfi2 [ 3 ] = _rtDW -> kwbq0t4ug3 [ 0 ] ; _rtB -> puublf5eju [ 0
] = _rtB -> g3avnhhafd ; _rtB -> puublf5eju [ 1 ] = 0.0 ; _rtB -> puublf5eju
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> aeht4iphq4 [ 0 ] = !
( _rtB -> puublf5eju [ 0 ] == _rtDW -> aeht4iphq4 [ 1 ] ) ; _rtDW ->
aeht4iphq4 [ 1 ] = _rtB -> puublf5eju [ 0 ] ; } _rtB -> puublf5eju [ 3 ] =
_rtDW -> aeht4iphq4 [ 0 ] ; _rtB -> ozntlzax40 [ 0 ] = _rtB -> g0orgbvwtd ;
_rtB -> ozntlzax40 [ 1 ] = 0.0 ; _rtB -> ozntlzax40 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> prepn0talh [ 0 ] = ! ( _rtB ->
ozntlzax40 [ 0 ] == _rtDW -> prepn0talh [ 1 ] ) ; _rtDW -> prepn0talh [ 1 ] =
_rtB -> ozntlzax40 [ 0 ] ; } _rtB -> ozntlzax40 [ 3 ] = _rtDW -> prepn0talh [
0 ] ; _rtB -> lcpdexvsjf [ 0 ] = _rtB -> e4epcmtju3 ; _rtB -> lcpdexvsjf [ 1
] = 0.0 ; _rtB -> lcpdexvsjf [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> j3c1sce3ix [ 0 ] = ! ( _rtB -> lcpdexvsjf [ 0 ] == _rtDW ->
j3c1sce3ix [ 1 ] ) ; _rtDW -> j3c1sce3ix [ 1 ] = _rtB -> lcpdexvsjf [ 0 ] ; }
_rtB -> lcpdexvsjf [ 3 ] = _rtDW -> j3c1sce3ix [ 0 ] ; _rtB -> a1tubz4mv0 [ 0
] = _rtB -> g0orgbvwtd ; _rtB -> a1tubz4mv0 [ 1 ] = 0.0 ; _rtB -> a1tubz4mv0
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> my4rzj4xqe [ 0 ] = !
( _rtB -> a1tubz4mv0 [ 0 ] == _rtDW -> my4rzj4xqe [ 1 ] ) ; _rtDW ->
my4rzj4xqe [ 1 ] = _rtB -> a1tubz4mv0 [ 0 ] ; } _rtB -> a1tubz4mv0 [ 3 ] =
_rtDW -> my4rzj4xqe [ 0 ] ; _rtB -> d4yqbydz4v [ 0 ] = _rtB -> g3avnhhafd ;
_rtB -> d4yqbydz4v [ 1 ] = 0.0 ; _rtB -> d4yqbydz4v [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> lvigibahl5 [ 0 ] = ! ( _rtB ->
d4yqbydz4v [ 0 ] == _rtDW -> lvigibahl5 [ 1 ] ) ; _rtDW -> lvigibahl5 [ 1 ] =
_rtB -> d4yqbydz4v [ 0 ] ; } _rtB -> d4yqbydz4v [ 3 ] = _rtDW -> lvigibahl5 [
0 ] ; _rtB -> ewo33mjg1g [ 0 ] = _rtB -> cul2nogpv1 ; _rtB -> ewo33mjg1g [ 1
] = 0.0 ; _rtB -> ewo33mjg1g [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> evz0pkpt2y [ 0 ] = ! ( _rtB -> ewo33mjg1g [ 0 ] == _rtDW ->
evz0pkpt2y [ 1 ] ) ; _rtDW -> evz0pkpt2y [ 1 ] = _rtB -> ewo33mjg1g [ 0 ] ; }
_rtB -> ewo33mjg1g [ 3 ] = _rtDW -> evz0pkpt2y [ 0 ] ; _rtB -> m0qxlpymy1 [ 0
] = _rtB -> cul2nogpv1 ; _rtB -> m0qxlpymy1 [ 1 ] = 0.0 ; _rtB -> m0qxlpymy1
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> fyxgeojjr4 [ 0 ] = !
( _rtB -> m0qxlpymy1 [ 0 ] == _rtDW -> fyxgeojjr4 [ 1 ] ) ; _rtDW ->
fyxgeojjr4 [ 1 ] = _rtB -> m0qxlpymy1 [ 0 ] ; } _rtB -> m0qxlpymy1 [ 3 ] =
_rtDW -> fyxgeojjr4 [ 0 ] ; _rtB -> azqhnk3tnr [ 0 ] = _rtB -> cyelfttrrn ;
_rtB -> azqhnk3tnr [ 1 ] = 0.0 ; _rtB -> azqhnk3tnr [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> ebjrxus3pi [ 0 ] = ! ( _rtB ->
azqhnk3tnr [ 0 ] == _rtDW -> ebjrxus3pi [ 1 ] ) ; _rtDW -> ebjrxus3pi [ 1 ] =
_rtB -> azqhnk3tnr [ 0 ] ; } _rtB -> azqhnk3tnr [ 3 ] = _rtDW -> ebjrxus3pi [
0 ] ; _rtB -> mvxc1suuxe [ 0 ] = _rtB -> nlnhe4fyr0 ; _rtB -> mvxc1suuxe [ 1
] = 0.0 ; _rtB -> mvxc1suuxe [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> clyorsxgqt [ 0 ] = ! ( _rtB -> mvxc1suuxe [ 0 ] == _rtDW ->
clyorsxgqt [ 1 ] ) ; _rtDW -> clyorsxgqt [ 1 ] = _rtB -> mvxc1suuxe [ 0 ] ; }
_rtB -> mvxc1suuxe [ 3 ] = _rtDW -> clyorsxgqt [ 0 ] ; _rtB -> pchlffrngz [ 0
] = _rtB -> nlnhe4fyr0 ; _rtB -> pchlffrngz [ 1 ] = 0.0 ; _rtB -> pchlffrngz
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> fgekhhgzju [ 0 ] = !
( _rtB -> pchlffrngz [ 0 ] == _rtDW -> fgekhhgzju [ 1 ] ) ; _rtDW ->
fgekhhgzju [ 1 ] = _rtB -> pchlffrngz [ 0 ] ; } _rtB -> pchlffrngz [ 3 ] =
_rtDW -> fgekhhgzju [ 0 ] ; _rtB -> foea3rzuce [ 0 ] = _rtB -> i145asusp0 ;
_rtB -> foea3rzuce [ 1 ] = 0.0 ; _rtB -> foea3rzuce [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> ebwif13gzv [ 0 ] = ! ( _rtB ->
foea3rzuce [ 0 ] == _rtDW -> ebwif13gzv [ 1 ] ) ; _rtDW -> ebwif13gzv [ 1 ] =
_rtB -> foea3rzuce [ 0 ] ; } _rtB -> foea3rzuce [ 3 ] = _rtDW -> ebwif13gzv [
0 ] ; _rtB -> dn122qh1cp [ 0 ] = _rtB -> i145asusp0 ; _rtB -> dn122qh1cp [ 1
] = 0.0 ; _rtB -> dn122qh1cp [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> a12iydwrx0 [ 0 ] = ! ( _rtB -> dn122qh1cp [ 0 ] == _rtDW ->
a12iydwrx0 [ 1 ] ) ; _rtDW -> a12iydwrx0 [ 1 ] = _rtB -> dn122qh1cp [ 0 ] ; }
_rtB -> dn122qh1cp [ 3 ] = _rtDW -> a12iydwrx0 [ 0 ] ; _rtB -> fqip30rjqg [ 0
] = _rtB -> ibb01rjgun ; _rtB -> fqip30rjqg [ 1 ] = 0.0 ; _rtB -> fqip30rjqg
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> arfgerixen [ 0 ] = !
( _rtB -> fqip30rjqg [ 0 ] == _rtDW -> arfgerixen [ 1 ] ) ; _rtDW ->
arfgerixen [ 1 ] = _rtB -> fqip30rjqg [ 0 ] ; } _rtB -> fqip30rjqg [ 3 ] =
_rtDW -> arfgerixen [ 0 ] ; _rtB -> e1n3kbiqi0 [ 0 ] = _rtB -> ia5fawgwax ;
_rtB -> e1n3kbiqi0 [ 1 ] = 0.0 ; _rtB -> e1n3kbiqi0 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> biuk4y0fmv [ 0 ] = ! ( _rtB ->
e1n3kbiqi0 [ 0 ] == _rtDW -> biuk4y0fmv [ 1 ] ) ; _rtDW -> biuk4y0fmv [ 1 ] =
_rtB -> e1n3kbiqi0 [ 0 ] ; } _rtB -> e1n3kbiqi0 [ 3 ] = _rtDW -> biuk4y0fmv [
0 ] ; _rtB -> e10bnmzwqq [ 0 ] = _rtB -> ibb01rjgun ; _rtB -> e10bnmzwqq [ 1
] = 0.0 ; _rtB -> e10bnmzwqq [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> ovx5q5ela5 [ 0 ] = ! ( _rtB -> e10bnmzwqq [ 0 ] == _rtDW ->
ovx5q5ela5 [ 1 ] ) ; _rtDW -> ovx5q5ela5 [ 1 ] = _rtB -> e10bnmzwqq [ 0 ] ; }
_rtB -> e10bnmzwqq [ 3 ] = _rtDW -> ovx5q5ela5 [ 0 ] ; _rtB -> mhrt2kr1nn [ 0
] = _rtB -> ia5fawgwax ; _rtB -> mhrt2kr1nn [ 1 ] = 0.0 ; _rtB -> mhrt2kr1nn
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> dh2ybatfqp [ 0 ] = !
( _rtB -> mhrt2kr1nn [ 0 ] == _rtDW -> dh2ybatfqp [ 1 ] ) ; _rtDW ->
dh2ybatfqp [ 1 ] = _rtB -> mhrt2kr1nn [ 0 ] ; } _rtB -> mhrt2kr1nn [ 3 ] =
_rtDW -> dh2ybatfqp [ 0 ] ; _rtB -> f1vgyn2gy5 [ 0 ] = _rtB -> o5v4qw3g2d ;
_rtB -> f1vgyn2gy5 [ 1 ] = 0.0 ; _rtB -> f1vgyn2gy5 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> g1ovjf4ubf [ 0 ] = ! ( _rtB ->
f1vgyn2gy5 [ 0 ] == _rtDW -> g1ovjf4ubf [ 1 ] ) ; _rtDW -> g1ovjf4ubf [ 1 ] =
_rtB -> f1vgyn2gy5 [ 0 ] ; } _rtB -> f1vgyn2gy5 [ 3 ] = _rtDW -> g1ovjf4ubf [
0 ] ; _rtB -> klcxmyzep4 [ 0 ] = _rtB -> dk35u53igm ; _rtB -> klcxmyzep4 [ 1
] = 0.0 ; _rtB -> klcxmyzep4 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> d5stcehjhi [ 0 ] = ! ( _rtB -> klcxmyzep4 [ 0 ] == _rtDW ->
d5stcehjhi [ 1 ] ) ; _rtDW -> d5stcehjhi [ 1 ] = _rtB -> klcxmyzep4 [ 0 ] ; }
_rtB -> klcxmyzep4 [ 3 ] = _rtDW -> d5stcehjhi [ 0 ] ; _rtB -> alu0hsjnvt [ 0
] = _rtB -> cqoqbnifmu ; _rtB -> alu0hsjnvt [ 1 ] = 0.0 ; _rtB -> alu0hsjnvt
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> hyjpfasxrs [ 0 ] = !
( _rtB -> alu0hsjnvt [ 0 ] == _rtDW -> hyjpfasxrs [ 1 ] ) ; _rtDW ->
hyjpfasxrs [ 1 ] = _rtB -> alu0hsjnvt [ 0 ] ; } _rtB -> alu0hsjnvt [ 3 ] =
_rtDW -> hyjpfasxrs [ 0 ] ; _rtB -> kz2wpyf3pk [ 0 ] = _rtB -> olsu31ca0j ;
_rtB -> kz2wpyf3pk [ 1 ] = 0.0 ; _rtB -> kz2wpyf3pk [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> el3ajvwkn5 [ 0 ] = ! ( _rtB ->
kz2wpyf3pk [ 0 ] == _rtDW -> el3ajvwkn5 [ 1 ] ) ; _rtDW -> el3ajvwkn5 [ 1 ] =
_rtB -> kz2wpyf3pk [ 0 ] ; } _rtB -> kz2wpyf3pk [ 3 ] = _rtDW -> el3ajvwkn5 [
0 ] ; _rtB -> hcj3je53de [ 0 ] = _rtB -> olsu31ca0j ; _rtB -> hcj3je53de [ 1
] = 0.0 ; _rtB -> hcj3je53de [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> fozqpnbqcm [ 0 ] = ! ( _rtB -> hcj3je53de [ 0 ] == _rtDW ->
fozqpnbqcm [ 1 ] ) ; _rtDW -> fozqpnbqcm [ 1 ] = _rtB -> hcj3je53de [ 0 ] ; }
_rtB -> hcj3je53de [ 3 ] = _rtDW -> fozqpnbqcm [ 0 ] ; if ( ssIsSampleHit ( S
, 1 , 0 ) ) { currentTime = ssGetTaskTime ( S , 1 ) ; _rtDW -> aqgesl2iyg = (
currentTime >= _rtP -> P_16 ) ; if ( _rtDW -> aqgesl2iyg == 1 ) { _rtB ->
gmmotd5aq0 = _rtP -> P_18 ; } else { _rtB -> gmmotd5aq0 = _rtP -> P_17 ; } }
fxoxbchte0 = ssGetT ( S ) ; _rtB -> m2gibjmgw2 = fxoxbchte0 - _rtB ->
jbhvjedbuz ; _rtB -> cu3wusza0b = _rtB -> gmmotd5aq0 * _rtB -> m2gibjmgw2 ;
_rtB -> inshv3jeua = _rtB -> cu3wusza0b + _rtB -> kq1d3ijofq ; _rtB ->
fijufsadkt [ 0 ] = _rtB -> inshv3jeua ; _rtB -> fijufsadkt [ 1 ] = 0.0 ; _rtB
-> fijufsadkt [ 2 ] = 0.0 ; _rtB -> fijufsadkt [ 3 ] = 0.0 ;
ssCallAccelRunBlock ( S , 3 , 56 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 3 , 57 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> kntdko2wag [ 0 ] = _rtB -> ix5nw5ouor [ 0 ] ; _rtB -> kntdko2wag [ 1
] = _rtB -> ix5nw5ouor [ 3 ] ; } _rtB -> l0qca1g20e = _rtB -> ix5nw5ouor [ 3
] * _rtB -> ix5nw5ouor [ 0 ] ; ssCallAccelRunBlock ( S , 3 , 60 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> cdpp2nhzup [ 0 ] = _rtB -> ix5nw5ouor [ 3 ] ;
_rtB -> cdpp2nhzup [ 1 ] = _rtB -> ix5nw5ouor [ 0 ] ; ssCallAccelRunBlock ( S
, 3 , 62 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> lxba3ctkph
[ 0 ] = _rtB -> ix5nw5ouor [ 4 ] ; _rtB -> lxba3ctkph [ 1 ] = _rtB ->
ix5nw5ouor [ 1 ] ; ssCallAccelRunBlock ( S , 2 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> dtgwsj2tla [ 0 ] = _rtB -> ix5nw5ouor [ 4 ] ; _rtB -> dtgwsj2tla [ 1
] = _rtB -> ix5nw5ouor [ 2 ] ; } ssCallAccelRunBlock ( S , 3 , 67 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> k3q3w05lqn [ 0 ] = _rtB -> ix5nw5ouor [ 2 ] ;
_rtB -> k3q3w05lqn [ 1 ] = _rtB -> ix5nw5ouor [ 4 ] ; ssCallAccelRunBlock ( S
, 3 , 69 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> khcuamzew4 [ 0 ] = _rtB ->
ix5nw5ouor [ 4 ] ; _rtB -> khcuamzew4 [ 1 ] = _rtB -> ix5nw5ouor [ 1 ] ;
ssCallAccelRunBlock ( S , 3 , 71 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER (
tid ) ; } static void mdlOutputsTID2 ( SimStruct * S , int_T tid ) {
h5kt41wnrp * _rtB ; p1a5tgug2l * _rtP ; _rtP = ( ( p1a5tgug2l * )
ssGetModelRtp ( S ) ) ; _rtB = ( ( h5kt41wnrp * ) _ssGetModelBlockIO ( S ) )
; _rtB -> cyelfttrrn = _rtP -> P_0 ; _rtB -> o5v4qw3g2d = _rtP -> P_1 ; _rtB
-> e4epcmtju3 = _rtP -> P_2 ; _rtB -> cqoqbnifmu = _rtP -> P_3 ; _rtB ->
dk35u53igm = _rtP -> P_4 ; _rtB -> nrcwwhjgyt = _rtP -> P_5 ; _rtB ->
bu1lhjvanf = _rtP -> P_6 ; _rtB -> pnt3n51nyd = _rtP -> P_7 ; _rtB ->
g3avnhhafd = _rtP -> P_8 ; _rtB -> g0orgbvwtd = _rtP -> P_9 ; _rtB ->
cul2nogpv1 = _rtP -> P_10 ; _rtB -> nlnhe4fyr0 = _rtP -> P_11 ; _rtB ->
i145asusp0 = _rtP -> P_12 ; _rtB -> ibb01rjgun = _rtP -> P_13 ; _rtB ->
ia5fawgwax = _rtP -> P_14 ; _rtB -> olsu31ca0j = _rtP -> P_15 ; _rtB ->
jbhvjedbuz = _rtP -> P_19 ; _rtB -> kq1d3ijofq = _rtP -> P_20 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { h5kt41wnrp * _rtB ;
_rtB = ( ( h5kt41wnrp * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 3 , 56 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock ( S , 2 , 0 ,
SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 3 ,
56 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
3 , 56 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 3 ,
56 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { p1a5tgug2l * _rtP ;
gc3zyrmkte * _rtZCSV ; _rtZCSV = ( ( gc3zyrmkte * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( p1a5tgug2l * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
acicl3w0vp = ssGetT ( S ) - _rtP -> P_16 ; ssCallAccelRunBlock ( S , 3 , 56 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 2495655291U ) ; ssSetChecksumVal ( S , 1 ,
3027949726U ) ; ssSetChecksumVal ( S , 2 , 3469759011U ) ; ssSetChecksumVal (
S , 3 , 1677117122U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
ata4x4liix ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( h5kt41wnrp ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
p1a5tgug2l ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & fpow22vapl ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( ata4x4liix ) ) { {
( ( ata4x4liix * ) ssGetRootDWork ( S ) ) -> py1jmgof00 = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
