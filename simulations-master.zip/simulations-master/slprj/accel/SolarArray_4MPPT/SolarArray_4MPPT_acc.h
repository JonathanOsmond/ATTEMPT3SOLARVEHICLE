#include "__cf_SolarArray_4MPPT.h"
#ifndef RTW_HEADER_SolarArray_4MPPT_acc_h_
#define RTW_HEADER_SolarArray_4MPPT_acc_h_
#include <stddef.h>
#ifndef SolarArray_4MPPT_acc_COMMON_INCLUDES_
#define SolarArray_4MPPT_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SolarArray_4MPPT_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T cyelfttrrn ; real_T eviuvjxr5s [ 4 ] ; real_T
o5v4qw3g2d ; real_T kgiobs020s [ 4 ] ; real_T e4epcmtju3 ; real_T cgildvxhzu
[ 4 ] ; real_T cqoqbnifmu ; real_T h3oyd4yz3w [ 4 ] ; real_T dk35u53igm ;
real_T cbk02q5hhz [ 4 ] ; real_T nrcwwhjgyt ; real_T m5qya3k503 [ 4 ] ;
real_T bu1lhjvanf ; real_T ffhkfxwzzx [ 4 ] ; real_T pnt3n51nyd ; real_T
epqjkoltfu [ 4 ] ; real_T oh2m5ntp2g [ 4 ] ; real_T djicnfjtex [ 4 ] ; real_T
dsa0j5rfi2 [ 4 ] ; real_T g3avnhhafd ; real_T puublf5eju [ 4 ] ; real_T
g0orgbvwtd ; real_T ozntlzax40 [ 4 ] ; real_T lcpdexvsjf [ 4 ] ; real_T
a1tubz4mv0 [ 4 ] ; real_T d4yqbydz4v [ 4 ] ; real_T cul2nogpv1 ; real_T
ewo33mjg1g [ 4 ] ; real_T m0qxlpymy1 [ 4 ] ; real_T azqhnk3tnr [ 4 ] ; real_T
nlnhe4fyr0 ; real_T mvxc1suuxe [ 4 ] ; real_T pchlffrngz [ 4 ] ; real_T
i145asusp0 ; real_T foea3rzuce [ 4 ] ; real_T dn122qh1cp [ 4 ] ; real_T
ibb01rjgun ; real_T fqip30rjqg [ 4 ] ; real_T ia5fawgwax ; real_T e1n3kbiqi0
[ 4 ] ; real_T e10bnmzwqq [ 4 ] ; real_T mhrt2kr1nn [ 4 ] ; real_T f1vgyn2gy5
[ 4 ] ; real_T klcxmyzep4 [ 4 ] ; real_T alu0hsjnvt [ 4 ] ; real_T olsu31ca0j
; real_T kz2wpyf3pk [ 4 ] ; real_T hcj3je53de [ 4 ] ; real_T gmmotd5aq0 ;
real_T jbhvjedbuz ; real_T m2gibjmgw2 ; real_T cu3wusza0b ; real_T kq1d3ijofq
; real_T inshv3jeua ; real_T fijufsadkt [ 4 ] ; real_T edeehzv2vc [ 293 ] ;
real_T ix5nw5ouor [ 5 ] ; real_T l0qca1g20e ; real_T cdpp2nhzup [ 2 ] ;
real_T k3q3w05lqn [ 2 ] ; real_T khcuamzew4 [ 2 ] ; real_T dtgwsj2tla [ 2 ] ;
real_T kntdko2wag [ 2 ] ; real_T lxba3ctkph [ 2 ] ; } h5kt41wnrp ; typedef
struct { real_T bkkf11dbdm [ 2 ] ; real_T lqrr5j0jnf [ 2 ] ; real_T
i2oc5dutqq [ 2 ] ; real_T gfiivyyoe4 [ 2 ] ; real_T mrynth1k40 [ 2 ] ; real_T
f3qdc4zofk [ 2 ] ; real_T agaubfitpn [ 2 ] ; real_T dzvxkbhxxt [ 2 ] ; real_T
iobhqps1hm [ 2 ] ; real_T bo20hsf0jd [ 2 ] ; real_T kwbq0t4ug3 [ 2 ] ; real_T
aeht4iphq4 [ 2 ] ; real_T prepn0talh [ 2 ] ; real_T j3c1sce3ix [ 2 ] ; real_T
my4rzj4xqe [ 2 ] ; real_T lvigibahl5 [ 2 ] ; real_T evz0pkpt2y [ 2 ] ; real_T
fyxgeojjr4 [ 2 ] ; real_T ebjrxus3pi [ 2 ] ; real_T clyorsxgqt [ 2 ] ; real_T
fgekhhgzju [ 2 ] ; real_T ebwif13gzv [ 2 ] ; real_T a12iydwrx0 [ 2 ] ; real_T
arfgerixen [ 2 ] ; real_T biuk4y0fmv [ 2 ] ; real_T ovx5q5ela5 [ 2 ] ; real_T
dh2ybatfqp [ 2 ] ; real_T g1ovjf4ubf [ 2 ] ; real_T d5stcehjhi [ 2 ] ; real_T
hyjpfasxrs [ 2 ] ; real_T el3ajvwkn5 [ 2 ] ; real_T fozqpnbqcm [ 2 ] ; real_T
bhjvkahl2v [ 2 ] ; void * ezjqoa1jgc ; void * aptrmo32vr ; void * mcwt5guqkv
; void * et4fppuz0h ; void * legjzd4du2 ; void * aqqsptf3f5 ; void *
h21fnlqokh ; void * mkmuoiplaj ; void * hdbfa52ssz ; void * o5dz5aqhcd ; void
* nauni2p413 [ 3 ] ; void * ennakhmncx ; void * kopl3f3nle [ 3 ] ; void *
msgli1lbhn ; void * icdosrvt45 ; int_T hnmb5jfcge [ 178 ] ; int_T aqgesl2iyg
; int32_T py1jmgof00 ; boolean_T f4ersaubgw ; boolean_T kuhafwo2n2 ; char_T
c4accohaa0 [ 6 ] ; } ata4x4liix ; typedef struct { real_T oqvmcvolce [ 115 ]
; } hmggh2gq2d ; typedef struct { real_T oqvmcvolce [ 115 ] ; } azjw1qmenc ;
typedef struct { boolean_T oqvmcvolce [ 115 ] ; } mt2c5wxofr ; typedef struct
{ real_T oqvmcvolce [ 115 ] ; } bjkkp1ctd3 ; typedef struct { real_T
acicl3w0vp ; real_T kucxjsokl5 ; real_T azl341tx3n ; real_T o2z1ualxjg ;
real_T dadstaobje ; real_T mepw1wsz2w ; real_T pzi1f4e2rq ; real_T i3w3gxmzql
; real_T mu2ne1gkx4 ; real_T exdyaedneh ; real_T nwqxgq5lfs ; real_T
b0ednwrwcf ; real_T izmmthkls4 ; real_T kepawg1oe5 ; real_T a4mkhogwdu ;
real_T htz5hliyfq ; real_T n4ctmjso3z ; real_T exrtuq3i1d ; real_T jrz2kr0qik
; real_T b0s2h5htv0 ; real_T iwbomkjtp5 ; real_T jcfasockg0 ; real_T
lrlfoxe0hu ; real_T etykawaraw ; real_T l2mnircjhl ; real_T pd3gjncdum ;
real_T alxzo0essn ; real_T g4drxnp214 ; real_T dwufgfwfb5 ; real_T jzkgfp23i3
; real_T kn25mk11oe ; real_T poedbsjixv ; real_T kak5p5lnkz ; real_T
ft2sz5kiur ; real_T kdgv4cspwf ; real_T fwcv5kjrhy ; real_T nrh5ui2aef ;
real_T c4bvqrznfp ; real_T paziwzufbn ; real_T hfawrqq0ir ; real_T nelcj5p304
; real_T fxmesdsox0 ; real_T nwmzj51eku ; real_T e2pfij4j4p ; real_T
ecw5qr2kgi ; real_T oauthxjzsq ; real_T mvot3dh3cy ; real_T fzbbmvnexe ;
real_T m3fpxrjfci ; real_T pt2djidts0 ; real_T bidm3xioel ; real_T mhwgo54fns
; real_T lfecq5y1a5 ; real_T cad4xcyqv3 ; real_T pe154hypbm ; real_T
gmaxw1wmoq ; real_T e5qmwlbbxh ; real_T ndbmsofeey ; real_T ke2rzdgkg2 ;
real_T nuaxj0f554 ; real_T ezogrnxecl ; real_T pbgjsudkxn ; real_T makespgdka
; real_T ggpggp0uo0 ; real_T d2xp0wguqo ; real_T epe50xvh45 ; real_T
cuwajgiuii ; real_T m45t25muue ; real_T nxvinp5jcc ; real_T diwzbzp2za ;
real_T dymfsdgwn2 ; real_T knsk0tczd5 ; real_T a4xlqpqbn3 ; real_T igjhbtaxrn
; real_T hrppvnrifu ; real_T jvbg4meb5t ; real_T hhzfgvso1o ; real_T
ex02synish ; real_T frsacfyzsu ; real_T atvkupiyyt ; real_T a2c0ra41p1 ;
real_T cxcvkhkfmt ; real_T cjyzx2fn1x ; real_T emffzesrwl ; real_T hezsbribez
; real_T lza3bun5rm ; real_T bal0finsex ; real_T ojgnddpb0j ; real_T
f4jfomvsco ; real_T o3sit0r5uv ; real_T dc04tzz5z4 ; real_T glfb4cs4n3 ;
real_T nvphjn243f ; real_T irvtuya0gc ; real_T dbz53oc2iw ; real_T ane2nk0tot
; real_T hs4ewtin4m ; real_T me1rx5io1g ; real_T b05ot50cqt ; real_T
ppqxxnar3w ; real_T gx0dt1rt5e ; real_T hirocquuvw ; real_T bc3vbvxxb2 ;
real_T hfbfe4ds5i ; real_T ag1jraxtfb ; real_T fspzxpyddc ; real_T hjlgcbnj4j
; real_T g1kz2rjmee ; real_T atlgrcyuev ; real_T kqvncledmx ; real_T
jgjy1divdg ; real_T g2ebopinji ; real_T jeg2bskf1h ; real_T kpgqvknn2f ;
real_T humuvvw4sg ; real_T gginzobcun ; real_T nd3tatw3op ; real_T j32gax15gm
; real_T jjpfrtqeap ; real_T codgjylfko ; real_T bqnllf2txa ; real_T
lpvguhui0k ; real_T orhzl4ng53 ; real_T mpoaji2aou ; real_T amlig5r0tp ;
real_T nos2i4inm4 ; real_T leivsht0ox ; real_T errxgvnmtv ; real_T hksk3e4zc1
; real_T btu0aryclx ; real_T psboqmnws3 ; real_T pszdqwqi25 ; real_T
jwwks0qu1m ; real_T bljyklinpf ; real_T iodko2wmbs ; real_T aullsivbck ;
real_T nj0j0yxovs ; real_T opphjvjbhc ; real_T ov4bul13yc ; real_T jp3lairsl3
; real_T hzcsmjm2qk ; real_T acfthwqqvw ; real_T fxav0hkgdu ; real_T
oti2gjitv0 ; real_T cpzsxuslzl ; real_T lteidet113 ; real_T bjoyhbmzux ;
real_T n0rbblyviw ; real_T krnaihcbts ; real_T ik1fmcmkn2 ; real_T hatrsfakkc
; real_T l5ggeifx1m ; real_T fwbkliw22g ; real_T lhjdzeahb4 ; real_T
igo1v35wto ; real_T ng1mm53whp ; real_T jfrppm1iif ; real_T h3uycfb1p2 ;
real_T ibkuhuhjfv ; real_T lfonr2rcoe ; real_T gu3kthmpqy ; real_T fqndqqbqaw
; real_T lgub1cgkiv ; real_T pkjmawswpj ; real_T lrsckrtkzu ; real_T
nwhmavedcn ; real_T exayafmvvs ; real_T dxqz3ekq1h ; real_T ptbyiufpo3 ;
real_T ciu0jhvdlm ; real_T okg50q5dlb ; real_T mwlhba2ad5 ; real_T fglwqqudzu
; real_T iqy4am1ymc ; real_T e2ugaxizrg ; real_T odcibag3kt ; real_T
gerzgcs13z ; real_T kjmkqrsqg5 ; real_T og20cizxfy ; } gc3zyrmkte ; typedef
struct { ZCSigState mlxecqtrje ; ZCSigState ngk0wcdrnu ; ZCSigState
ff4rhabsnx ; ZCSigState kwwzhs0kuv ; ZCSigState ovhihjhxif ; ZCSigState
jwptro0zy3 ; ZCSigState p0qnnlgb0i ; ZCSigState cxqdx0eq0f ; ZCSigState
lilrdpp43c ; ZCSigState g1o15fmoaf ; ZCSigState hrygtd4oc3 ; ZCSigState
lab3z3xllo ; ZCSigState o1cuauycpy ; ZCSigState iokdtmwdp4 ; ZCSigState
ppnlywgcox ; ZCSigState enxxzhlqx4 ; ZCSigState epj5hlsojq ; ZCSigState
h3aiuerfai ; ZCSigState kchgqgj5dc ; ZCSigState mhzehk1kgi ; ZCSigState
nqtak4o1ff ; ZCSigState noyhoh3pbt ; ZCSigState nh50kilyon ; ZCSigState
gk0t1wik3t ; ZCSigState a5gas2i5z3 ; ZCSigState as3zbg1gjs ; ZCSigState
fixw5rkbyh ; ZCSigState annftjbmz2 ; ZCSigState ay0aqo02mf ; ZCSigState
idquqp3ktx ; ZCSigState dh11jw4c2c ; ZCSigState bte4dl2adl ; ZCSigState
ahucrqatiz ; ZCSigState edbxxm2fqh ; ZCSigState mgtqzc10b2 ; ZCSigState
ikgw5sis03 ; ZCSigState c1s2p1thdi ; ZCSigState p12lqcyekt ; ZCSigState
bktycoagiw ; ZCSigState hsedsyzr5r ; ZCSigState hsoq1eq4o1 ; ZCSigState
lbhypq4de2 ; ZCSigState bwwxs0crg2 ; ZCSigState ciicfntx2c ; ZCSigState
lnima25ce3 ; ZCSigState fjlzpixfaa ; ZCSigState d3045gwgkd ; ZCSigState
e2yzzswat1 ; ZCSigState mwmk4yitxg ; ZCSigState m3ppkduowi ; ZCSigState
jjybpbd4w3 ; ZCSigState a2kzemtcxg ; ZCSigState dpjtx2b051 ; ZCSigState
mrdatirvny ; ZCSigState dlejasolrc ; ZCSigState bqyy1by1mf ; ZCSigState
hdenqdqbww ; ZCSigState amkxrdj525 ; ZCSigState eirgxo3qvd ; ZCSigState
exvvco3ikp ; ZCSigState awkcvnyujp ; ZCSigState ds3p5yaihx ; ZCSigState
jn5d5o420p ; ZCSigState fdgwatm34s ; ZCSigState mik3yildjk ; ZCSigState
pzvfkcjgcu ; ZCSigState mhweeehout ; ZCSigState ouzwfx3aom ; ZCSigState
gomjaw2saj ; ZCSigState n530b05utb ; ZCSigState mnorvk0jfi ; ZCSigState
gr4ysh2v3r ; ZCSigState dcywm44y04 ; ZCSigState hkhladeebg ; ZCSigState
ljxphkdkss ; ZCSigState g5q1ymdzg3 ; ZCSigState eyt1hohpcm ; ZCSigState
lw0ezxrffi ; ZCSigState caqz4pfbmp ; ZCSigState luidgbpl4s ; ZCSigState
lbvzcozha2 ; ZCSigState gilnhii4pz ; ZCSigState osra4htg5l ; ZCSigState
hh41w50wo0 ; ZCSigState ityqltkarl ; ZCSigState juzbz2dal1 ; ZCSigState
cvu3gfafrg ; ZCSigState ekskkmkgra ; ZCSigState hqk3we103y ; ZCSigState
llrucfnnwg ; ZCSigState fji3uptgaw ; ZCSigState d2ipbdrl0r ; ZCSigState
puz1ytlnyk ; ZCSigState czzfk15fgz ; ZCSigState hzoigqkean ; ZCSigState
fx1qvmptfh ; ZCSigState caiydze5hd ; ZCSigState bl2v5vyxlz ; ZCSigState
pemb5zt33u ; ZCSigState po5fdclhwv ; ZCSigState hacp0coe42 ; ZCSigState
as1wrcyva4 ; ZCSigState dnqbo40ogy ; ZCSigState poa4d5zhpb ; ZCSigState
filq2jvrnz ; ZCSigState cjbabggjqm ; ZCSigState gmwr1v00fj ; ZCSigState
mvr3y2l4yj ; ZCSigState mq4ne0cmiv ; ZCSigState ps23gg30gg ; ZCSigState
ezfo12qj5x ; ZCSigState idb1sojbvl ; ZCSigState j0r2gp30fu ; ZCSigState
icityepkbb ; ZCSigState oqjrjfioz1 ; ZCSigState ou1ryc1onl ; ZCSigState
euy324bfvy ; ZCSigState n20dsdrxcm ; ZCSigState fat5zkq2xl ; ZCSigState
lrswdpok2y ; ZCSigState ffnezqsmtf ; ZCSigState nmjqal5p0j ; ZCSigState
dyaughxrel ; ZCSigState eeulbjlvjh ; ZCSigState byux1p11zl ; ZCSigState
gsmjmocyos ; ZCSigState iartorfrc0 ; ZCSigState h3tnrefcyh ; ZCSigState
fkstyewsai ; ZCSigState puxbehbrhz ; ZCSigState jntvtwahqm ; ZCSigState
gf1zj0yrn3 ; ZCSigState lhz55jbdqz ; ZCSigState ev1fhm43ky ; ZCSigState
bi1ic3w2sb ; ZCSigState gfsxlvcrq1 ; ZCSigState mm3qimeqbu ; ZCSigState
jg32wtr3kl ; ZCSigState dfqnpbuus2 ; ZCSigState azyfoe014e ; ZCSigState
eu5fbmdsxj ; ZCSigState hoiu2uawgf ; ZCSigState ei2lqjfqrr ; ZCSigState
mnpdctjhtz ; ZCSigState nvz0yz3mtl ; ZCSigState begrnficso ; ZCSigState
mhjr3xfoxf ; ZCSigState j2jvkg5m5e ; ZCSigState bo3alvyqie ; ZCSigState
cvuju41nq0 ; ZCSigState erozhprdf0 ; ZCSigState dwn4mtjdkd ; ZCSigState
ds15mafivd ; ZCSigState hz5ytiiogx ; ZCSigState fbfy1wlx5x ; ZCSigState
nxvewe5t3x ; ZCSigState hak04pxnet ; ZCSigState nsx0ci1xae ; ZCSigState
dgj2ocsqim ; ZCSigState jwjilm3ep4 ; ZCSigState kjt3vgjyjg ; ZCSigState
jhraydb5xg ; ZCSigState ezfuzxnnsh ; ZCSigState gsyjj0xgcd ; ZCSigState
dd3l04s4t1 ; ZCSigState lne5ukw1ap ; ZCSigState pwujmlf233 ; ZCSigState
nzdynrpxvo ; ZCSigState ggnuyvl404 ; ZCSigState bbvq1zhcz5 ; ZCSigState
avm4oumper ; ZCSigState ijuvfowzz4 ; ZCSigState mvospkzs2s ; ZCSigState
nvelmr12gd ; ZCSigState akunx3s4fv ; ZCSigState egdkbqxbwy ; ZCSigState
amhgjdptjw ; ZCSigState hwb5as3plm ; ZCSigState j4kjbo5ytw ; } ogxqfi43kv ;
typedef struct { int_T ir [ 1 ] ; int_T jc [ 115 + 1 ] ; real_T pr [ 1 ] ; }
eaegy5bnt4 ; struct p1a5tgug2l_ { real_T P_0 ; real_T P_1 ; real_T P_2 ;
real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ; real_T P_7 ; real_T P_8 ;
real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T
P_14 ; real_T P_15 ; real_T P_16 ; real_T P_17 ; real_T P_18 ; real_T P_19 ;
real_T P_20 ; } ; extern p1a5tgug2l fpow22vapl ;
#endif
