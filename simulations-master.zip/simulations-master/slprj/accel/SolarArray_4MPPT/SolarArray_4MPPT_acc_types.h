#include "__cf_SolarArray_4MPPT.h"
#ifndef RTW_HEADER_SolarArray_4MPPT_acc_types_h_
#define RTW_HEADER_SolarArray_4MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct p1a5tgug2l_ p1a5tgug2l ;
#endif
