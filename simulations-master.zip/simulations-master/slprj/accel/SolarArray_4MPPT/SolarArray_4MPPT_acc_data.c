#include "__cf_SolarArray_4MPPT.h"
#include "SolarArray_4MPPT_acc.h"
#include "SolarArray_4MPPT_acc_private.h"
p1a5tgug2l fpow22vapl = { 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 0.0 , 0.0 , 0.0 , 700.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.5 , 0.0 , 0.0 } ;
