#include "__cf_SolarArray4MPPT.h"
#ifndef RTW_HEADER_SolarArray4MPPT_acc_types_h_
#define RTW_HEADER_SolarArray4MPPT_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct mcayb5owbc_ mcayb5owbc ;
#endif
