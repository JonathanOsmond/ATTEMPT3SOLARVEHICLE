#include "__cf_SolarArray4MPPT.h"
#ifndef RTW_HEADER_SolarArray4MPPT_acc_h_
#define RTW_HEADER_SolarArray4MPPT_acc_h_
#include <stddef.h>
#ifndef SolarArray4MPPT_acc_COMMON_INCLUDES_
#define SolarArray4MPPT_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SolarArray4MPPT_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T ds5liothwy ; real_T cnme3mofvw [ 4 ] ; real_T
hntom54zzd ; real_T joh01apd5l [ 4 ] ; real_T ivnpy5wui0 ; real_T pioxdtnf10
[ 4 ] ; real_T pu11euisot ; real_T jhhew1tffn [ 4 ] ; real_T ouhfnbms2u [ 4 ]
; real_T h1mrb1pjbk [ 4 ] ; real_T lrtf21g4mf [ 4 ] ; real_T nhphqb0gig ;
real_T jgtfqmhxd1 [ 4 ] ; real_T p32ztt1cmi ; real_T cg30p3ajiq [ 4 ] ;
real_T llemrxdjiz [ 4 ] ; real_T afzwvr45vq [ 4 ] ; real_T dywnbja5gl [ 4 ] ;
real_T hf2q4eeidk ; real_T jhdswbtmeh [ 4 ] ; real_T jqmufyejrl [ 4 ] ;
real_T hahy5eltjv ; real_T c5ktyfphyi [ 4 ] ; real_T b2in51hfrp [ 4 ] ;
real_T n4aifowshw ; real_T erim1pilme [ 4 ] ; real_T fsynsgmjgc ; real_T
dpizgjgex0 [ 4 ] ; real_T lluxbjhchj [ 4 ] ; real_T o2irgkud4x [ 4 ] ; real_T
d1qi3hlcez ; real_T ingrbdlb5k [ 4 ] ; real_T arug0svcva [ 4 ] ; real_T
ocvgih13yj [ 4 ] ; real_T lf3i5j401j [ 4 ] ; real_T osppbfeygr ; real_T
dwliet05fy ; real_T k0zepwna4f ; real_T evmyj54qqp ; real_T iw22ysw3ue ;
real_T dck4vfveza ; real_T b2pa1ef2wz [ 4 ] ; real_T os135qdcah [ 225 ] ;
real_T aluqmryxvr [ 3 ] ; real_T enesdf3izz [ 2 ] ; real_T geg0hajrf5 [ 2 ] ;
real_T n2kpx2cwjk [ 2 ] ; } oggo3ouij4 ; typedef struct { real_T iqqnbkugdv [
2 ] ; real_T a2fygfdqtr [ 2 ] ; real_T prcfnkytep [ 2 ] ; real_T jyhmf2vsuv [
2 ] ; real_T ndss5lilet [ 2 ] ; real_T hr44ptz0i0 [ 2 ] ; real_T jxgglxqqdw [
2 ] ; real_T c1msiokleh [ 2 ] ; real_T mmqog3wzb0 [ 2 ] ; real_T e22q2fnxif [
2 ] ; real_T bp5opm2kzx [ 2 ] ; real_T d0af1qy52l [ 2 ] ; real_T lszu111noc [
2 ] ; real_T jtta1nuil1 [ 2 ] ; real_T ld3bmkvp4k [ 2 ] ; real_T pslgwxpv1m [
2 ] ; real_T i0xtqu1z3b [ 2 ] ; real_T desn1i1nq1 [ 2 ] ; real_T j3x3glyl3h [
2 ] ; real_T cugjnvyxwa [ 2 ] ; real_T oy5hpncban [ 2 ] ; real_T bh2mx11oog [
2 ] ; real_T k2tuxbjsrh [ 2 ] ; real_T pydejdjctd [ 2 ] ; real_T mcmiwizdzk [
2 ] ; void * d0k5uk1bip ; void * prb3r4v51w ; void * g1uoszvww0 ; void *
n51a2cl32l ; void * gtjyyzhdq5 ; void * dxjlrquyru ; void * glikbryklt ; void
* n41vpwywn2 ; void * nde5narhis ; void * afpcw0hny1 ; void * b3cclfbfx0 [ 3
] ; void * dvgzhnyzc4 ; void * m0u0r1gn0b ; int_T fgaggfvysa [ 134 ] ; int_T
oj22sl2wai ; int32_T pnuonqk3pf ; boolean_T lwxmgw4s4r ; boolean_T ikowi14eev
; char_T bngwxzgl3l [ 6 ] ; } puetfg5lx3 ; typedef struct { real_T gs3ayt4fzs
[ 91 ] ; } jkp3iubwyy ; typedef struct { real_T gs3ayt4fzs [ 91 ] ; }
g4zgfosoxb ; typedef struct { boolean_T gs3ayt4fzs [ 91 ] ; } d3gnu2pfq2 ;
typedef struct { real_T gs3ayt4fzs [ 91 ] ; } ii2amel34b ; typedef struct {
real_T jlso4tscbk ; real_T flpsumcmtb ; real_T bzdccph2mp ; real_T ddlmtg4ydz
; real_T ish2nwibjj ; real_T dgeevt42dt ; real_T jlbdsnl4oh ; real_T
ivg0w1oi5x ; real_T iq3054e3mf ; real_T k4pttshw0a ; real_T at1i0aa5vj ;
real_T eqxtxwq1hh ; real_T glmmtkffrm ; real_T e5gdep1ljh ; real_T bhwpbs2lfv
; real_T mcifo3ggbt ; real_T kie1ptjlup ; real_T g0fjvnlpfc ; real_T
go3thvdouf ; real_T hzosa5xfls ; real_T bcnlpnwvcu ; real_T aecu45jzba ;
real_T cgzdi5ieil ; real_T ake5351ddp ; real_T aowzbylfmx ; real_T hun31gdooc
; real_T nyolz34hsf ; real_T ayrovtjv1g ; real_T hetcgwavp2 ; real_T
hhaia13rij ; real_T nugkgoctoc ; real_T gizgakmfsl ; real_T eui0akay0i ;
real_T n2m3s1m0wu ; real_T eq3rd4v1mo ; real_T clzeprt3nx ; real_T j1sf00hslq
; real_T fuji3ws0op ; real_T o4zsq4lbdj ; real_T kyot2jjyq5 ; real_T
bdeotbko4d ; real_T b0t0umi2ii ; real_T i3zrw3ibvb ; real_T g5affh5o0o ;
real_T f4lg04iyns ; real_T ouz1w0ddhp ; real_T i4b35ozmr0 ; real_T gi0iq4a5hc
; real_T jcae5t4cad ; real_T fk4exv5hi5 ; real_T axeiao0elk ; real_T
pdz0chljhn ; real_T pdnpeexe3a ; real_T dj4pzmuivy ; real_T bvuzgq0s3c ;
real_T j1i23r51s2 ; real_T lidhyskoyr ; real_T o3qsqzv14t ; real_T ksv51pzms1
; real_T cxv5hjyzrd ; real_T f0gftubgy4 ; real_T lbd3fxjwpo ; real_T
mpz04e0p52 ; real_T arw5sgh0r2 ; real_T n05nvirvci ; real_T h1lwqwxut1 ;
real_T p0xo2r4sfi ; real_T nev3fogib1 ; real_T orobteps1y ; real_T c4tjbkilvt
; real_T kicknmevcn ; real_T kuyyl4lvsm ; real_T oc503dii3a ; real_T
cmfs54z3gf ; real_T ivy3vmochu ; real_T mfopw4dda4 ; real_T bcwfjia4vt ;
real_T oi5gzpqzpn ; real_T gylew5ns55 ; real_T bol14nubb2 ; real_T nkrg04igxo
; real_T e4rteohygj ; real_T h00fkhiqef ; real_T j3t5u534ua ; real_T
iqb033dllg ; real_T nrtkqr22cw ; real_T hy0mh1yhfd ; real_T kxyrjkq4to ;
real_T hthpg04rvj ; real_T gh53hh3ulu ; real_T auz3y5ihnc ; real_T j4cgltzgmp
; real_T krjj4dw21j ; real_T cev4swpwj0 ; real_T iap0bjuohh ; real_T
olljoymwbq ; real_T hx43zphj0w ; real_T dpcdx3jw5s ; real_T lapiazanzz ;
real_T o5zzldzkfg ; real_T ly2dtfp55g ; real_T gvvne3tolb ; real_T pxsbaeblzc
; real_T dleteghc34 ; real_T jahepkxmvw ; real_T iyarq2scwi ; real_T
bvvarykwyz ; real_T ajaqjxn0vw ; real_T mk24zpjc2k ; real_T or3mpti1cc ;
real_T neuxf4ljyk ; real_T pdomf1514v ; real_T nsi01uftuf ; real_T okfs2l0nqm
; real_T d3uz0ycfq0 ; real_T n1xloclx51 ; real_T csr0rrqspt ; real_T
cenvt2xsot ; real_T psgljb1kv5 ; real_T g0xgmirfkp ; real_T hyyyvqxclg ;
real_T bmz3yagzyu ; real_T ncwregcuvs ; real_T avb3u2l5bi ; real_T moqz5x4epl
; real_T oawkfildqk ; real_T eosf1umlat ; real_T lqholodsfq ; real_T
delegqnwak ; real_T gig1vydwik ; real_T js2x1ndzdy ; real_T crkjvvueym ;
real_T cogcsuxcdl ; real_T ogh2qwxdps ; real_T cg4ttta2ye ; } i4kjmfay0h ;
typedef struct { ZCSigState equfwc0ext ; ZCSigState jsvxq3lvnh ; ZCSigState
mdxg3u0ueu ; ZCSigState o1o0l2cuuk ; ZCSigState dzaqljazcv ; ZCSigState
hxisyn1p0j ; ZCSigState kuxi02a2tb ; ZCSigState f2hvheota2 ; ZCSigState
hnof5gnpr5 ; ZCSigState gbxcealwow ; ZCSigState bv10hscm54 ; ZCSigState
p1vv3pbtq5 ; ZCSigState errosv1bqj ; ZCSigState p1rzsuoqzq ; ZCSigState
dlia13etut ; ZCSigState hkwunzyl2r ; ZCSigState ckr5cofbx0 ; ZCSigState
lp54v3jhe3 ; ZCSigState fka3vyk55t ; ZCSigState bzq1juzhqv ; ZCSigState
dyrndhaypc ; ZCSigState if0yrchxk5 ; ZCSigState ni23cw5sot ; ZCSigState
pst3hi44ew ; ZCSigState jxjnppvtcv ; ZCSigState itdhjwx2pt ; ZCSigState
et3pbd2p4g ; ZCSigState gyc2n12t2g ; ZCSigState dhuxrkv1zh ; ZCSigState
cswkon25u0 ; ZCSigState nc3ezjdabr ; ZCSigState kiqeyz24lp ; ZCSigState
ndg3yfkudq ; ZCSigState k532qbevxr ; ZCSigState hbvznvncky ; ZCSigState
ltyncjlvue ; ZCSigState hqs0ziplrh ; ZCSigState anbgi1ngaj ; ZCSigState
mmb3psigq0 ; ZCSigState is50cdt2x0 ; ZCSigState bzlq0xwsdv ; ZCSigState
fv2gvazm0b ; ZCSigState aaryqqnjvs ; ZCSigState pscuk23wn2 ; ZCSigState
iql4up3er4 ; ZCSigState lsy2fx0jin ; ZCSigState o44lk0puha ; ZCSigState
iry5aamvop ; ZCSigState npizfk1slg ; ZCSigState kntr1mth0d ; ZCSigState
plcldcofg3 ; ZCSigState j2bcg5mgi5 ; ZCSigState l3cxhtxdjn ; ZCSigState
pvlqn4sch5 ; ZCSigState amjizb4hhr ; ZCSigState pi0gqqym4y ; ZCSigState
nca1vnlpyp ; ZCSigState nhnbugi0gy ; ZCSigState kt4toa2hwr ; ZCSigState
doblwnm5va ; ZCSigState ae3igcdmqi ; ZCSigState pafwc40hre ; ZCSigState
c3u5bwlt44 ; ZCSigState gfcotnajja ; ZCSigState otkceyskwx ; ZCSigState
crp1dkffd4 ; ZCSigState gunv1unpwk ; ZCSigState dh10pbq3za ; ZCSigState
mur0rtvevi ; ZCSigState fozoewccaj ; ZCSigState g5dpay3ja3 ; ZCSigState
fqao4acn22 ; ZCSigState m3okss1fkv ; ZCSigState l1l0n5pgbi ; ZCSigState
pf0t12hkga ; ZCSigState gj4ned5ukn ; ZCSigState k0bnoxyitm ; ZCSigState
f2b3sgg2od ; ZCSigState acui2ezj0b ; ZCSigState nyx1ycv3sm ; ZCSigState
exmgl5xzie ; ZCSigState mbxralq3rd ; ZCSigState h3v2hwyybs ; ZCSigState
nnvx43ssyx ; ZCSigState lncj5jd5lj ; ZCSigState ktieem30lc ; ZCSigState
dtljudrtwu ; ZCSigState fy33msqify ; ZCSigState a2uiehodbw ; ZCSigState
bny1ak3fmq ; ZCSigState ax4cwkjql1 ; ZCSigState cvrpfjkzkz ; ZCSigState
mpx1rcwltd ; ZCSigState n0gddj1d1a ; ZCSigState anmvxy4ubu ; ZCSigState
jrhdfsllgr ; ZCSigState dhlplem03a ; ZCSigState huxgewt2yg ; ZCSigState
irrhm441to ; ZCSigState bnk3nntide ; ZCSigState hyxwutavrk ; ZCSigState
lb5ilgvtpm ; ZCSigState clpxwpodft ; ZCSigState pcg55vmokn ; ZCSigState
o5k5mhcrey ; ZCSigState bi1nqzkdc4 ; ZCSigState dkurh5iuuv ; ZCSigState
c0jhbpgsjp ; ZCSigState jq5iyovxqg ; ZCSigState g3r4rdcmap ; ZCSigState
b0k2l5jl21 ; ZCSigState cienlfe2mx ; ZCSigState cwrupudfdg ; ZCSigState
cr3qxvruhl ; ZCSigState mrdmmddfnl ; ZCSigState crhmaz05bx ; ZCSigState
a33m5cnivy ; ZCSigState pqzkju2s1n ; ZCSigState lldajqqmhr ; ZCSigState
jy2xyfdsxp ; ZCSigState g4h53nv0nk ; ZCSigState iq5z1sey0d ; ZCSigState
bpdgnbuozk ; ZCSigState fgriigw2nc ; ZCSigState lq22jwkwvu ; ZCSigState
fr00ksxusw ; ZCSigState i3rnxu4gip ; ZCSigState p5dtgnvvv0 ; ZCSigState
gjfva5w11q ; ZCSigState on5dwtthnb ; ZCSigState pqbqjtmey2 ; ZCSigState
o5efi4dzcl ; ZCSigState lxfvkfdsew ; ZCSigState o44b4decgp ; ZCSigState
c5eigh2nrf ; } hcijjc2zfq ; typedef struct { int_T ir [ 1 ] ; int_T jc [ 91 +
1 ] ; real_T pr [ 1 ] ; } domsc3hslp ; struct mcayb5owbc_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; } ; extern mcayb5owbc
j0gwlqmbjf ;
#endif
