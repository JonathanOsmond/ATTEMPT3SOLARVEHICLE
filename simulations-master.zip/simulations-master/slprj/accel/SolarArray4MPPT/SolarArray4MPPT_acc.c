#include "__cf_SolarArray4MPPT.h"
#include <math.h>
#include "SolarArray4MPPT_acc.h"
#include "SolarArray4MPPT_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T mpjnrrbwxh ;
real_T currentTime ; oggo3ouij4 * _rtB ; mcayb5owbc * _rtP ; puetfg5lx3 *
_rtDW ; _rtDW = ( ( puetfg5lx3 * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
mcayb5owbc * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( oggo3ouij4 * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> cnme3mofvw [ 0 ] = _rtB -> ds5liothwy ;
_rtB -> cnme3mofvw [ 1 ] = 0.0 ; _rtB -> cnme3mofvw [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> iqqnbkugdv [ 0 ] = ! ( _rtB ->
cnme3mofvw [ 0 ] == _rtDW -> iqqnbkugdv [ 1 ] ) ; _rtDW -> iqqnbkugdv [ 1 ] =
_rtB -> cnme3mofvw [ 0 ] ; } _rtB -> cnme3mofvw [ 3 ] = _rtDW -> iqqnbkugdv [
0 ] ; _rtB -> joh01apd5l [ 0 ] = _rtB -> hntom54zzd ; _rtB -> joh01apd5l [ 1
] = 0.0 ; _rtB -> joh01apd5l [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> a2fygfdqtr [ 0 ] = ! ( _rtB -> joh01apd5l [ 0 ] == _rtDW ->
a2fygfdqtr [ 1 ] ) ; _rtDW -> a2fygfdqtr [ 1 ] = _rtB -> joh01apd5l [ 0 ] ; }
_rtB -> joh01apd5l [ 3 ] = _rtDW -> a2fygfdqtr [ 0 ] ; _rtB -> pioxdtnf10 [ 0
] = _rtB -> ivnpy5wui0 ; _rtB -> pioxdtnf10 [ 1 ] = 0.0 ; _rtB -> pioxdtnf10
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> prcfnkytep [ 0 ] = !
( _rtB -> pioxdtnf10 [ 0 ] == _rtDW -> prcfnkytep [ 1 ] ) ; _rtDW ->
prcfnkytep [ 1 ] = _rtB -> pioxdtnf10 [ 0 ] ; } _rtB -> pioxdtnf10 [ 3 ] =
_rtDW -> prcfnkytep [ 0 ] ; _rtB -> jhhew1tffn [ 0 ] = _rtB -> pu11euisot ;
_rtB -> jhhew1tffn [ 1 ] = 0.0 ; _rtB -> jhhew1tffn [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> jyhmf2vsuv [ 0 ] = ! ( _rtB ->
jhhew1tffn [ 0 ] == _rtDW -> jyhmf2vsuv [ 1 ] ) ; _rtDW -> jyhmf2vsuv [ 1 ] =
_rtB -> jhhew1tffn [ 0 ] ; } _rtB -> jhhew1tffn [ 3 ] = _rtDW -> jyhmf2vsuv [
0 ] ; _rtB -> ouhfnbms2u [ 0 ] = _rtB -> pu11euisot ; _rtB -> ouhfnbms2u [ 1
] = 0.0 ; _rtB -> ouhfnbms2u [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> ndss5lilet [ 0 ] = ! ( _rtB -> ouhfnbms2u [ 0 ] == _rtDW ->
ndss5lilet [ 1 ] ) ; _rtDW -> ndss5lilet [ 1 ] = _rtB -> ouhfnbms2u [ 0 ] ; }
_rtB -> ouhfnbms2u [ 3 ] = _rtDW -> ndss5lilet [ 0 ] ; _rtB -> h1mrb1pjbk [ 0
] = _rtB -> ivnpy5wui0 ; _rtB -> h1mrb1pjbk [ 1 ] = 0.0 ; _rtB -> h1mrb1pjbk
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> hr44ptz0i0 [ 0 ] = !
( _rtB -> h1mrb1pjbk [ 0 ] == _rtDW -> hr44ptz0i0 [ 1 ] ) ; _rtDW ->
hr44ptz0i0 [ 1 ] = _rtB -> h1mrb1pjbk [ 0 ] ; } _rtB -> h1mrb1pjbk [ 3 ] =
_rtDW -> hr44ptz0i0 [ 0 ] ; _rtB -> lrtf21g4mf [ 0 ] = _rtB -> hntom54zzd ;
_rtB -> lrtf21g4mf [ 1 ] = 0.0 ; _rtB -> lrtf21g4mf [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> jxgglxqqdw [ 0 ] = ! ( _rtB ->
lrtf21g4mf [ 0 ] == _rtDW -> jxgglxqqdw [ 1 ] ) ; _rtDW -> jxgglxqqdw [ 1 ] =
_rtB -> lrtf21g4mf [ 0 ] ; } _rtB -> lrtf21g4mf [ 3 ] = _rtDW -> jxgglxqqdw [
0 ] ; _rtB -> jgtfqmhxd1 [ 0 ] = _rtB -> nhphqb0gig ; _rtB -> jgtfqmhxd1 [ 1
] = 0.0 ; _rtB -> jgtfqmhxd1 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> c1msiokleh [ 0 ] = ! ( _rtB -> jgtfqmhxd1 [ 0 ] == _rtDW ->
c1msiokleh [ 1 ] ) ; _rtDW -> c1msiokleh [ 1 ] = _rtB -> jgtfqmhxd1 [ 0 ] ; }
_rtB -> jgtfqmhxd1 [ 3 ] = _rtDW -> c1msiokleh [ 0 ] ; _rtB -> cg30p3ajiq [ 0
] = _rtB -> p32ztt1cmi ; _rtB -> cg30p3ajiq [ 1 ] = 0.0 ; _rtB -> cg30p3ajiq
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> mmqog3wzb0 [ 0 ] = !
( _rtB -> cg30p3ajiq [ 0 ] == _rtDW -> mmqog3wzb0 [ 1 ] ) ; _rtDW ->
mmqog3wzb0 [ 1 ] = _rtB -> cg30p3ajiq [ 0 ] ; } _rtB -> cg30p3ajiq [ 3 ] =
_rtDW -> mmqog3wzb0 [ 0 ] ; _rtB -> llemrxdjiz [ 0 ] = _rtB -> ds5liothwy ;
_rtB -> llemrxdjiz [ 1 ] = 0.0 ; _rtB -> llemrxdjiz [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> e22q2fnxif [ 0 ] = ! ( _rtB ->
llemrxdjiz [ 0 ] == _rtDW -> e22q2fnxif [ 1 ] ) ; _rtDW -> e22q2fnxif [ 1 ] =
_rtB -> llemrxdjiz [ 0 ] ; } _rtB -> llemrxdjiz [ 3 ] = _rtDW -> e22q2fnxif [
0 ] ; _rtB -> afzwvr45vq [ 0 ] = _rtB -> p32ztt1cmi ; _rtB -> afzwvr45vq [ 1
] = 0.0 ; _rtB -> afzwvr45vq [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> bp5opm2kzx [ 0 ] = ! ( _rtB -> afzwvr45vq [ 0 ] == _rtDW ->
bp5opm2kzx [ 1 ] ) ; _rtDW -> bp5opm2kzx [ 1 ] = _rtB -> afzwvr45vq [ 0 ] ; }
_rtB -> afzwvr45vq [ 3 ] = _rtDW -> bp5opm2kzx [ 0 ] ; _rtB -> dywnbja5gl [ 0
] = _rtB -> nhphqb0gig ; _rtB -> dywnbja5gl [ 1 ] = 0.0 ; _rtB -> dywnbja5gl
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> d0af1qy52l [ 0 ] = !
( _rtB -> dywnbja5gl [ 0 ] == _rtDW -> d0af1qy52l [ 1 ] ) ; _rtDW ->
d0af1qy52l [ 1 ] = _rtB -> dywnbja5gl [ 0 ] ; } _rtB -> dywnbja5gl [ 3 ] =
_rtDW -> d0af1qy52l [ 0 ] ; _rtB -> jhdswbtmeh [ 0 ] = _rtB -> hf2q4eeidk ;
_rtB -> jhdswbtmeh [ 1 ] = 0.0 ; _rtB -> jhdswbtmeh [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> lszu111noc [ 0 ] = ! ( _rtB ->
jhdswbtmeh [ 0 ] == _rtDW -> lszu111noc [ 1 ] ) ; _rtDW -> lszu111noc [ 1 ] =
_rtB -> jhdswbtmeh [ 0 ] ; } _rtB -> jhdswbtmeh [ 3 ] = _rtDW -> lszu111noc [
0 ] ; _rtB -> jqmufyejrl [ 0 ] = _rtB -> hf2q4eeidk ; _rtB -> jqmufyejrl [ 1
] = 0.0 ; _rtB -> jqmufyejrl [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> jtta1nuil1 [ 0 ] = ! ( _rtB -> jqmufyejrl [ 0 ] == _rtDW ->
jtta1nuil1 [ 1 ] ) ; _rtDW -> jtta1nuil1 [ 1 ] = _rtB -> jqmufyejrl [ 0 ] ; }
_rtB -> jqmufyejrl [ 3 ] = _rtDW -> jtta1nuil1 [ 0 ] ; _rtB -> c5ktyfphyi [ 0
] = _rtB -> hahy5eltjv ; _rtB -> c5ktyfphyi [ 1 ] = 0.0 ; _rtB -> c5ktyfphyi
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> ld3bmkvp4k [ 0 ] = !
( _rtB -> c5ktyfphyi [ 0 ] == _rtDW -> ld3bmkvp4k [ 1 ] ) ; _rtDW ->
ld3bmkvp4k [ 1 ] = _rtB -> c5ktyfphyi [ 0 ] ; } _rtB -> c5ktyfphyi [ 3 ] =
_rtDW -> ld3bmkvp4k [ 0 ] ; _rtB -> b2in51hfrp [ 0 ] = _rtB -> hahy5eltjv ;
_rtB -> b2in51hfrp [ 1 ] = 0.0 ; _rtB -> b2in51hfrp [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> pslgwxpv1m [ 0 ] = ! ( _rtB ->
b2in51hfrp [ 0 ] == _rtDW -> pslgwxpv1m [ 1 ] ) ; _rtDW -> pslgwxpv1m [ 1 ] =
_rtB -> b2in51hfrp [ 0 ] ; } _rtB -> b2in51hfrp [ 3 ] = _rtDW -> pslgwxpv1m [
0 ] ; _rtB -> erim1pilme [ 0 ] = _rtB -> n4aifowshw ; _rtB -> erim1pilme [ 1
] = 0.0 ; _rtB -> erim1pilme [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> i0xtqu1z3b [ 0 ] = ! ( _rtB -> erim1pilme [ 0 ] == _rtDW ->
i0xtqu1z3b [ 1 ] ) ; _rtDW -> i0xtqu1z3b [ 1 ] = _rtB -> erim1pilme [ 0 ] ; }
_rtB -> erim1pilme [ 3 ] = _rtDW -> i0xtqu1z3b [ 0 ] ; _rtB -> dpizgjgex0 [ 0
] = _rtB -> fsynsgmjgc ; _rtB -> dpizgjgex0 [ 1 ] = 0.0 ; _rtB -> dpizgjgex0
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> desn1i1nq1 [ 0 ] = !
( _rtB -> dpizgjgex0 [ 0 ] == _rtDW -> desn1i1nq1 [ 1 ] ) ; _rtDW ->
desn1i1nq1 [ 1 ] = _rtB -> dpizgjgex0 [ 0 ] ; } _rtB -> dpizgjgex0 [ 3 ] =
_rtDW -> desn1i1nq1 [ 0 ] ; _rtB -> lluxbjhchj [ 0 ] = _rtB -> n4aifowshw ;
_rtB -> lluxbjhchj [ 1 ] = 0.0 ; _rtB -> lluxbjhchj [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> j3x3glyl3h [ 0 ] = ! ( _rtB ->
lluxbjhchj [ 0 ] == _rtDW -> j3x3glyl3h [ 1 ] ) ; _rtDW -> j3x3glyl3h [ 1 ] =
_rtB -> lluxbjhchj [ 0 ] ; } _rtB -> lluxbjhchj [ 3 ] = _rtDW -> j3x3glyl3h [
0 ] ; _rtB -> o2irgkud4x [ 0 ] = _rtB -> fsynsgmjgc ; _rtB -> o2irgkud4x [ 1
] = 0.0 ; _rtB -> o2irgkud4x [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> cugjnvyxwa [ 0 ] = ! ( _rtB -> o2irgkud4x [ 0 ] == _rtDW ->
cugjnvyxwa [ 1 ] ) ; _rtDW -> cugjnvyxwa [ 1 ] = _rtB -> o2irgkud4x [ 0 ] ; }
_rtB -> o2irgkud4x [ 3 ] = _rtDW -> cugjnvyxwa [ 0 ] ; _rtB -> ingrbdlb5k [ 0
] = _rtB -> d1qi3hlcez ; _rtB -> ingrbdlb5k [ 1 ] = 0.0 ; _rtB -> ingrbdlb5k
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> oy5hpncban [ 0 ] = !
( _rtB -> ingrbdlb5k [ 0 ] == _rtDW -> oy5hpncban [ 1 ] ) ; _rtDW ->
oy5hpncban [ 1 ] = _rtB -> ingrbdlb5k [ 0 ] ; } _rtB -> ingrbdlb5k [ 3 ] =
_rtDW -> oy5hpncban [ 0 ] ; _rtB -> arug0svcva [ 0 ] = _rtB -> d1qi3hlcez ;
_rtB -> arug0svcva [ 1 ] = 0.0 ; _rtB -> arug0svcva [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> bh2mx11oog [ 0 ] = ! ( _rtB ->
arug0svcva [ 0 ] == _rtDW -> bh2mx11oog [ 1 ] ) ; _rtDW -> bh2mx11oog [ 1 ] =
_rtB -> arug0svcva [ 0 ] ; } _rtB -> arug0svcva [ 3 ] = _rtDW -> bh2mx11oog [
0 ] ; _rtB -> ocvgih13yj [ 0 ] = _rtB -> ds5liothwy ; _rtB -> ocvgih13yj [ 1
] = 0.0 ; _rtB -> ocvgih13yj [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> k2tuxbjsrh [ 0 ] = ! ( _rtB -> ocvgih13yj [ 0 ] == _rtDW ->
k2tuxbjsrh [ 1 ] ) ; _rtDW -> k2tuxbjsrh [ 1 ] = _rtB -> ocvgih13yj [ 0 ] ; }
_rtB -> ocvgih13yj [ 3 ] = _rtDW -> k2tuxbjsrh [ 0 ] ; _rtB -> lf3i5j401j [ 0
] = _rtB -> ds5liothwy ; _rtB -> lf3i5j401j [ 1 ] = 0.0 ; _rtB -> lf3i5j401j
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> pydejdjctd [ 0 ] = !
( _rtB -> lf3i5j401j [ 0 ] == _rtDW -> pydejdjctd [ 1 ] ) ; _rtDW ->
pydejdjctd [ 1 ] = _rtB -> lf3i5j401j [ 0 ] ; } _rtB -> lf3i5j401j [ 3 ] =
_rtDW -> pydejdjctd [ 0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime
= ssGetTaskTime ( S , 1 ) ; _rtDW -> oj22sl2wai = ( currentTime >= _rtP ->
P_11 ) ; if ( _rtDW -> oj22sl2wai == 1 ) { _rtB -> osppbfeygr = _rtP -> P_13
; } else { _rtB -> osppbfeygr = _rtP -> P_12 ; } } mpjnrrbwxh = ssGetT ( S )
; _rtB -> k0zepwna4f = mpjnrrbwxh - _rtB -> dwliet05fy ; _rtB -> evmyj54qqp =
_rtB -> osppbfeygr * _rtB -> k0zepwna4f ; _rtB -> dck4vfveza = _rtB ->
evmyj54qqp + _rtB -> iw22ysw3ue ; _rtB -> b2pa1ef2wz [ 0 ] = _rtB ->
dck4vfveza ; _rtB -> b2pa1ef2wz [ 1 ] = 0.0 ; _rtB -> b2pa1ef2wz [ 2 ] = 0.0
; _rtB -> b2pa1ef2wz [ 3 ] = 0.0 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 44 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> n2kpx2cwjk
[ 0 ] = _rtB -> aluqmryxvr [ 2 ] ; _rtB -> n2kpx2cwjk [ 1 ] = _rtB ->
aluqmryxvr [ 0 ] ; ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> geg0hajrf5 [ 0 ] = _rtB -> aluqmryxvr [ 2 ] ; _rtB -> geg0hajrf5 [ 1
] = _rtB -> aluqmryxvr [ 1 ] ; } ssCallAccelRunBlock ( S , 2 , 47 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 48 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> enesdf3izz [ 0 ] = _rtB -> aluqmryxvr [ 2 ] ;
_rtB -> enesdf3izz [ 1 ] = _rtB -> aluqmryxvr [ 0 ] ; ssCallAccelRunBlock ( S
, 2 , 50 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) { oggo3ouij4 * _rtB ; mcayb5owbc
* _rtP ; _rtP = ( ( mcayb5owbc * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
oggo3ouij4 * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> ds5liothwy = _rtP -> P_0
; _rtB -> hntom54zzd = _rtP -> P_1 ; _rtB -> ivnpy5wui0 = _rtP -> P_2 ; _rtB
-> pu11euisot = _rtP -> P_3 ; _rtB -> nhphqb0gig = _rtP -> P_4 ; _rtB ->
p32ztt1cmi = _rtP -> P_5 ; _rtB -> hf2q4eeidk = _rtP -> P_6 ; _rtB ->
hahy5eltjv = _rtP -> P_7 ; _rtB -> n4aifowshw = _rtP -> P_8 ; _rtB ->
fsynsgmjgc = _rtP -> P_9 ; _rtB -> d1qi3hlcez = _rtP -> P_10 ; _rtB ->
dwliet05fy = _rtP -> P_14 ; _rtB -> iw22ysw3ue = _rtP -> P_15 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { oggo3ouij4 * _rtB ;
_rtB = ( ( oggo3ouij4 * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 2 , 43 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
2 , 43 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { mcayb5owbc * _rtP ;
i4kjmfay0h * _rtZCSV ; _rtZCSV = ( ( i4kjmfay0h * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( mcayb5owbc * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
jlso4tscbk = ssGetT ( S ) - _rtP -> P_11 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 2565599914U ) ; ssSetChecksumVal ( S , 1 ,
157588587U ) ; ssSetChecksumVal ( S , 2 , 341931038U ) ; ssSetChecksumVal ( S
, 3 , 2817018942U ) ; { mxArray * slVerStructMat = NULL ; mxArray * slStrMat
= mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status =
mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if ( status
== 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 , "Version" ) ;
if ( slVerMat == NULL ) { status = 1 ; } else { status = mxGetString (
slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
puetfg5lx3 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( oggo3ouij4 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
mcayb5owbc ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & j0gwlqmbjf ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( puetfg5lx3 ) ) { {
( ( puetfg5lx3 * ) ssGetRootDWork ( S ) ) -> pnuonqk3pf = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
