#include "__cf_SolarArray4MPPT.h"
#include "SolarArray4MPPT_acc.h"
#include "SolarArray4MPPT_acc_private.h"
mcayb5owbc j0gwlqmbjf = { 392.57 , 353.31300000000005 , 0.0 , 0.0 , 0.0 , 0.0
, 0.0 , 392.57000000000005 , 0.0 , 392.57000000000005 , 392.57000000000005 ,
0.0 , 0.0 , 2.0 , 0.0 , 0.0 } ;
