#include "__cf_SolarArray_4MPPT2.h"
#ifndef RTW_HEADER_SolarArray_4MPPT2_acc_types_h_
#define RTW_HEADER_SolarArray_4MPPT2_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct mrcrm0jxvb_ mrcrm0jxvb ;
#endif
