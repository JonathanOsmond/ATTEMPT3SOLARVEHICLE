#ifndef CF_SolarArray_4MPPT2_H__
#define CF_SolarArray_4MPPT2_H__
#endif
