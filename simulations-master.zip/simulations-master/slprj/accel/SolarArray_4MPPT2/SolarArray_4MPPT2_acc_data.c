#include "__cf_SolarArray_4MPPT2.h"
#include "SolarArray_4MPPT2_acc.h"
#include "SolarArray_4MPPT2_acc_private.h"
mrcrm0jxvb k32qvmidlk = { 392.57 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 , 0.0 ,
274.79900000000004 , 196.28500000000003 , 392.57000000000005 , 0.0 , 0.0 ,
0.5 , 0.0 , 0.0 } ;
