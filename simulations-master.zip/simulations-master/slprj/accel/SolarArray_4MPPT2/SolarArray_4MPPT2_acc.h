#include "__cf_SolarArray_4MPPT2.h"
#ifndef RTW_HEADER_SolarArray_4MPPT2_acc_h_
#define RTW_HEADER_SolarArray_4MPPT2_acc_h_
#include <stddef.h>
#ifndef SolarArray_4MPPT2_acc_COMMON_INCLUDES_
#define SolarArray_4MPPT2_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "SolarArray_4MPPT2_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
typedef struct { real_T gl4zqbycev ; real_T mofz5vbiy2 [ 4 ] ; real_T
bqy0so4pet ; real_T nuexc0on5m [ 4 ] ; real_T gzwla3quzu ; real_T cm4oxwrr1n
[ 4 ] ; real_T bgugsjyqjq ; real_T ap5dnhe1c4 [ 4 ] ; real_T nsikrywcul [ 4 ]
; real_T m4sv1andz4 [ 4 ] ; real_T g3mjzkbmpz [ 4 ] ; real_T cg3obh1znk ;
real_T eylnwy1qiy [ 4 ] ; real_T nakwvrxqx2 ; real_T m5zct5hbeq [ 4 ] ;
real_T jxxkhf23ff [ 4 ] ; real_T b0ezksuzlv [ 4 ] ; real_T irsr3snper [ 4 ] ;
real_T kupr01xcmy ; real_T ex43zdrifj [ 4 ] ; real_T lxlps4rynr [ 4 ] ;
real_T docckoh30w ; real_T druun3nucx [ 4 ] ; real_T lvnu5cln0f [ 4 ] ;
real_T kv1baduwaa ; real_T hlkfredxjk [ 4 ] ; real_T b2sfywwpbz ; real_T
pa5nfiuptp [ 4 ] ; real_T lg52uwvjmt [ 4 ] ; real_T pxided2a1m [ 4 ] ; real_T
h5zijdgjfg ; real_T kf3v4w1yy0 [ 4 ] ; real_T l1glpirm2l [ 4 ] ; real_T
jnubqt1a55 [ 4 ] ; real_T aztk3z2sl2 [ 4 ] ; real_T cwidrx0imh ; real_T
jdafa2veaq ; real_T pccbbjg4ne ; real_T jkxjgk13h3 ; real_T e1vroguf5f ;
real_T focqdn31tx ; real_T i2wo3fsj2j [ 4 ] ; real_T g1endy1v3m [ 225 ] ;
real_T gyrqqbo0dl [ 3 ] ; real_T bku2h5cxlf [ 2 ] ; real_T dgfdsiigxt [ 2 ] ;
real_T li5nzdtkek [ 2 ] ; } o5ipvpmpa2 ; typedef struct { real_T nhce3zpg0n [
2 ] ; real_T kepp3otxop [ 2 ] ; real_T jsjk1l5nqh [ 2 ] ; real_T gpaigrmh5g [
2 ] ; real_T a2fjs5ue52 [ 2 ] ; real_T llwxnxmwrf [ 2 ] ; real_T cluzohdzmj [
2 ] ; real_T ljs2jvrtzb [ 2 ] ; real_T owaqyeihiv [ 2 ] ; real_T gkw1f3v5dq [
2 ] ; real_T dhjytdolsk [ 2 ] ; real_T dzv5ltiqhw [ 2 ] ; real_T mfc2dmmp1z [
2 ] ; real_T iof2yhh0p0 [ 2 ] ; real_T oqyzll4ukh [ 2 ] ; real_T p1oa3xfkrz [
2 ] ; real_T h2vekgsxkd [ 2 ] ; real_T kj3o5iu5lv [ 2 ] ; real_T d0acwttvk0 [
2 ] ; real_T bh42x4daf5 [ 2 ] ; real_T fttl1403fb [ 2 ] ; real_T jzpt0jjpuw [
2 ] ; real_T aohdf4v02w [ 2 ] ; real_T lz4a4jfzub [ 2 ] ; real_T bchrtlmbky [
2 ] ; void * ixaakztp1k ; void * nts4wahnu4 ; void * jfhbqyopad ; void *
kqz1ut4kwm ; void * cauxk1ogp1 ; void * pdw00fbxng ; void * curz53hplq ; void
* f2yi13oeow ; void * culovp4ew2 ; void * lpbf2dlnsa ; void * prwvopzk4a [ 3
] ; void * nty34te4od ; void * paz3bbm2k3 ; int_T m4w0ma3pzx [ 134 ] ; int_T
nfscce14u0 ; int32_T bb2alwd0gn ; boolean_T eym4bdtlhw ; boolean_T jfe5dykopw
; char_T hwt1gfigpx [ 6 ] ; } cfh0nr4x0p ; typedef struct { real_T gx4whtzqgi
[ 91 ] ; } gvukjrmekx ; typedef struct { real_T gx4whtzqgi [ 91 ] ; }
nh1qlfws22 ; typedef struct { boolean_T gx4whtzqgi [ 91 ] ; } brdqbeunbl ;
typedef struct { real_T gx4whtzqgi [ 91 ] ; } ocgr1gl3eu ; typedef struct {
real_T dxrr2mvo21 ; real_T l2tiwwvv4j ; real_T ophhdlhpkf ; real_T gsejxv5vhi
; real_T dhglcod2sf ; real_T p2cf3ox5ly ; real_T dtincbaaxh ; real_T
jwtxkyol3z ; real_T ja10oixwop ; real_T cc5xcjzatj ; real_T ire2oe44vr ;
real_T g14k1gkfog ; real_T nds0pquwwh ; real_T o3tmpk1oqs ; real_T f0eone2pcx
; real_T pna0ewslvq ; real_T ane1bh0tzp ; real_T cdh4lqwmzs ; real_T
gmwg11sh2o ; real_T jsnwyu2muf ; real_T j0jhpwexrq ; real_T c4tt3ie5cv ;
real_T ardkprep5k ; real_T atjcjppuwj ; real_T d1450iavjd ; real_T fyguqomian
; real_T n2o5g5vqwa ; real_T jpxie4sccs ; real_T lieleqwh3j ; real_T
olpzw1u0mj ; real_T kmq2hmecsh ; real_T fftncxxwcc ; real_T al0caonaea ;
real_T m3a0dejyb5 ; real_T kmz4nwgshd ; real_T d2hdzhpkry ; real_T kg1lf5mre3
; real_T e1xtkexzma ; real_T phcpzcz1kz ; real_T jefcavto2f ; real_T
np5akjgggl ; real_T cy5g2czecp ; real_T bh0atnhm3a ; real_T cciobhlnxw ;
real_T nbntlsnpq0 ; real_T ftozibi1sa ; real_T o12hcqazfc ; real_T lvap2nmoll
; real_T cbiaofl3te ; real_T nm1jvcqpba ; real_T cl3nx4r1cp ; real_T
ebnv4rk0xz ; real_T mu2lo5bpcz ; real_T m1aac0i1yb ; real_T p1mr5vlnp3 ;
real_T gs5iselcbq ; real_T obdmmtqzeh ; real_T g4ood130w4 ; real_T ffaevmu2lq
; real_T lurbffmf3f ; real_T m121x1kiug ; real_T f3vlaghkqx ; real_T
nhdljtiuoi ; real_T a005b0rq1z ; real_T hnxatczjsr ; real_T hga13mqldg ;
real_T k40ljtosun ; real_T egufsg5zgr ; real_T h54ht4sm5j ; real_T jzzz31010o
; real_T orzqddjzwa ; real_T at1opiwgjh ; real_T g1wbgmwuat ; real_T
oasdpckmlw ; real_T eppq54lnsq ; real_T d31zgkc1ot ; real_T ebpqvcgc3e ;
real_T jxwo502yf1 ; real_T cnxacw2y2a ; real_T aty5xtr2qj ; real_T fwdugnppnj
; real_T hqjrrf3emi ; real_T g3murv4jh0 ; real_T l4fbmgaghj ; real_T
oexox2au1u ; real_T pnj4sjdqtm ; real_T nw4c0hobyc ; real_T miqgxgohnt ;
real_T i5zq54nc1g ; real_T brwmlbk3nw ; real_T m5wkzqcr4s ; real_T ctf42y0bmx
; real_T bsplkuib2k ; real_T c2gl5vd41y ; real_T iv5y4jzruv ; real_T
h45paqomyg ; real_T cayn1np1ei ; real_T n2peicua3g ; real_T bo4jidsxr0 ;
real_T nxay1p42xj ; real_T bxosirlxhk ; real_T bb5uy2gyjz ; real_T cx2bg11mjv
; real_T gols4cw5f2 ; real_T ej2vkny5tl ; real_T g1taanry4v ; real_T
gmehrhs3lg ; real_T dfuah0vio4 ; real_T hk1o00fibt ; real_T kb5ofkcz0h ;
real_T ju4dhvktgp ; real_T jbjfaulf3f ; real_T kqj4xvki2d ; real_T h3ezyuyxjp
; real_T kya1rjzw1s ; real_T ic0too3kfn ; real_T gt4zsvqvm3 ; real_T
hpxpgx0yqg ; real_T plvo3pr0pn ; real_T pk3cmw2rik ; real_T gqkbw4dlii ;
real_T obcvwvthwc ; real_T dxwdwppbvi ; real_T eb5vds42pr ; real_T n3kvgxx1lb
; real_T h2nn2mw3kd ; real_T pwihaurgw1 ; real_T olqkk1ls2r ; real_T
pkoiqfinnp ; real_T gg1y3nrkjt ; real_T oos2aox4pp ; real_T ddedgirdcl ;
real_T akqhxjgh4u ; real_T bmbionv33d ; real_T knmlf5oi4f ; } jrucs4a3rx ;
typedef struct { ZCSigState oifv3bxtiz ; ZCSigState hnilfpwfdy ; ZCSigState
e4i31n2wa2 ; ZCSigState gbmg2h4scf ; ZCSigState blmkotd0mf ; ZCSigState
argwhwpng5 ; ZCSigState f30xvi5d1p ; ZCSigState e31f0r5kes ; ZCSigState
ndupu0ns4u ; ZCSigState cgcu2qgqgl ; ZCSigState ig4kulqqe0 ; ZCSigState
lwky2hu3w1 ; ZCSigState mxg5ehupdo ; ZCSigState j3gmj3cnlr ; ZCSigState
oj4o55qg4c ; ZCSigState kd2k4yyhnb ; ZCSigState ozihmyatfo ; ZCSigState
ewnwnkokuc ; ZCSigState cznrpfi3og ; ZCSigState aow4qslsmm ; ZCSigState
hozvvcjzjn ; ZCSigState nl5p1yuqwj ; ZCSigState muiodigkpd ; ZCSigState
pbzxcrwnzw ; ZCSigState esienl3dmz ; ZCSigState hfani4u5by ; ZCSigState
hyyfpelahw ; ZCSigState agxbs4350r ; ZCSigState oznc15xgnf ; ZCSigState
ndmnqzqjhz ; ZCSigState hpq4o4dffb ; ZCSigState iicefgnfe3 ; ZCSigState
l2wpk111vj ; ZCSigState kh1mpplruw ; ZCSigState ehhquqngd4 ; ZCSigState
luf5tktsvd ; ZCSigState eswop31w0o ; ZCSigState gnhl1py12v ; ZCSigState
m2gnpwzihz ; ZCSigState phhaxemotd ; ZCSigState esgffodbno ; ZCSigState
buqdmtnjpu ; ZCSigState bxing4vkii ; ZCSigState h32ttz3hb3 ; ZCSigState
nbvyzmi5w3 ; ZCSigState oleuqtat1f ; ZCSigState f0ocdwxqx2 ; ZCSigState
oty0avj33p ; ZCSigState oq4zotzo3z ; ZCSigState ke3o4rv3bd ; ZCSigState
m03l35imkq ; ZCSigState ppjyip03pd ; ZCSigState dywsuhl1ij ; ZCSigState
ota2vyu3on ; ZCSigState mebk4rpfmg ; ZCSigState ln1dhrf41s ; ZCSigState
m4wcaeywyc ; ZCSigState hnl2xxfj5c ; ZCSigState etdjxuf2if ; ZCSigState
amzbmhlrfr ; ZCSigState a0bz1hbaob ; ZCSigState jlr2wdbwuk ; ZCSigState
nqczop3zua ; ZCSigState faxvlzqlxu ; ZCSigState luqlgq2pdj ; ZCSigState
jariktjxrn ; ZCSigState g15jamhtma ; ZCSigState k5rlb0vief ; ZCSigState
hv3fgwo3bs ; ZCSigState kgbsptzluf ; ZCSigState gqzmuknm3f ; ZCSigState
cbc424jnby ; ZCSigState cvuqhbx2tc ; ZCSigState a2lz3oe0sq ; ZCSigState
b33ok3kruc ; ZCSigState bx4hxu5g4a ; ZCSigState e3qm3njcgm ; ZCSigState
olok53tzkl ; ZCSigState mnxlk45hjv ; ZCSigState pgrt2uzsiz ; ZCSigState
jcsq3mebxy ; ZCSigState jjzoxvjdaa ; ZCSigState oqdpucoxqv ; ZCSigState
j4kue10xwy ; ZCSigState ieertott5g ; ZCSigState c5rwssh2vc ; ZCSigState
kgbegoudrl ; ZCSigState p4jgy2uvff ; ZCSigState afohqqmlz1 ; ZCSigState
iiwhasce5u ; ZCSigState dxx1o3liu3 ; ZCSigState hzcp4k5tl5 ; ZCSigState
dlwe14crcb ; ZCSigState a0pd42q5ca ; ZCSigState ltsdt1au0a ; ZCSigState
gtml05nn1g ; ZCSigState cybzjbzzrb ; ZCSigState gjwj5hhdrd ; ZCSigState
noh2bhutv3 ; ZCSigState pb31cr0abw ; ZCSigState b4zu5srkx0 ; ZCSigState
ko52rpj2pt ; ZCSigState bu4mgy0dpb ; ZCSigState anxyrbzo3v ; ZCSigState
atouhrziux ; ZCSigState dszp0a4g0h ; ZCSigState lnni0fx1po ; ZCSigState
p0x2hposrr ; ZCSigState iygxsgfpkt ; ZCSigState idimvz1ygy ; ZCSigState
k0w2qbh15k ; ZCSigState c54p5bs0bp ; ZCSigState igxmybxnts ; ZCSigState
mgnlvbidlo ; ZCSigState oj1yideqxh ; ZCSigState pgim114jj2 ; ZCSigState
bugdnijsxg ; ZCSigState icjzz3kjin ; ZCSigState ptsexlx45x ; ZCSigState
irzjc0oebp ; ZCSigState cgehzy5zx3 ; ZCSigState h0qswfp5id ; ZCSigState
ehe5szg2x3 ; ZCSigState cj4qkierzu ; ZCSigState erw3tiotxn ; ZCSigState
otcas140kp ; ZCSigState ptrhgza4iu ; ZCSigState pjxerjjbdl ; ZCSigState
jtutanq03b ; ZCSigState nx1mnxjzjj ; ZCSigState liuikagrhq ; ZCSigState
inhslrmijm ; ZCSigState n3c34mmzlz ; ZCSigState opxurle554 ; ZCSigState
fehun5s3fs ; } m53qw53rk2 ; typedef struct { int_T ir [ 1 ] ; int_T jc [ 91 +
1 ] ; real_T pr [ 1 ] ; } n4x55a5a4x ; struct mrcrm0jxvb_ { real_T P_0 ;
real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ; real_T P_6 ;
real_T P_7 ; real_T P_8 ; real_T P_9 ; real_T P_10 ; real_T P_11 ; real_T
P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ; } ; extern mrcrm0jxvb
k32qvmidlk ;
#endif
