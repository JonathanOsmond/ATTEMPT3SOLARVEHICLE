#include "__cf_SolarArray_4MPPT2.h"
#include <math.h>
#include "SolarArray_4MPPT2_acc.h"
#include "SolarArray_4MPPT2_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "slexec_vm_lookup_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T jrocrsz5nu ;
real_T currentTime ; o5ipvpmpa2 * _rtB ; mrcrm0jxvb * _rtP ; cfh0nr4x0p *
_rtDW ; _rtDW = ( ( cfh0nr4x0p * ) ssGetRootDWork ( S ) ) ; _rtP = ( (
mrcrm0jxvb * ) ssGetModelRtp ( S ) ) ; _rtB = ( ( o5ipvpmpa2 * )
_ssGetModelBlockIO ( S ) ) ; _rtB -> mofz5vbiy2 [ 0 ] = _rtB -> gl4zqbycev ;
_rtB -> mofz5vbiy2 [ 1 ] = 0.0 ; _rtB -> mofz5vbiy2 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> nhce3zpg0n [ 0 ] = ! ( _rtB ->
mofz5vbiy2 [ 0 ] == _rtDW -> nhce3zpg0n [ 1 ] ) ; _rtDW -> nhce3zpg0n [ 1 ] =
_rtB -> mofz5vbiy2 [ 0 ] ; } _rtB -> mofz5vbiy2 [ 3 ] = _rtDW -> nhce3zpg0n [
0 ] ; _rtB -> nuexc0on5m [ 0 ] = _rtB -> bqy0so4pet ; _rtB -> nuexc0on5m [ 1
] = 0.0 ; _rtB -> nuexc0on5m [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> kepp3otxop [ 0 ] = ! ( _rtB -> nuexc0on5m [ 0 ] == _rtDW ->
kepp3otxop [ 1 ] ) ; _rtDW -> kepp3otxop [ 1 ] = _rtB -> nuexc0on5m [ 0 ] ; }
_rtB -> nuexc0on5m [ 3 ] = _rtDW -> kepp3otxop [ 0 ] ; _rtB -> cm4oxwrr1n [ 0
] = _rtB -> gzwla3quzu ; _rtB -> cm4oxwrr1n [ 1 ] = 0.0 ; _rtB -> cm4oxwrr1n
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> jsjk1l5nqh [ 0 ] = !
( _rtB -> cm4oxwrr1n [ 0 ] == _rtDW -> jsjk1l5nqh [ 1 ] ) ; _rtDW ->
jsjk1l5nqh [ 1 ] = _rtB -> cm4oxwrr1n [ 0 ] ; } _rtB -> cm4oxwrr1n [ 3 ] =
_rtDW -> jsjk1l5nqh [ 0 ] ; _rtB -> ap5dnhe1c4 [ 0 ] = _rtB -> bgugsjyqjq ;
_rtB -> ap5dnhe1c4 [ 1 ] = 0.0 ; _rtB -> ap5dnhe1c4 [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> gpaigrmh5g [ 0 ] = ! ( _rtB ->
ap5dnhe1c4 [ 0 ] == _rtDW -> gpaigrmh5g [ 1 ] ) ; _rtDW -> gpaigrmh5g [ 1 ] =
_rtB -> ap5dnhe1c4 [ 0 ] ; } _rtB -> ap5dnhe1c4 [ 3 ] = _rtDW -> gpaigrmh5g [
0 ] ; _rtB -> nsikrywcul [ 0 ] = _rtB -> bgugsjyqjq ; _rtB -> nsikrywcul [ 1
] = 0.0 ; _rtB -> nsikrywcul [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> a2fjs5ue52 [ 0 ] = ! ( _rtB -> nsikrywcul [ 0 ] == _rtDW ->
a2fjs5ue52 [ 1 ] ) ; _rtDW -> a2fjs5ue52 [ 1 ] = _rtB -> nsikrywcul [ 0 ] ; }
_rtB -> nsikrywcul [ 3 ] = _rtDW -> a2fjs5ue52 [ 0 ] ; _rtB -> m4sv1andz4 [ 0
] = _rtB -> gzwla3quzu ; _rtB -> m4sv1andz4 [ 1 ] = 0.0 ; _rtB -> m4sv1andz4
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> llwxnxmwrf [ 0 ] = !
( _rtB -> m4sv1andz4 [ 0 ] == _rtDW -> llwxnxmwrf [ 1 ] ) ; _rtDW ->
llwxnxmwrf [ 1 ] = _rtB -> m4sv1andz4 [ 0 ] ; } _rtB -> m4sv1andz4 [ 3 ] =
_rtDW -> llwxnxmwrf [ 0 ] ; _rtB -> g3mjzkbmpz [ 0 ] = _rtB -> bqy0so4pet ;
_rtB -> g3mjzkbmpz [ 1 ] = 0.0 ; _rtB -> g3mjzkbmpz [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> cluzohdzmj [ 0 ] = ! ( _rtB ->
g3mjzkbmpz [ 0 ] == _rtDW -> cluzohdzmj [ 1 ] ) ; _rtDW -> cluzohdzmj [ 1 ] =
_rtB -> g3mjzkbmpz [ 0 ] ; } _rtB -> g3mjzkbmpz [ 3 ] = _rtDW -> cluzohdzmj [
0 ] ; _rtB -> eylnwy1qiy [ 0 ] = _rtB -> cg3obh1znk ; _rtB -> eylnwy1qiy [ 1
] = 0.0 ; _rtB -> eylnwy1qiy [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> ljs2jvrtzb [ 0 ] = ! ( _rtB -> eylnwy1qiy [ 0 ] == _rtDW ->
ljs2jvrtzb [ 1 ] ) ; _rtDW -> ljs2jvrtzb [ 1 ] = _rtB -> eylnwy1qiy [ 0 ] ; }
_rtB -> eylnwy1qiy [ 3 ] = _rtDW -> ljs2jvrtzb [ 0 ] ; _rtB -> m5zct5hbeq [ 0
] = _rtB -> nakwvrxqx2 ; _rtB -> m5zct5hbeq [ 1 ] = 0.0 ; _rtB -> m5zct5hbeq
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> owaqyeihiv [ 0 ] = !
( _rtB -> m5zct5hbeq [ 0 ] == _rtDW -> owaqyeihiv [ 1 ] ) ; _rtDW ->
owaqyeihiv [ 1 ] = _rtB -> m5zct5hbeq [ 0 ] ; } _rtB -> m5zct5hbeq [ 3 ] =
_rtDW -> owaqyeihiv [ 0 ] ; _rtB -> jxxkhf23ff [ 0 ] = _rtB -> gl4zqbycev ;
_rtB -> jxxkhf23ff [ 1 ] = 0.0 ; _rtB -> jxxkhf23ff [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> gkw1f3v5dq [ 0 ] = ! ( _rtB ->
jxxkhf23ff [ 0 ] == _rtDW -> gkw1f3v5dq [ 1 ] ) ; _rtDW -> gkw1f3v5dq [ 1 ] =
_rtB -> jxxkhf23ff [ 0 ] ; } _rtB -> jxxkhf23ff [ 3 ] = _rtDW -> gkw1f3v5dq [
0 ] ; _rtB -> b0ezksuzlv [ 0 ] = _rtB -> nakwvrxqx2 ; _rtB -> b0ezksuzlv [ 1
] = 0.0 ; _rtB -> b0ezksuzlv [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> dhjytdolsk [ 0 ] = ! ( _rtB -> b0ezksuzlv [ 0 ] == _rtDW ->
dhjytdolsk [ 1 ] ) ; _rtDW -> dhjytdolsk [ 1 ] = _rtB -> b0ezksuzlv [ 0 ] ; }
_rtB -> b0ezksuzlv [ 3 ] = _rtDW -> dhjytdolsk [ 0 ] ; _rtB -> irsr3snper [ 0
] = _rtB -> cg3obh1znk ; _rtB -> irsr3snper [ 1 ] = 0.0 ; _rtB -> irsr3snper
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> dzv5ltiqhw [ 0 ] = !
( _rtB -> irsr3snper [ 0 ] == _rtDW -> dzv5ltiqhw [ 1 ] ) ; _rtDW ->
dzv5ltiqhw [ 1 ] = _rtB -> irsr3snper [ 0 ] ; } _rtB -> irsr3snper [ 3 ] =
_rtDW -> dzv5ltiqhw [ 0 ] ; _rtB -> ex43zdrifj [ 0 ] = _rtB -> kupr01xcmy ;
_rtB -> ex43zdrifj [ 1 ] = 0.0 ; _rtB -> ex43zdrifj [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> mfc2dmmp1z [ 0 ] = ! ( _rtB ->
ex43zdrifj [ 0 ] == _rtDW -> mfc2dmmp1z [ 1 ] ) ; _rtDW -> mfc2dmmp1z [ 1 ] =
_rtB -> ex43zdrifj [ 0 ] ; } _rtB -> ex43zdrifj [ 3 ] = _rtDW -> mfc2dmmp1z [
0 ] ; _rtB -> lxlps4rynr [ 0 ] = _rtB -> kupr01xcmy ; _rtB -> lxlps4rynr [ 1
] = 0.0 ; _rtB -> lxlps4rynr [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> iof2yhh0p0 [ 0 ] = ! ( _rtB -> lxlps4rynr [ 0 ] == _rtDW ->
iof2yhh0p0 [ 1 ] ) ; _rtDW -> iof2yhh0p0 [ 1 ] = _rtB -> lxlps4rynr [ 0 ] ; }
_rtB -> lxlps4rynr [ 3 ] = _rtDW -> iof2yhh0p0 [ 0 ] ; _rtB -> druun3nucx [ 0
] = _rtB -> docckoh30w ; _rtB -> druun3nucx [ 1 ] = 0.0 ; _rtB -> druun3nucx
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> oqyzll4ukh [ 0 ] = !
( _rtB -> druun3nucx [ 0 ] == _rtDW -> oqyzll4ukh [ 1 ] ) ; _rtDW ->
oqyzll4ukh [ 1 ] = _rtB -> druun3nucx [ 0 ] ; } _rtB -> druun3nucx [ 3 ] =
_rtDW -> oqyzll4ukh [ 0 ] ; _rtB -> lvnu5cln0f [ 0 ] = _rtB -> docckoh30w ;
_rtB -> lvnu5cln0f [ 1 ] = 0.0 ; _rtB -> lvnu5cln0f [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> p1oa3xfkrz [ 0 ] = ! ( _rtB ->
lvnu5cln0f [ 0 ] == _rtDW -> p1oa3xfkrz [ 1 ] ) ; _rtDW -> p1oa3xfkrz [ 1 ] =
_rtB -> lvnu5cln0f [ 0 ] ; } _rtB -> lvnu5cln0f [ 3 ] = _rtDW -> p1oa3xfkrz [
0 ] ; _rtB -> hlkfredxjk [ 0 ] = _rtB -> kv1baduwaa ; _rtB -> hlkfredxjk [ 1
] = 0.0 ; _rtB -> hlkfredxjk [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> h2vekgsxkd [ 0 ] = ! ( _rtB -> hlkfredxjk [ 0 ] == _rtDW ->
h2vekgsxkd [ 1 ] ) ; _rtDW -> h2vekgsxkd [ 1 ] = _rtB -> hlkfredxjk [ 0 ] ; }
_rtB -> hlkfredxjk [ 3 ] = _rtDW -> h2vekgsxkd [ 0 ] ; _rtB -> pa5nfiuptp [ 0
] = _rtB -> b2sfywwpbz ; _rtB -> pa5nfiuptp [ 1 ] = 0.0 ; _rtB -> pa5nfiuptp
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> kj3o5iu5lv [ 0 ] = !
( _rtB -> pa5nfiuptp [ 0 ] == _rtDW -> kj3o5iu5lv [ 1 ] ) ; _rtDW ->
kj3o5iu5lv [ 1 ] = _rtB -> pa5nfiuptp [ 0 ] ; } _rtB -> pa5nfiuptp [ 3 ] =
_rtDW -> kj3o5iu5lv [ 0 ] ; _rtB -> lg52uwvjmt [ 0 ] = _rtB -> kv1baduwaa ;
_rtB -> lg52uwvjmt [ 1 ] = 0.0 ; _rtB -> lg52uwvjmt [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> d0acwttvk0 [ 0 ] = ! ( _rtB ->
lg52uwvjmt [ 0 ] == _rtDW -> d0acwttvk0 [ 1 ] ) ; _rtDW -> d0acwttvk0 [ 1 ] =
_rtB -> lg52uwvjmt [ 0 ] ; } _rtB -> lg52uwvjmt [ 3 ] = _rtDW -> d0acwttvk0 [
0 ] ; _rtB -> pxided2a1m [ 0 ] = _rtB -> b2sfywwpbz ; _rtB -> pxided2a1m [ 1
] = 0.0 ; _rtB -> pxided2a1m [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> bh42x4daf5 [ 0 ] = ! ( _rtB -> pxided2a1m [ 0 ] == _rtDW ->
bh42x4daf5 [ 1 ] ) ; _rtDW -> bh42x4daf5 [ 1 ] = _rtB -> pxided2a1m [ 0 ] ; }
_rtB -> pxided2a1m [ 3 ] = _rtDW -> bh42x4daf5 [ 0 ] ; _rtB -> kf3v4w1yy0 [ 0
] = _rtB -> h5zijdgjfg ; _rtB -> kf3v4w1yy0 [ 1 ] = 0.0 ; _rtB -> kf3v4w1yy0
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> fttl1403fb [ 0 ] = !
( _rtB -> kf3v4w1yy0 [ 0 ] == _rtDW -> fttl1403fb [ 1 ] ) ; _rtDW ->
fttl1403fb [ 1 ] = _rtB -> kf3v4w1yy0 [ 0 ] ; } _rtB -> kf3v4w1yy0 [ 3 ] =
_rtDW -> fttl1403fb [ 0 ] ; _rtB -> l1glpirm2l [ 0 ] = _rtB -> h5zijdgjfg ;
_rtB -> l1glpirm2l [ 1 ] = 0.0 ; _rtB -> l1glpirm2l [ 2 ] = 0.0 ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> jzpt0jjpuw [ 0 ] = ! ( _rtB ->
l1glpirm2l [ 0 ] == _rtDW -> jzpt0jjpuw [ 1 ] ) ; _rtDW -> jzpt0jjpuw [ 1 ] =
_rtB -> l1glpirm2l [ 0 ] ; } _rtB -> l1glpirm2l [ 3 ] = _rtDW -> jzpt0jjpuw [
0 ] ; _rtB -> jnubqt1a55 [ 0 ] = _rtB -> gl4zqbycev ; _rtB -> jnubqt1a55 [ 1
] = 0.0 ; _rtB -> jnubqt1a55 [ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> aohdf4v02w [ 0 ] = ! ( _rtB -> jnubqt1a55 [ 0 ] == _rtDW ->
aohdf4v02w [ 1 ] ) ; _rtDW -> aohdf4v02w [ 1 ] = _rtB -> jnubqt1a55 [ 0 ] ; }
_rtB -> jnubqt1a55 [ 3 ] = _rtDW -> aohdf4v02w [ 0 ] ; _rtB -> aztk3z2sl2 [ 0
] = _rtB -> gl4zqbycev ; _rtB -> aztk3z2sl2 [ 1 ] = 0.0 ; _rtB -> aztk3z2sl2
[ 2 ] = 0.0 ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> lz4a4jfzub [ 0 ] = !
( _rtB -> aztk3z2sl2 [ 0 ] == _rtDW -> lz4a4jfzub [ 1 ] ) ; _rtDW ->
lz4a4jfzub [ 1 ] = _rtB -> aztk3z2sl2 [ 0 ] ; } _rtB -> aztk3z2sl2 [ 3 ] =
_rtDW -> lz4a4jfzub [ 0 ] ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { currentTime
= ssGetTaskTime ( S , 1 ) ; _rtDW -> nfscce14u0 = ( currentTime >= _rtP ->
P_11 ) ; if ( _rtDW -> nfscce14u0 == 1 ) { _rtB -> cwidrx0imh = _rtP -> P_13
; } else { _rtB -> cwidrx0imh = _rtP -> P_12 ; } } jrocrsz5nu = ssGetT ( S )
; _rtB -> pccbbjg4ne = jrocrsz5nu - _rtB -> jdafa2veaq ; _rtB -> jkxjgk13h3 =
_rtB -> cwidrx0imh * _rtB -> pccbbjg4ne ; _rtB -> focqdn31tx = _rtB ->
jkxjgk13h3 + _rtB -> e1vroguf5f ; _rtB -> i2wo3fsj2j [ 0 ] = _rtB ->
focqdn31tx ; _rtB -> i2wo3fsj2j [ 1 ] = 0.0 ; _rtB -> i2wo3fsj2j [ 2 ] = 0.0
; _rtB -> i2wo3fsj2j [ 3 ] = 0.0 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 44 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_OUTPUTS ) ; _rtB -> li5nzdtkek
[ 0 ] = _rtB -> gyrqqbo0dl [ 2 ] ; _rtB -> li5nzdtkek [ 1 ] = _rtB ->
gyrqqbo0dl [ 0 ] ; ssCallAccelRunBlock ( S , 1 , 0 , SS_CALL_MDL_OUTPUTS ) ;
_rtB -> dgfdsiigxt [ 0 ] = _rtB -> gyrqqbo0dl [ 2 ] ; _rtB -> dgfdsiigxt [ 1
] = _rtB -> gyrqqbo0dl [ 1 ] ; } ssCallAccelRunBlock ( S , 2 , 47 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 2 , 48 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> bku2h5cxlf [ 0 ] = _rtB -> gyrqqbo0dl [ 2 ] ;
_rtB -> bku2h5cxlf [ 1 ] = _rtB -> gyrqqbo0dl [ 0 ] ; ssCallAccelRunBlock ( S
, 2 , 50 , SS_CALL_MDL_OUTPUTS ) ; UNUSED_PARAMETER ( tid ) ; } static void
mdlOutputsTID2 ( SimStruct * S , int_T tid ) { o5ipvpmpa2 * _rtB ; mrcrm0jxvb
* _rtP ; _rtP = ( ( mrcrm0jxvb * ) ssGetModelRtp ( S ) ) ; _rtB = ( (
o5ipvpmpa2 * ) _ssGetModelBlockIO ( S ) ) ; _rtB -> gl4zqbycev = _rtP -> P_0
; _rtB -> bqy0so4pet = _rtP -> P_1 ; _rtB -> gzwla3quzu = _rtP -> P_2 ; _rtB
-> bgugsjyqjq = _rtP -> P_3 ; _rtB -> cg3obh1znk = _rtP -> P_4 ; _rtB ->
nakwvrxqx2 = _rtP -> P_5 ; _rtB -> kupr01xcmy = _rtP -> P_6 ; _rtB ->
docckoh30w = _rtP -> P_7 ; _rtB -> kv1baduwaa = _rtP -> P_8 ; _rtB ->
b2sfywwpbz = _rtP -> P_9 ; _rtB -> h5zijdgjfg = _rtP -> P_10 ; _rtB ->
jdafa2veaq = _rtP -> P_14 ; _rtB -> e1vroguf5f = _rtP -> P_15 ;
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { o5ipvpmpa2 * _rtB ;
_rtB = ( ( o5ipvpmpa2 * ) _ssGetModelBlockIO ( S ) ) ; ssCallAccelRunBlock (
S , 2 , 43 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
ssCallAccelRunBlock ( S , 0 , 0 , SS_CALL_MDL_UPDATE ) ; ssCallAccelRunBlock
( S , 1 , 0 , SS_CALL_MDL_UPDATE ) ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID2 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_DERIVATIVES ) ; }
#define MDL_FORCINGFUNCTION
static void mdlForcingFunction ( SimStruct * S ) { ssCallAccelRunBlock ( S ,
2 , 43 , SS_CALL_MDL_FORCINGFUNCTION ) ; }
#define MDL_MASSMATRIX
static void mdlMassMatrix ( SimStruct * S ) { ssCallAccelRunBlock ( S , 2 ,
43 , SS_CALL_MDL_MASSMATRIX ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { mrcrm0jxvb * _rtP ;
jrucs4a3rx * _rtZCSV ; _rtZCSV = ( ( jrucs4a3rx * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( mrcrm0jxvb * ) ssGetModelRtp ( S ) ) ; _rtZCSV ->
dxrr2mvo21 = ssGetT ( S ) - _rtP -> P_11 ; ssCallAccelRunBlock ( S , 2 , 43 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 157394181U ) ; ssSetChecksumVal ( S , 1 ,
1610840198U ) ; ssSetChecksumVal ( S , 2 , 2131409055U ) ; ssSetChecksumVal (
S , 3 , 3307128044U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.7" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
cfh0nr4x0p ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( o5ipvpmpa2 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
mrcrm0jxvb ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetModelRtp ( S , ( real_T *
) & k32qvmidlk ) ; if ( ssGetSizeofDWork ( S ) == sizeof ( cfh0nr4x0p ) ) { {
( ( cfh0nr4x0p * ) ssGetRootDWork ( S ) ) -> bb2alwd0gn = 0 ; } }
rt_InitInfAndNaN ( sizeof ( real_T ) ) ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID2 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
