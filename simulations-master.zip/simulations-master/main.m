%% MPPT Optimisation V2
% Jack Ward & Jarryd Moore

clear all
close all
clc



q=1;
w=1;   
numToStartFrom = 3;
for NumMPPT = numToStartFrom:5
    simtype = sprintf('SolarArray%dMPPT',NumMPPT);
    Result{(NumMPPT-2)} = simFunction(NumMPPT,simtype);
    
    
    
     
   
end
 
 [Pout1,Pout2,Pout3] = plotFunction(Result,NumMPPT)