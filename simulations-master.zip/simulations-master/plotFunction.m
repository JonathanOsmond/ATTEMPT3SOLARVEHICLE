function [OptimalBattVolt3,OptimalBattVolt4,OptimalBattVolt5,HighestEff3,HighestEff4,HighestEff5] = plotFunction( Result,NumMPPT )
%UNTITLED plotFunction takes the cell array ResultTotal after all the
%simulations have run and unpackages and plots the necessary data.



%UNTITLED plotFunction takes the cell array ResultTotal after all the
%simulations have run and unpackages and plots the necessary data.



%% MPPT3 Efficiencies
NumMPPT = 3;
w = 1;
for BattVolt = 110:5:150
    
    if BattVolt/NumMPPT >40
        
        disp('ERROR: MPPT cannot output over 40v')
        
        break
        
    end
        
        for i=1:18      % Iterate over hours of the day
            
            [Pmax(i),Index] = (max(Result{1,1}(i).Power));   %PowerMax for every half hour
            Vmp(i) = Result{1,1}(i).Voltage(Index)
            [Peff(i),OverVoltage] = EfficiencyData(BattVolt,NumMPPT,Vmp(i));
            Pout(i) = Peff(i)*Pmax(i);
            
           
            
            
        end
        
      maxPeff3(w) = max(Peff) 
      maxPout3(w) = max(Pout);
      MPPT3_Max{w} = Pmax;
      MPPT3_Pout{w} = Pout;
      MPPT3_Peff{w} = Peff;
      w=w+1;
      
      
end
        




%% MPPT4 EFFICIENCIES
NumMPPT = 4;
w = 1;
for BattVolt = 110:5:150
    
    if BattVolt/NumMPPT >40
        
        disp('ERROR: MPPT cannot output over 40v')
        
        break
        
    end
    
    for q = 1:3
        
        for i=1:18
            
            [Pmax(i),Index] = (max(Result{1,2}{q,i}.Power));   %PowerMax for every half hour
            disp(Index)
            Vmp(q,i) = Result{1,2}{q,i}.Voltage(Index)
            Peff(q,i) = EfficiencyData(BattVolt,NumMPPT,Vmp(q,i));
            Pout(q,i) = Peff(q,i)*Pmax(i);
            
        end
        
            [maxPout4(q),Index4(q)] = max(Pout(q,:));
            
             
    end
    
      MPPT4_Max{w} = Pmax;
      MPPT4_Pout{w} = Pout;
      MPPT4_Peff{w} = Peff;
      AveMaxPeff4(w) = max(mean(Peff));
      AveMaxPout4(w) = max(mean(Pout));
      
      w=w+1;
end
        

      

%% MPPT5 EFFICIENCIES
NumMPPT = 5;
w = 1;
for BattVolt = 110:5:150
    
    for q = 1:3
        
        for i=1:18
            
            [Pmax(i),Index] = (max(Result{1,3}{q,i}.Power)); %PowerMax for every half hour
            Vmp(q,i) = Result{1,3}{q,i}.Voltage(Index)
            
            Peff(q,i) = EfficiencyData(BattVolt,NumMPPT,Vmp(q,i));
            Pout(q,i) = Peff(q,i)*Pmax(i);
            
        end
            [maxPout5(q),Index5(q)] = max(Pout(q,:));
    end
      MPPT5_Max{w} = Pmax;
      MPPT5_Pout{w} = Pout;
      MPPT5_Peff{w} = Peff;
      AveMaxPeff5(w) = max(mean(Peff));
      AveMaxPout5(w)= max(mean(Pout));
      
      w=w+1;
end  

 %% Best Solution finder
 
 [HighestPout5,Index] = max(AveMaxPout5);
 [HighestEff5,VoltIndex] = max(AveMaxPeff5);
 OptimalBattVolt5 = (VoltIndex*5 + 105); %Converting increment toBattVolt
 
  [HighestPout4,Index] = max(AveMaxPout4);
 [HighestEff4,VoltIndex] = max(AveMaxPeff4);
 OptimalBattVolt4 = (VoltIndex*5 + 105); %Converting increment toBattVolt
 
 [HighestPout3,Index] = max(maxPout3);
 [HighestEff3,VoltIndex] = max(maxPeff3);
 OptimalBattVolt3 = (VoltIndex*5 + 105); %Converting increment toBattVolt
 pwrpercell = (max(maxPout3))/40;
 
    
%Solution = sort(maxPout3,mean(maxPout4),mean(maxPout5))
disp(AveMaxPout5)

NoCells5 = 24;
NoCells4 = 32;
NoCells3 = 40;
 
%% PLOTS

 figure
 plot(110:5:120,maxPeff3)
 hold on
 plot(110:5:150,AveMaxPeff4)
 hold on
 plot(110:5:150,AveMaxPeff5)
 title('Maximum Efficiencies of MPPTs')
 xlabel('BatteryVoltage')
 ylabel('Boost Efficiency')
 legend('3MPPTs','4MPPTs','5MPPTs')
 
 
 figure
 plot(110:5:120,maxPout3/(pwrpercell*NoCells3))
 hold on
 plot(110:5:150,AveMaxPout4/(pwrpercell*NoCells4))
 hold on
 plot(110:5:150,AveMaxPout5/(pwrpercell*NoCells5))
 title('Maximum Efficiencies of MPPTs')
 xlabel('BatteryVoltage')
 ylabel('Boost Efficiency')
 legend('3MPPTs','4MPPTs','5MPPTs')

 