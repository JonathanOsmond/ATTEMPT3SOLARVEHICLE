%% MPPT Optimisation
% Jack Ward & Jarryd Moore

clear all
close all
clc

[BattVolt,NumMPPT,temp]=prompt_script()

fwd_drop =  (0.125*(temp-25)+107.5)/1000;

if NumMPPT == 4
    prompt = 'Do you want to analyse Layout 1 or Layout 2 ?';
    choice = input(prompt)
        
    if choice ==1
        simtype = 'SolarArray_4MPPT';
    elseif choice==2
        simtype = 'SolarArray_4MPPTs_Config2';
    else
        disp('Invalid Selection')
        return
    end

elseif NumMPPT == 5
    simtype = 'SolarArray_5MPPT';
    
elseif NumMPPT == 3
    simtype = 'SolarArray_3MPPT';
    
else
    disp('No simulation exists for this MPPT number')
    return
end

w=0;
q=1;

while Z == 1
    for i=1:10            %1 is 8:00 AM, each increment is 30 mins
        
        x= ShadingData2(i);
        Irradiance(1,:)=x(1,:);    % Building Irradiance Matrix for simulink to assign to solar cells
        Irradiance(2,:)=x(2,:);    % The w increments over the 3 different shadows experienced by the 3 sections
        Irradiance(3,:)=x(3,:);    % near the canopy
        Irradiance(4,:)=x(4,:);
        Irradiance(5,:)=x(5,:);
        
        sim(simtype)
        
        Voltage(1:length(power_voltage.data(:,2)),i)= zeros((length(power_voltage.data(:,2))),1);
        Voltage(1:length(power_voltage.data(:,2)),i) = power_voltage.data(:,2);
        
        Current(1:length(current_voltage.data(:,2)),i)= zeros((length(current_voltage.data(:,2))),1);
        Current(1:length(current_voltage.data(:,2)),i) = current_voltage.data(:,2);
        
        Power(1:length(power_voltage.data(:,1)),i)= zeros((length(power_voltage.data(:,1))),1);
        Power(1:length(power_voltage.data(:,1)),i) = power_voltage.data(:,1);
        
        
        PowerData{q}=Power;
        VoltageData{q}=Voltage;
        CurrentData{q}=Current;
        
        Volt = Voltage(:,i);
        Curr = Current(:,i);
        Pwr = Power(:,i);
        Pmax(q,i) = max(Pwr);
        k = find(Pwr == Pmax(q,i),1);
        
        Vmp(i) = Volt(k,1);
        Imp(i) = Curr(k,1);
        r=i;
        Peff = EfficiencyData(Vout,Vmp,i);
        PowerEfficiency(i) = Peff(i);
        Peff2(w+1)=Peff(i);
        Pout(q,i)=(Pmax(i)*Peff2(w+1))/100;
        
    end
    
    if i==10
        VMPP(q,:) = Vmp;
        IMPP(q,:) = Imp;
        w=w+2;
        q=q+1;
        if w==6; %Once the 3 sims occur
            
            break
            
        elseif choice ~= 2
            
            break
            
        end   
    end
end


if Z==1
    
    Voltage(Voltage==0) = nan;
    Power(Power == 0) = nan;
    Current(Current == 0) = nan;
    timevector=[800 ,830 ,900,930 ,1000 ,1030 ,1100 ,1130 ,1200 ,1230 ];
    figure('Name','eff percent vs time','NumberTitle','off')
    plot(timevector,PowerEfficiency)
    xlabel('Time')
    ylabel('Pout/Pin (%)')
    
    figure('Name','PowerVoltage (PV) Curves','NumberTitle','off')
    plot(Voltage,Power)
    xlabel('Time')
    ylabel('Pout/Pin (%)')
    
    return
end


i=1;


while Z==2
    
    r=1;
    
    if (i-increment)<=0      %errors occur when irrad = 0. In reality this will also never happen
        break
    end
    
    for i=1:-increment:0
        
        
        
        
        
        Irradiance(1,:)=ones(1,5)*1000*i;
        Irradiance(2,:)=ones(1,5)*1000*i;
        Irradiance(3,:)=ones(1,5)*1000*i;
        Irradiance(4,:)=ones(1,5)*1000*i;
        Irradiance(5,:)=ones(1,5)*1000*i;
        
        assignin('base','Irradiance',Irradiance)
        assignin('base','temp',temp)
        assignin('base','fwd_drop',fwd_drop)
        sim(simtype)
        
        Voltage(1:length(power_voltage.data(:,2)),r)= zeros((length(power_voltage.data(:,2))),1);
        Voltage(1:length(power_voltage.data(:,2)),r) = power_voltage.data(:,2);
        
        Current(1:length(current_voltage.data(:,2)),r)= zeros((length(current_voltage.data(:,2))),1);
        Current(1:length(current_voltage.data(:,2)),r) = current_voltage.data(:,2);
        
        Power(1:length(power_voltage.data(:,1)),r)= zeros((length(power_voltage.data(:,1))),1)
        Power(1:length(current_voltage.data(:,2)),r) = power_voltage.data(:,1);
        
        Volt = Voltage(:,r);
        Curr = Current(:,r);
        Pwr = Power(:,r);
        Pmax(r) = max(Pwr);
        k = find(Pwr == Pmax(r),1);
        
        Vmp(r) = Volt(k,1);
        Imp(r) = Curr(k,1);
        
        Peff = EfficiencyData(Vout,Vmp,r);
        PowerEfficiency(r) = Peff(r);
        Peff2=Peff(r);
        Pout(r)=(Pmax(r)*Peff2)/100;
        
        r=r+1;
        if (i-increment)<=0
            p=i;
            break
        end
    end    %Simulation run code
end


if Z == 2
    
    figure('Name','eff percent vs irradiance','NumberTitle','off')
    plot(PowerEfficiency,1000*[1:-increment:i])
    xlabel('percent eff')
    ylabel('Irradiance W/m^2')
    legend('Peff(%)','Irradiance(W/M^2)')
    figure('Name','Output power vs irradiance','NumberTitle','off')
    plot(Pout,1000*[1:-increment:i])
    xlabel('Output Power (W)')
    ylabel('Irradiance W/m^2')
    legend('Pout(Watts)','Irradiance(W/M^2)')
    
    figure('Name','Vmp vs irradiance','NumberTitle','off')
    plot(Vmp,1000*[1:-increment:i])
    xlabel('Voltage MPP (V)')
    ylabel('Irradiance W/m^2')
    
    
    Voltage(Voltage==0)=nan;        %Removing zeros for graphing purposes
    Current(Current==0)=nan;
    Power(Power==0)=nan;
    
    figure('Name','voltage vs current (IV)','NumberTitle','off')
    plot(Voltage,Current)
    xlabel('Voltage')
    ylabel('Current')
    figure('Name','power vs current (PV)','NumberTitle','off')
    plot(Voltage,Power)
    xlabel('Voltage')
    ylabel('Power')
    
    figure('Name','Pmax and Pout with varying Irradiance','NumberTitle','off')
    plot(1000*[1:-increment:i],Pmax,1000*[1:-increment:i],Pout)
    xlabel('Irradiance (W/m^2)')
    ylabel('Power (Watts)')
    % MPPT EFFICIENY GRAPHS HERE
    
end





    
    
    