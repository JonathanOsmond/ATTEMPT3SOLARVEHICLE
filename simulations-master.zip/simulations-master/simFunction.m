function Result = simFunction(NumMPPT,simtype)
%This function sets up and calls the simulink file



BOMDataIrr = [392.57
538.645
650.9075
754.54375
843.86625
918.89875
976.8425
1019.12
1040.6025
1043.65375
1027.6825
998.1125
940.71375
869.2
786.475
690.5525
583.32125
459.4375
326.59]'

    BOMDataTemp = ones(1,18)*25;

   
    
        
        for i=1:18                                  %Iterates over the time of day, i=1 is 8:00, i=18 is 5PM, each iteration is 30 min
            i
            assignin('base','temp',BOMDataTemp(i))
            assignin('base','Irradiance',ShadingData2(i,BOMDataIrr(i)))
            assignin('base','IrrX',BOMDataIrr(i))
            assignin('base','fwd_drop',(0.125*(BOMDataTemp(i)-25)+107.5)/1000)

            if (strcmp(simtype,'SolarArray3MPPT')~=1)
                for q=0:2
                    
                assignin('base','s',q*2)
                sim(simtype)
                Volt= power_voltage.data(:,2);
                Curr = current_voltage.data(:,2);
                Pwr = power_voltage.data(:,1);
                %[Pmax,Index] = max(Pwr);
                %Vmp = power_voltage3.data(Index,2);
                %Imp = current_voltage3.data(Index,2);
                
                Result{(q+1),i} = struct('Voltage',Volt,'Current',Curr,'Power',Pwr,'NumMPPT',NumMPPT); 
                end
                
            else

                sim(simtype)
                Volt= power_voltage.data(:,2);
                Curr = current_voltage.data(:,2);
                Pwr = power_voltage.data(:,1);
                %[Pmax,Index] = max(Pwr);
                %Vmp = power_voltage3.data(Index,2);
                %Imp = current_voltage3.data(Index,2);
                
                Result(i) = struct('Voltage',Volt,'Current',Curr,'Power',Pwr,'NumMPPT',NumMPPT); 


            end
        
        end


