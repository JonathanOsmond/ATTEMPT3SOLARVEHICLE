    prompt_script[BattVolt,NumMPPT,temp] = function()
    prompt = 'Input desired battery voltage: ';
    BattVolt = input(prompt);
    
    %prompt = 'Input number of series MPPTs (3 4 or 5): ';
    %NumMPPT = input(prompt);
    
    MaxOutput = 40;
    Vout = BattVolt/NumMPPT;
    if Vout >MaxOutput
        disp('ERROR: MaxMPPT voltage exceeds max possible output')
    else
        A=0;
    end
    
    prompt = 'Enter simulation Temperature: ';
    temp= input(prompt);

    prompt = 'Enter Simulation Type \n 1: Morning \n 2: Afternoon \n ' ;
    Z = input(prompt);

    prompt = 'enter irradiance increment (between 0 and 1): '
    increment = input(prompt);