% MPPT Parameter Design
% Matthew Salkeld 25/08/16

clear
clc

% Critical Parameters for Sunpower Solar Cells

B_CellVoltMax = 4.2;
B_CellVoltNom = 3.8;
B_CellVoltMin = 3.0;

NumCells = 265;

BatteryVoltMax = 120;


% Based on random google "sunpower c60 datasheet"
C60_CellEff = 0.225;
C60_CellVoltMax = 0.687;
C60_CellVoltMpp = 0.582;
C60_CellCurrMax = 6.28;
C60_CellCurrMpp = 5.93;

% Based on email from Sunpower, in confidence: DO NOT DISTRIBUTE
E60_CellEff = 0.243;
E60_PMpp = 3.72;
E60_CellVoltMax = 0.73;
E60_CellCurrMax = 6.18;
E60_CellVoltMpp = 0.632;
E60_CellCurrMpp = 5.89;

% MPPT System
parallel = 2;
series = 4;
NumMppt = parallel*series;

%  Oscillator Frequency