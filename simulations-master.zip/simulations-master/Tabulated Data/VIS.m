function[MaximumPower,Voc,Isc,Vmp,Imp,PowerLossDiode] = VIS(x1,x2,x3,x4,temp,str)
    prompt = 'Which Simulation type would you like to run? \n 1: Sim 1 Paralell Diodes \n 2: Sim 2 Series Diodes \n 3: Both and compare \n'
    str = input(prompt,'s');
    
    if str == '1'
        simtype = 'SolarArray_DiodeConfig1'
    elseif str == '2'
        simtype = 'SolarArray_DiodeConfig2'
    elseif str == '3'
        simtype = 'SolarArray_DiodeConfig1'
    else
        disp('ERROR: No Simulation chosen, self destructing')
        return
        
    end
    
    prompt = 'Do you wish to run at default settings? (25 deg 1000W/m^2) y or n? ';
    choice=input(prompt,'s')
    
    if choice == 'n'
    prompt = 'Incremental change of row 1';
    x1 = input(prompt)
    prompt = 'Input irradiance of row 2';
    x2 = input(prompt)
    prompt = 'Input irradiance of row 3';
    x3 = input(prompt)
    prompt = 'Input irradiance of row 4';
    x4 = input(prompt)
    
    
    prompt1 = 'Enter Simulation Temperature';
    temp=input(prompt1);
    
    prompt = 'Enter simulation stop time';
    StopTime = input(prompt)
    prompt = 'Enter simulation start time';
    StartTime = input(prompt)
    else
    
        temp=25;
        x1=100;
        x2=1000;
        x3=1000;
        x4=1000;
    end
        
    
        
    
    
 fwd_drop =  (0.125*(temp-25)+107.5)/1000;    %calculating forward voltage drop of the bypass diodes (SPV1512)
    i=0;
    A=1       %Correct for 5.8 A (interpolated
 while A==1   
 while i<=(1000/x1)
    Irradiance = [x1*i,x2,x2,x2;x2,x2,x2,x2;x3,x3,x3,x3;x4,x4,x4,x4]  
    assignin('base','Irradiance',[x1*i,x2,x2,x2;x2,x2,x2,x2;x3,x3,x3,x3;x4,x4,x4,x4])
    assignin('base','temp',temp)
    assignin('base','fwd_drop',fwd_drop)
    sim(simtype)
    
    
    voltage = power_voltage.data(:,2);
    power = power_voltage.data(:,1);
    current = current_voltage.data(:,2);

    diodevoltage(:,i+1) = diode_PI.data(:,1);
    disp(diodevoltage)
    diodecurrent(:,i+1) = diode_PI.data(:,2);
    disp(diodecurrent)
    PowerLossDiode(i+1)=max((diodevoltage(:,i+1)).*(diodecurrent(:,i+1)));
    disp(PowerLossDiode)


    MaximumPower(:,i+1) = max(power);
    Voc(:,i+1) = max(voltage);
    Isc(:,i+1) = max(current);
    k = find(power==max(power));
    Vmp(:,i+1) = voltage(k);
    Imp(:,i+1) = current(k);

   
    Curr(:,i+1) = current;
    Vol(:,i+1) = voltage;
    pwr(:,i+1) = power;
    
    i=i+1;
    
    
 end
     if str == 3
         i=0;
         str=0;
     else 
         break
     end
 end
 
    for m=1:length(i)
    figure 
    plot(Vol,pwr)
    end
    
    %figure
    %plot(Vol(:,1:length(i)),pwr(:,1:length(i)))
    %title('PV Graph')
    %xlabel('Voltage')
    %ylabel('Power')
    %legend('0','100','200','300','400','500','600','700','800','900','1000')
    %figure
    %plot(Vol(:,1),Curr(:,1),Vol(:,2),Curr(:,2),Vol(:,3),Curr(:,3),Vol(:,4),Curr(:,4),Vol(:,5),Curr(:,5),Vol(:,6),Curr(:,6),Vol(:,7),Curr(:,7),Vol(:,8),Curr(:,8),Vol(:,9),Curr(:,9),Vol(:,10),Curr(:,10))
    %title('IV Curve')
    %xlabel('Voltage')
    %ylabel('Current')